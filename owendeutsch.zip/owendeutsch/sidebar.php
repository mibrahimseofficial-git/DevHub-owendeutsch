<!-- sidebar start -->
<div class="col-xs-12 col-sm-4 pull-right">
	<div class="main-content-right">

		<?php if ( is_active_sidebar( 'sidebar' ) ) : dynamic_sidebar( 'sidebar' ); else : ?>
			<div class="widget">
				<h3><?php _e('Categories','theme'); ?></h3>
				<ul>
					<?php wp_list_categories("title_li=");?>
				</ul>
			</div>
			 <div class="widget">
				<h3><?php _e('Archives','theme'); ?></h3>
				<ul>
					<?php wp_get_archives('type=monthly'); ?>
				</ul>
			</div>
			<div class="widget">			
				<h3><?php _e('Pages','theme'); ?></h3>
				<ul>
					<?php wp_list_pages('title_li='); ?>
				</ul>
			</div>
		<?php endif; ?>

	</div>
</div>