<?php
  get_header();
  if( have_posts() ) : while( have_posts() ) : the_post();

?>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/fancybox-common.css">
<style type="text/css" media="screen">
#map,#map_popup{
	height: 300px;
}	
</style>
<?php $lat = get_field('latitude');
$long = get_field('longitude'); ?>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA11CaxhVItmyBxye-PU715SZ-9c3fhV4A&callback=initMap"></script>
  <script>
var map, map1;
// Initialize and add the map
function initMap() {
  // The location of Uluru
  var uluru = {lat: <?php echo $lat; ?>, lng: <?php echo $long; ?>};
  // The map, centered at Uluru
  var map = new google.maps.Map(
  document.getElementById('map'), {zoom: 14, center: uluru, mapTypeId: 'satellite',mapTypeControl: false});

  var map1 = new google.maps.Map(
  document.getElementById('map_popup'), {zoom: 14, center: uluru, mapTypeId: 'satellite',mapTypeControl: false});
  // The marker, positioned at Uluru
  var marker = new google.maps.Marker({position: uluru, map: map});
  var marker1 = new google.maps.Marker({position: uluru, map: map1});
}
    </script>
 <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
 	<div class="inner-page-outer">
		<div class="large-container">
			<?php $lodge_site_url = od_normalize_url( get_field('site_url') ); ?>
                        <h1 class="large text-center"><?php if ( $lodge_site_url ) : ?><a href="<?php echo esc_url( $lodge_site_url ); ?>" target="_blank" rel="noopener"><?php the_title(); ?></a><?php else : ?><?php the_title(); ?><?php endif; ?></h1>	
			<?php 
			global $post;
			 $thePostID = $post->ID;
			$post_id = get_post($thePostID);
			$title = $post_id->post_title;
			//$t = str_replace(","," ",$title);
			$turl = str_replace("/"," ", $title);
			if($thePostID == 14343){
				$lodge_url = od_location_search_url( 'Île aux perroquets - canada' );
			} elseif($thePostID == 25475) {
          $lodge_url = site_url() . '/?s=' . rawurlencode( 'san diego' ) . '&sorting_option=by_tags';
      } else {
				  $lodge_url = od_location_search_url( $turl );
			}
			?>
			<div class="lodges-info aaa">

				<div class="row">
					<div class="col-lg-6">
						<h4>About</h4>
						<?php if(!empty(the_field('about'))){

							echo the_field('about');

						} ?>
					</div>
					<div class="col-lg-6">
						<?php if(!empty($lat)){ ?>
						<div class="oadges-map-image">
							<h3 class="desktop-show">
							<?php if(get_field('credit_url')): ?>
              <?php
                $credit_url = od_normalize_url( get_field('credit_url') );
              ?>
							<a href="<?php echo esc_url($credit_url); ?>" target="_blank">
							<?php endif; ?>
									<?php the_field('credit_name'); ?>
								</a>
							</h3>
							<div class="inner-image bird">
								<?php
								$lodge_img = get_field('lodges_image');
								if(!empty($lodge_img)){?> 
									<img src="<?php echo $lodge_img['url']; ?>" alt="<?php echo $lodge_img['alt']; ?>">
								<?php }
								?>
							
							</div>
							<div class="inner-image map">
								<!-- Button trigger modal -->
								<button type="button" class="" data-toggle="modal" data-target="#mappopup">	
									<div id="map"></div>
								</button>
							</div>
						</div>
						<?php } else { ?>
						<div class="oadges-map-image single-bird-show">	
							<div class="inner-image bird">
								<?php
								$lodge_img = get_field('lodges_image');
								if(!empty($lodge_img)){?> 
									<img src="<?php echo $lodge_img['url']; ?>" alt="<?php echo $lodge_img['alt']; ?>">
								<?php }
								?>
							
							</div>
							<h3 class="desktop-show">
							<?php if(get_field('credit_url')): ?>
								<a href="<?php echo esc_url( od_normalize_url( get_field('credit_url') ) ); ?>" target="_blank">
							<?php endif; ?>
									<?php the_field('credit_name'); ?>
								</a>
							</h3>
						</div>
						<?php } ?>
					</div>
					<!-- Modal -->
					<div class="modal fade" id="mappopup" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
					  <div class="modal-dialog modal-dialog-centered" role="document">
					    <div class="modal-content">					      
					      <div class="modal-body">
					      	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					          <span aria-hidden="true">&times;</span>
					        </button>
							<div id="map_popup"></div>
					      </div>
					    </div>
					  </div>
				</div>
			</div>


		<h4 class="birds-found-here">Birds found here</h4>
		<?php 
		 $pagename = $post->post_title;
		 $pid = $post->ID;
		 $pgname = str_replace("/"," ",$pagename);
		 $pname = str_replace("'", "%27",$pgname);
		 $name = strtolower($pname);
		 //$nm = htmlspecialchars($name);
     if($pid == 14314){
     $result = substr($name, 0, 4); 
     } else {
     $result = strtolower($name);  
     }
		 $result = substr($name, 0, 5);
		
		$birds_list = get_field('bird_list');
    $bird_list = array_reverse($birds_list);
    // print_r($bird_list);

    if( $bird_list ){
	?>
		<ul class="massonary">
		<?php 
		$i = 1;
        foreach( $bird_list as $bl ){

          $image = wp_get_attachment_image_src( get_post_thumbnail_id( $bl->ID ), 'single-post-thumbnail' ); 
          $iframedata = get_field('bird_sounds', $bl->ID );

            // Setup this post for WP functions (variable must be named $post).
            setup_postdata($bl); ?>
			
			<li class="country-list-outer" data-post-id="<?php echo $bl->ID; ?>">
			    	<div class="grid-item1" href="<?php echo $image[0]; ?>" data-fancybox="imageslodge" data-type="image">
			    		<!-- <a href="<?php echo $image[0]; ?>" data-fancybox="imageslodge" data-type="image"> -->
				    		<div class="image-outer-table">
					    		<div class="image">
					    			<img src="<?php echo $image[0]; ?>" alt="<?php echo $bl->post_title; ?>">
					    		</div>
					    	</div>
					    	<figcaption>
                                        <div class="countrydetails <?php //echo $lastclass; ?>">
						                     <h4><?php echo $bl->post_title; ?></h4>
						                     <?php /*<h3><?php echo "ID : " . $row->ID; ?></h3>*/ ?>
                                           <div class="custom-table">
                                            <div class="row">
                                              <div class="col-md-6">
                                                <?php 
                                                    $get_order = get_field('bird_family',$bl->ID);
                                                    if(!empty($get_order)){ 
                                                    $search_order = mb_strtolower($get_order);
                                                    $search_order_url = site_url() . '/?s=&birdfamily='.$search_order;
                                                  ?>
                                                    <h5>Order</h5>
                                                    <a href="<?php echo $search_order_url; ?>" class="whitebtn"><?php echo $search_order; ?></a>
                                                  <?php } ?>
                                              </div>
                                              <div class="col-md-6">
                                                  <?php 
                                                    $get_family = get_field('bfamily',$bl->ID);
                                                    if(!empty($get_family)){ 
                                                    $search_get_family = mb_strtolower($get_family);
                                                    $search_family_url = site_url() . '/?s=&family='.$search_get_family;
                                                  ?>
                                                    <h5>Family</h5>
                                                    <a href="<?php echo $search_family_url; ?>" class="whitebtn"><?php echo $search_get_family; ?></a>
                                                  <?php } ?>
                                              </div>
                                            </div>
                                            <div class="row">
                                              <div class="col-md-6">
                                                <h5>Genus <span>(Similar Species)</span>
                                                  <?php
                                                  $gettxgenus = get_field('bird_taxonomic_genus',$bl->ID);
                                                    if(!empty($gettxgenus)) { 
                                                    $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.strtolower($gettxgenus);
                                                  ?>
                                                  
                                                    <div class="specbtn">
                                                      <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo $gettxgenus; ?></a>
                                                    </div>
                                                  <?php } ?>
                                              </div>
                                              <?php if(!empty(get_field('bird_scientific_name',$bl->ID))) { ?>
                                                <div class="col-md-6">
                                                  <h5>Scientific Name</h5>
                                                  <h6><?php echo get_field('bird_scientific_name',$bl->ID); ?></h6>
                                                </div>
                                            <?php } ?>
                                            </div>
                                           </div>
                                            <ul>
                                              <?php
                                                /*
                                              <li>
                                                
                                                 if(!empty(get_field('bird_scientific_name',$row->ID))) { ?>
                                                    <h5>Scientific Name</h5>
                                                    <h6><?php echo get_field('bird_scientific_name',$row->ID); ?></h6>
                                                
                                                  <?php }
                                                    $gettxgenus = get_field('bird_taxonomic_genus',$row->ID);
                                                    if(!empty($gettxgenus)) { 
                                                    $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.strtolower($gettxgenus);
                                                  ?>
                                                  
                                                    <div class="specbtn">
                                                      <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo "Similar Species"; ?></a>
                                                    </div>
                                                  <?php } 
                                                   
                                              </li>
                                               */
                                                  ?>
                                                <?php
                                                    $get_cs = get_field('bird_conservation_status',$bl->ID);
                                                    if(!empty($get_cs)) { 
                                                    $search_cs = strtolower($get_cs);
                                                    $search_cs_url = site_url() . '/?s=&conservancy='.$search_cs;
                                                ?>
                                                        <li>
                                                            <h5>Conservation Status</h5>
                                                            <a class="whitebtn" href="<?php echo $search_cs_url; ?>" target="_self"><?php echo $get_cs; ?></a>
                                                        </li>
                                              <?php } ?>
                                            </ul>
                                            <div class="border-bottom-bird">
                                                <div class="row">
                                            <?php 
                                                $scurl = '';
                                                $postid = '';
                                                $terms = wp_get_post_terms($postid, 'cp_birds_country');
                                                if( !empty( $terms ) && !is_wp_error( $terms ) ) {
                                                    $taxonomy = $terms[0]->name;
                                                    $taxonomyid = $terms[0]->term_id;
                                                    $scurl = site_url() . '/?s=&country='.strtolower($taxonomyid);
                                                    ?>  
                                                    <div class="col-md-6 last-child">
                                                        <h5>Country</h5>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php echo $taxonomy; ?></a>
                                                            <a href="<?php echo site_url().'/countries/'; ?>" class="whitebtn">
                                                            View more Countries
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                }
                                            ?>
                                            <?php if (!empty(get_field('state',$bl->ID))){ ?>
                                                    <div class="col-md-6">
                                                        <h5>State</h5>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php the_field('state',$bl->ID); ?></a>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                }
                                            ?>
                                            </div>
                                        </div>
                                            <?php if ((!empty(get_field('bird_gender',$bl->ID))) || (!empty(get_field('bird_age',$bl->ID)))){ ?>
                                            <div class="border-bottom-bird">
                                              <div class="row">
                                                
                                                
                                                  <?php if(!empty(get_field('bird_gender',$bl->ID))){ ?>
                                                   <div class="col-md-6 last-child">
                                                        <h5>Gender </h5>
                                                        <h6><?php echo get_field('bird_gender',$bl->ID); ?></h6>
                                                    </div>
                                              <?php } ?>
                                                

                                                  <?php if(!empty(get_field('bird_age',$bl->ID))) { ?>
                                                  <div class="col-md-6">
                                                    <h5>Age</h5>
                                                    <h6><?php echo get_field('bird_age',$bl->ID); ?></h6>
                                                  </div>
                                              <?php } ?>
                                                
                                              </div>
                                            </div>
                                            <?php } ?>
                                            <ul>
                                              <?php /*
                                              <?php if(!empty(get_field('bird_age',$row->ID))) { ?>
                      											    <li>
                      											        <h5>Age</h5>
                      											        <h6><?php echo get_field('bird_age',$row->ID); ?></h6>
                      											    </li>
                                              <?php } 
                                              */ ?>
                                              <?php
                                                  $get_vc = get_field('bird_visual_country',$bl->ID);
                                                  if(!empty($get_vc)){ 
                                                  $search_vc = strtolower($get_vc);
                                                  $search_vc_url = site_url() . '/?s=&visualcategory='.$search_vc;
                                             ?>
                    											    <li>
                    											        <h5>Visual Category</h5>
                    											        <a class="whitebtn" href="<?php echo $search_vc_url; ?>" target="_self"><?php echo $get_vc; ?></a>
                    											    </li>
                                              <?php }
                                                $getloc = get_field('bird_locations_multi',$bl->ID);
                                                if(!empty($getloc) && isset($getloc)) { ?>
                                                <li>
                                                  <h5>Birding Sites and Lodges</h5>
                                                  <?php 
                                                    if($getloc != ''){
                                                      foreach ($getloc as $post) {
                                                       // Check if POST_TITLE is set before echoing
                                                       if (isset($post->post_title)) {
                                                        $getlocurlMulti = od_location_search_url( $post->post_title );
                                                        ?>
                                                        <a class="whitebtn" href="<?php echo $getlocurlMulti ?>" target="_self">
                                                            <?php echo $post->post_title; ?>
                                                        </a>
                                                        <?php
                                                    }
                                                    if(!empty($post) && !isset($post->post_title)) {
                                                        $get_title_lodges = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($post) AND post_status = 'publish'", ARRAY_N);
                                                        $lodges_postidtit = array_column($get_title_lodges, 0);
                                                        $getlocurlMulti = od_location_search_url( $lodges_postidtit[0] );
                                                        ?>
                                                        <a class="whitebtn" href="<?php echo $getlocurlMulti; ?>" target="_self">
                                                            <?php echo $lodges_postidtit[0]; ?>
                                                        </a>
                                                        <?php
                                                    }
                                                      }
                                                    }
                                                  ?>
                                                </li>
                                              <?php } ?>
                                              <?php 
                                                /*  $get_order = get_field('bird_family',$row->ID);
                                                  if(!empty($get_order)){ 
                                                  $search_order = strtolower($get_order);
                                                  $search_order_url = site_url() . '/?s=&birdfamily='.$search_order;
                                                  ?>
                                                <li>
                      											        <h5>Order</h5>
                      											        <a class="whitebtn" href="<?php echo $search_order_url; ?>" ><?php echo $get_order; ?></a>
                                                </li>
                                              <?php } */
                                                $get_activity = get_field('bird_activity',$bl->ID);
                                                if(!empty($get_activity) && isset($get_activity)) { ?>
                                                      <li>
                                                          <h5>Activity</h5>
                                                          <?php
                                                              if($get_activity != ''){
                                                                $explodeactivity = explode(",",$get_activity);
                                                                foreach ($explodeactivity as  $activityrow) {
                                                                    $search_activityurl = site_url() . '/?s=&activity='.$activityrow;
                                                          ?>
                                                                  <a class="whitebtn" href="<?php echo $search_activityurl; ?>" >
                                                                    <?php echo $activityrow; ?>
                                                                </a>
                                                          <?php } } ?>
                                                      </li>
                                              <?php } ?>
                      											</ul>
                                            <?php 
                                                //if(!empty($get_activity) && isset($get_activity)) { ?>
                                                    <div class="custom-table new-cat">
                                                       <div class="row">
                                                            <?php
                                                              if( have_rows('categories', $bl->ID) ):
                                                                  while ( have_rows('categories', $bl->ID) ) : the_row();
                                                                      if( get_row_layout() == 'category' ): 
                                                                          $name = get_sub_field('name');
                                                                          $value = get_sub_field('value'); ?>
                                                                          <div class="col-md-6">
                                                                              <h5><?php echo $name; ?></h5>
                                                                              <a class="whitebtn" href="<?php echo $search_activityurl; ?>" ><?php echo $value; ?></a>
                                                                          </div>
                                                                     <?php
                                                                      endif;                                      
                                                                  endwhile;
                                                              else :                                      
                                                              endif;
                                                            ?>
                                                        </div>
                                                    </div>
                                              <?php //} ?>
                                            <?php if(!empty($iframedata)){?>
                                            <h5>BIRD CALLS</h5>
                                              <div class="iframeappend">
                                                  <?php $removelastcomma = rtrim($iframedata, ','); ?>
                                                  <input type="hidden" id="custId" name="custId" value="<?php echo $removelastcomma; ?>">
                                                  <img class="iframeloader" src="<?php echo get_template_directory_uri(). '/images/loader.svg'; ?>" alt="Page Loader">
                                              </div>
                                            <?php } ?>
										                    </div>
                                        </figcaption>
					    	<div class="image-title">
					    		<?php  echo get_the_title($bl->ID);?>
					    		 <?php if( !empty($iframedata) ) { ?>					    
					    		<div class="music-symbol">
	                                <img src="<?php echo $HOME_URL; ?>/wp-content/uploads/2019/08/musical-notes-symbols-2.png" alt="music">            
	                            </div>
	                            <?php } ?>
					    	</div>

				    	<!-- </a> -->
			    	</div>
			    </li>


		<?php $i++; } ?>
	</ul>
	<?php } else { 
		echo "NO BIRDS FOUND";
	} ?>
		 </div>
	</div>
</div>
<div class="large-container">
	 <div class="view-another">
        <div class="pull-left">
          <a href="<?php echo $HOME_URL; ?>/birding-sites-and-lodges/">
            <?php echo "Visit another site/lodge" ?>
          </a>
        </div>
        <div class="pull-right">
          <a href="<?php echo $lodge_url; ?>" target="_self" title="<?php echo $lodge_url; ?>">
            <?php echo "See all birds from this site/lodge" ?>
          </a>
        </div>
        <input type="hidden" id="taxonomy_url" name="taxonomy_url" value="<?php echo !empty($cur_country_name) ? $cur_country_name : '' ; ?>">
        <!-- <input type="hidden" id="taxonomy_url" name="taxonomy_url" value="<?php //echo $term_name; ?>"> -->
    </div>
</div>
<?php endwhile; else: ?>
  
  <h2 class="error"><?php _e( 'Not Found.','theme' ); ?></h2>
  <p class="error">Sorry, but you are looking for something that isn't here.</p>
  

<?php
  endif; wp_reset_query(); wp_reset_postdata();
  get_footer();
?>