<?php
	if (!defined('ABSPATH')) exit;
	get_header();
?>
<?php

/*

 *  This is Standard Post Format Template

 */

?>

<div class="blog-container main-content inner-page-outer">
	<?php
	/* The posts page has no visible page heading, so the document had no H1.
	   Emit one for outline and accessibility; sr-only keeps the visual
	   design unchanged. */
	$od_blog_page_id = (int) get_option( 'page_for_posts' );
	$od_blog_heading = $od_blog_page_id ? get_the_title( $od_blog_page_id ) : __( 'Blog', 'owen' );
	?>
	<h1 class="sr-only"><?php echo esc_html( $od_blog_heading ); ?></h1>
	<div class="row">
		<?php if( have_posts() ) : while( have_posts() ) : the_post(); ?>
				<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 post-content-container clearfix">
					<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
						<a href="<?php the_permalink(); ?>" class="outer-link">
							<?php if(has_post_thumbnail() ) { ?>
								<?php $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' ); ?>
	  							<div class="post-featured">
									<img src="<?php echo $image[0]; ?>" alt="<?php echo $post->post_title; ?>" />
								</div>
    						<?php } ?>
    						<div class="post-info clearfix">
							    <div class="post-title-outer">
	    							<div class="post-date">
	    								<span class="postday"><?php the_time( 'j' ); ?></span>
	    								<span class="postmonth"><?php the_time( 'F' ); ?></span>
	    								<span class="postyear"><?php the_time( 'Y' ); ?></span>
	    							</div>
	    							<div class="post-title">
	    								<h2><?php the_title(); ?></h2>
	    							</div>
	    						</div>
								<?php if(is_sticky() ) { ?> <span class="post-sticky">Sticky</span>  <?php } ?>
							</div>
							<div class="excerpt_block">
								<div class="story-content clearfix">
									<?php 
										if( has_excerpt() ) { 
											//echo excerpt('40');
								    	}else{
								   //  		$stip_content = wp_strip_all_tags(get_the_content());
											// echo $stip_content;
											
											$content = get_the_content();
											pr($content);
										    $trimmed_content = wp_trim_words( $content, 50, NULL );
										   // echo $trimmed_content;
								    	}
							    	?>							
									<div class="clear"></div>
								</div>
							</div>
						</a>
						<!-- <div class="post-readmore-button">
						    <a href="<?php the_permalink(); ?>" class="yellow-btn">Read More</a>
						</div> -->
						
					</div>
				</div>
			
			<?php endwhile;	?>
			
			<div class="blog-navigation row">
				<?php
					the_posts_pagination( array(
						'prev_text' => __( '&#xf104;', 'theme' ),
						'next_text' => __( '&#xf105;', 'theme' ),
					) );
					
				?>
			</div>
			<?php else: ?>
				<h2 class="error"><?php _e( 'Not Found.','theme' ); ?></h2>
				<p class="error">Sorry, but you are looking for something that isn't here.</p>
			<?php endif; wp_reset_query(); wp_reset_postdata(); ?>
	</div>
</div>
<?php get_footer(); ?>