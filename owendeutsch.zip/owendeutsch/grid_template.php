<?php
/* Template Name: 5 Column Grid Template */
get_header();


$sort = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'newest';

$args = array(
    'post_type'         => 'cp_birds',
    'posts_per_page'    => 150,
    'paged'             => $paged,
);

// Add sorting logic
switch ($sort) {
    case 'name-asc':
        $args['orderby'] = 'title';
        $args['order'] = 'ASC';
        break;
    case 'name-desc':
        $args['orderby'] = 'title';
        $args['order'] = 'DESC';
        break;
    case 'oldest':
        $args['orderby'] = 'date';
        $args['order'] = 'ASC';
        break;
    case 'newest':
    default:
        $args['orderby'] = 'date';
        $args['order'] = 'DESC';
        break;
}

// Add taxonomy query if applicable
if (function_exists('get_field')) {
    $all_fields = get_field('all_birds_tags');
    if ($all_fields) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'cp_birds_tag',
                'field'    => 'term_id',
                'terms'    => $all_fields
            )
        );
    }
}

$query = new WP_Query($args);
?>

<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri(); ?>/css/fancybox-common.css">
<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
    <div class="inner-page-outer gallery-inner" bis_skin_checked="1">
        <div class="large-container">
            <h1 class="large text-center"><?php the_title(); ?></h1>
            <div class="color-white padding-bottom text-center">
                <?php the_content(); ?>
            </div>
            <?php
// Check if the 'sort' parameter is set in the URL
$sort = isset($_GET['sort']) ? sanitize_text_field($_GET['sort']) : 'newest'; // Default to 'newest'
$sortLabels = [
    'name-asc' => 'Bird Name A-Z',
    'name-desc' => 'Bird Name Z-A',
    'oldest' => 'Oldest to Newest',
    'newest' => 'Newest to Oldest',
];
?>
<div class="gallery-sortby-filter-col">
    <div class="sortby-filter dropdown">
        <div class="custom-dropdown" data-toggle="dropdown">
            <div>
                <!-- Default to "Sort By" if no sort parameter is present -->
                <span id="sortbySelected"><?php echo isset($_GET['sort']) ? $sortLabels[$sort] : 'Sort By'; ?></span>
            </div>
        </div>
        <ul class="dropdown-menu">
            <!-- Remove "Sort By" from the dropdown menu -->
            <li><a href="javascript:void(0);" data-sort="name-asc">Bird Name A-Z</a></li>
            <li><a href="javascript:void(0);" data-sort="name-desc">Bird Name Z-A</a></li>
            <li><a href="javascript:void(0);" data-sort="oldest">Oldest to Newest</a></li>
            <li><a href="javascript:void(0);" data-sort="newest">Newest to Oldest</a></li>
        </ul>
    </div>
</div>

            <?php if ($query->have_posts()) { ?>
                <ul class="massonary">
                    <?php
                    while ($query->have_posts()) {
                        $query->the_post();
                    ?>
                        <li class="country-list-outer" data-post-id="<?php the_ID(); ?>">
                            <div class="grid-item1"  data-fancybox="imagescountry" href="<?php echo   get_the_post_thumbnail_url( $post->ID, 'full' );?>" data-type="image" >
                            <div class="image-title">
                                            <?php echo get_the_title(); ?>
                            </div>  
                                <div class="image-outer-table">
                            
                                    <div class="image image-container">
                                        <?php if (has_post_thumbnail()) { ?>
                                            <?php $gt_thumb = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' ); ?>
                                            <img class="img-fluid" src="<?php echo esc_url( $gt_thumb[0] ); ?>" alt="<?php echo esc_attr( get_the_title() ); ?>"<?php if ( ! empty( $gt_thumb[1] ) ) : ?> width="<?php echo (int) $gt_thumb[1]; ?>" height="<?php echo (int) $gt_thumb[2]; ?>"<?php endif; ?>>
                                        <?php } ?>
                                    </div>
                                </div>  
                                  
                                <figcaption>
                                    <div class="countrydetails">
                                        <h4><?php the_title(); ?></h4>
                                        <div class="custom-table">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <?php
                                                    $get_order = get_field('bird_family', $post->ID);
                                                    if (!empty($get_order)) {
                                                        $search_order = mb_strtolower($get_order);
                                                        $search_order_url = site_url() . '/?s=&birdfamily=' . od_search_param($search_order);
                                                    ?>
                                                    <h5>Order</h5>
                                                    <a href="<?php echo $search_order_url; ?>" class="whitebtn"><?php echo $search_order; ?></a>
                                                    <?php
                                                    }
                                                    ?>
                                                </div>
                                                <div class="col-md-6">
                                                    <?php
                                                    $get_family = get_field('bfamily', $post->ID);
                                                    
                                                    if (!empty($get_family)) {
                                                        $search_get_family = mb_strtolower($get_family);
                                                        $search_family_url = site_url() . '/?s=&family=' . od_search_param($search_get_family);
                                                    ?>
                                                    <h5>Family</h5>
                                                    <a href="<?php echo $search_family_url; ?>" class="whitebtn"><?php echo $search_get_family; ?></a>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h5>Genus <span>(Similar Species)</span>
                                                        <?php
                                                        $gettxgenus = get_field('bird_taxonomic_genus', $post->ID);
                                                        if (!empty($gettxgenus)) {
                                                            $gettxgenusurl = site_url() . '/?s=&taxonomicgenus=' . od_search_param($gettxgenus);
                                                        ?>

                                                            <div class="specbtn">
                                                                <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo $gettxgenus; ?></a>
                                                            </div>
                                                        <?php } ?>
                                                </div>
                                                <?php if (!empty(get_field('bird_scientific_name', $post->ID))) { ?>
                                                    <div class="col-md-6">
                                                        <h5>Scientific Name</h5>
                                                        <h6><?php echo get_field('bird_scientific_name', $post->ID); ?></h6>
                                                    </div>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <ul>
                                            <?php
                                            $get_cs = get_field('bird_conservation_status', $post->ID);
                                            if (!empty($get_cs)) {
                                                $search_cs = strtolower($get_cs);
                                                $search_cs_url = site_url() . '/?s=&conservancy=' . od_search_param($search_cs);
                                            ?>
                                                <li>
                                                    <h5>Conservation Status</h5>
                                                    <a class="whitebtn" href="<?php echo $search_cs_url; ?>" target="_self"><?php echo $get_cs; ?></a>
                                                </li>
                                            <?php } ?>
                                        </ul>
                                        <div class="border-bottom-bird">
                                            <div class="row">
                                                <?php
                                                $terms = wp_get_post_terms($post->ID, 'cp_birds_country');
                                                if (!empty($terms) && !is_wp_error($terms)) {
                                                    $taxonomy = $terms[0]->name;
                                                    $taxonomyid = $terms[0]->term_id;
                                                    $scurl = site_url() . '/?s=&country=' . od_search_param($taxonomyid);
                                                ?>
                                                    <div class="col-md-6 last-child">
                                                        <h5>Country</h5>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php echo $taxonomy; ?></a>
                                                            <a href="<?php echo site_url() . '/countries/'; ?>" class="whitebtn">
                                                                View more Countries
                                                            </a>
                                                        </div>
                                                    </div>
                                                <?php
                                                }
                                                ?>
                                                
                                                    <div class="col-md-6">
                                                        <h5>State</h5>
                                                        <?php if (!empty(get_field('state', $post->ID))) { ?>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php the_field('state', $post->ID); ?></a>
                                                        </div>
                                                        <?php } ?>
                                                    </div>
                                                
                                            </div>
                                        </div>
                                        <?php if ((!empty(get_field('bird_gender', $post->ID))) || (!empty(get_field('bird_age', $post->ID)))) { ?>
                                            <div class="border-bottom-bird">
                                                <div class="row">
                                                    <?php if (!empty(get_field('bird_gender', $post->ID))) { ?>
                                                        <div class="col-md-6 last-child">
                                                            <h5>Gender </h5>
                                                            <h6><?php echo get_field('bird_gender', $post->ID); ?></h6>
                                                        </div>
                                                    <?php } ?>
                                                    <?php if (!empty(get_field('bird_age', $post->ID))) { ?>
                                                        <div class="col-md-6">
                                                            <h5>Age</h5>
                                                            <h6><?php echo get_field('bird_age', $post->ID); ?></h6>
                                                        </div>
                                                    <?php } ?>

                                                </div>
                                            </div>
                                        <?php } ?>
                                        <ul>
                                            <?php
                                            $get_vc = get_field('bird_visual_country', $post->ID);
                                            if (!empty($get_vc)) {
                                                $search_vc = strtolower($get_vc);
                                                $search_vc_url = site_url() . '/?s=&visualcategory=' . od_search_param($search_vc);
                                            ?>
                                                <li>
                                                    <h5>Visual Category</h5>
                                                    <a class="whitebtn" href="<?php echo $search_vc_url; ?>" target="_self"><?php echo $get_vc; ?></a>
                                                </li>
                                            <?php }
                                            
                                            $getloc = get_field('bird_locations_multi', $post->ID);
                                            if (!empty($getloc) && isset($getloc)) { ?>
                                                <li>
                                                    <h5>Birding Sites and Lodges</h5>
                                                    <?php
                                                    if ($getloc != '') {
                                                        foreach ($getloc as $posts) {
                                                            if (isset($posts->post_title)) {
                                                                $getlocurlMulti = od_location_search_url( $posts->post_title );
                                                                ?>
                                                                <a class="whitebtn" href="<?php echo $getlocurlMulti ?>" target="_self">
                                                                    <?php echo $posts->post_title; ?>
                                                                </a>
                                                                <?php
                                                            }
                                                            if(!empty($posts) && !isset($posts->post_title)) {
                                                                $get_title_lodges = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($posts) AND post_status = 'publish'", ARRAY_N);
                                                                $lodges_postidtit = array_column($get_title_lodges, 0);
                                                                $getlocurlMulti = od_location_search_url( $lodges_postidtit[0] );
                                                                ?>
                                                                <a class="whitebtn" href="<?php echo $getlocurlMulti; ?>" target="_self">
                                                                    <?php echo $lodges_postidtit[0]; ?>
                                                                </a>
                                                                <?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                </li>
                                            <?php } ?>
                                            <?php
                                            $get_activity = get_field('bird_activity', $post->ID);
                                            
                                            if (!empty($get_activity) && isset($get_activity)) { ?>
                                                <li>
                                                    <h5>Activity</h5>
                                                    <?php
                                                    if ($get_activity != '') {
                                                        $explodeactivity = explode(",", $get_activity);
                                                        foreach ($explodeactivity as  $activityrow) {
                                                            $search_activityurl = site_url() . '/?s=&activity=' . od_search_param($activityrow);
                                                    ?>
                                                            <a class="whitebtn" href="<?php echo $search_activityurl; ?>">
                                                                <?php echo $activityrow; ?>
                                                            </a>
                                                    <?php }
                                                    } ?>
                                                </li>
                                            <?php } ?>
                                        </ul>
                                        <div class="custom-table new-cat">
                                            <div class="row">
                                                <?php
                                                if (have_rows('categories', $post->ID)) :
                                                    while (have_rows('categories', $post->ID)) : the_row();
                                                        if (get_row_layout() == 'category') :
                                                            $name = get_sub_field('name');
                                                            $value = get_sub_field('value'); ?>
                                                            <div class="col-md-6">
                                                                <h5><?php echo $name; ?></h5>
                                                                <a class="whitebtn" href="<?php echo $search_activityurl; ?>"><?php echo $value; ?></a>
                                                            </div>
                                                <?php
                                                        endif;
                                                    endwhile;
                                                else :
                                                endif;
                                                ?>
                                            </div>
                                        </div>
                                        
                                        <?php
                                        $iframedata = get_field('bird_sounds', $post->ID);
                                        $datataArray = explode(",", $iframedata);
                                        ?>
                                        <?php  if (!empty($datataArray)) { ?>
                                            <h5>BIRD CALLS</h5>
                                            <?php
                                            foreach ($datataArray as $framedata) {
                                                if(!empty($framedata)){
                                                    $framedata = od_cleanSpaces($framedata);
                                            ?>
                                                <!-- <iframe src='https://www.xeno-canto.org/<?= $framedata ?>/embed?simple=1&darkbg=1' height='110' width='100%' frameborder='0' scrolling='no'></iframe> -->
                                            <?php
                                             }
                                         }
                                             ?>
                                        <?php } ?>

                                        <?php                                             
                                        if (!empty($iframedata)) {  ?>
                                                <div class="iframeappend">
                                                <?php $removelastcomma = rtrim($iframedata, ','); ?>
                                                <input type="hidden" id="custId" name="custId" value="<?php echo $removelastcomma; ?>">
                                                <img class="iframeloader" src="<?php echo get_template_directory_uri() . '/images/loader.svg'; ?>" alt="Page Loader">
                                                </div>
                                        <?php  } ?>
                                    </div>
                                </figcaption>
                            </div>
                        </li>
                    <?php } ?>
                </ul>
            <?php } wp_reset_postdata(); wp_reset_query(); ?>
            <div class="large-container row">
                <div class="birds-template-pagination text-center">
                    <div class="col-sm-12">
                        <?php  echo paginate_links(array('total' => $query->max_num_pages)); ?>
                    </div>
                </div>
            </div>
            <br/>
        </div>
    </div>
</div>

<?php

?>

<?php
get_footer();
?>
<style>
    .country-list-outer{
        min-height: 250px;
        max-height: 250px;
    }
    .country-list-outer .image-title{
        text-align: left !important;
        padding-right: 0px !important
    }
    .country-list-outer .image-title{
        position:absolute !important;
        display: none;
    }
    .country-list-outer:hover .image-title{
        display: block;
    }
    .gallery-sortby-filter-col{
        width: 25% !important;
        padding: 30px 0px;
    }

img{
  pointer-events: none !important;
}
</style>
<script type='text/javascript' src="<?php echo get_template_directory_uri(); ?>/js/hilitor.js"></script>
<script>
window.addEventListener("DOMContentLoaded", function(e) {
    var myHilitor2 = new Hilitor("playground");
    //myHilitor2.setEndRegExp('^[^\\w-]+|[^\\w]+$');
    //myHilitor2.setBreakRegExp(new RegExp('[^\\w\' - ]+', "g"));
    myHilitor2.setMatchType("left");
    var searchterm = jQuery("#searchfocus").val();
    myHilitor2.apply(searchterm);
}, false);
</script>
<script type="text/javascript">
    var urlsite = "<?php echo site_url(); ?>";
    jQuery(document).ready(function ($) {
        jQuery.noConflict();

        var maximumpages    = "<?php echo $wp_query->max_num_pages; ?>";
        var getcurrentpage  = "<?php echo get_query_var('paged'); ?>";
        var perpagepost    = "<?php echo $wp_query->post_count; ?>";
        var cpagelink       = "<?php echo get_pagenum_link(strip_tags((get_query_var('paged'))+1),false); ?>";
        var firstpagelink   = "<?php echo get_pagenum_link(strip_tags((get_query_var('paged'))),false); ?>";
        var searchparameters  = window.location.search;
        var str         = window.location.hash;
        var lastSlash   = str.lastIndexOf("-");
        jQuery('[data-fancybox="imagescountry"]').fancybox({
            loop: false,
            baseClass: "fancybox-search-layout",
            infobar: false,
            touch : true,
            wheel:false,
            clickSlide:false,
            clickOutside:false,
            //hash : false,
            buttons: ["close", "slideShow","fullScreen"],
            animationEffect: "fade",
            transitionEffect: "fade",
            preventCaptionOverlap: false,
            idleTime: false,
            gutter: 0,
            iframe : {
                preload: false
            },
            // Customize caption area
            caption : function( instance, item ) {
               return $(this).find('figcaption').html();
            },
            beforeLoad: function(instance, current) {
                
            },
            afterLoad: function(instance, current) {
            	
            },
            beforeShow: function( instance, current ) {
            },
            afterShow: function( instance, current ) {
                var a = $(".fancybox-container").contents().find( ".fancybox-caption").find('.countrydetails').find("h4").attr("data-value");
                //alert(a);
                jQuery("#cono_link").remove();
                jQuery("head").append('<link rel="canonical" id="cono_link" href="'+a+'" >');
                
                
                var currentDivNo = instance.currIndex;
                /*Next logic*/
                var gallerySize = instance.group.length;

                if(parseInt(getcurrentpage) == 0  && parseInt(maximumpages) == 1 && (instance.currIndex == parseInt(gallerySize) - 1)){
                    // jQuery('.fancybox-navigation').find(".fancybox-button--arrow_right").attr( "disabled",true);
                }else{
                    if((parseInt(getcurrentpage) == parseInt(maximumpages) && (instance.currIndex == parseInt(perpagepost) - 1))){
                        // $(".customnextbtn").remove();
                        // jQuery('.fancybox-navigation').find(".fancybox-button--arrow_right").attr( "disabled",true );
                    }else
                    {
                        jQuery('.fancybox-navigation').find(".fancybox-button--arrow_right").attr( "disabled",false );
                    }
                    if ((instance.currIndex == parseInt(gallerySize) - 1)) {
                        // console.log("reached");
                        $("button.fancybox-button.fancybox-button--arrow_right>div").addClass('FancyLastImage');
                        $("button.fancybox-button.fancybox-button--arrow_right").attr("disabled", true);
                        // console.log("Disabled attribute added");
                        jQuery(".FancyLastImage").parents(".fancybox-navigation").append("<button class='customnextbtn'>NEXT Button</button>");
                        jQuery(".customnextbtn").on('click', function(){
                            if((parseInt(getcurrentpage)==0)&&(parseInt(instance.currIndex) == 149)&&((parseInt(instance.currIndex))==parseInt(gallerySize)-1)) {
                                jQuery(".loader-icon").show();
                                window.location.href = urlsite+'/birds-gallery'+'/page/2/'+"#imagescountry-1";
                            } else if ((parseInt(getcurrentpage)>=2)&&(parseInt(instance.currIndex)==149) &&((parseInt(instance.currIndex)==(parseInt(gallerySize)-1)))) {
                                jQuery(".loader-icon").show();
                                window.location.href = cpagelink+"#imagescountry-1";
                            }else{
                                if(parseInt(getcurrentpage) < parseInt(maximumpages)){
                                    // window.location.href = cpagelink+"#search-gallery-1";
                                }else{
                                    $(".customnextbtn").remove();
                                }
                            }

                        });
                    }else{
                        $(".customnextbtn").remove();
                        $("button.fancybox-button.fancybox-button--arrow_right>div").removeClass('FancyLastImage');
                    }
                }
                /*Prev Logic*/
                if ((parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0)){
                    $("button.fancybox-button.fancybox-button--arrow_left>div").addClass('FancyFirstImage');
                    $("button.fancybox-button.fancybox-button--arrow_left").removeAttr("disabled");
                    var prevpagelink = "<?php echo get_pagenum_link(strip_tags((get_query_var('paged'))-1),false); ?>";
                    jQuery(".FancyFirstImage").parents(".fancybox-navigation").append("<button class='customprevbtn'>Prev Button</button>");
                    jQuery(".customprevbtn").on('click', function(){
                        if((parseInt(getcurrentpage)!=0)&&(parseInt(getcurrentpage)<=2)&&(parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0)){
                            jQuery(".loader-icon").show();
                            window.location.href = urlsite+'/birds-gallery/'+"#imagescountry-150"
                        }else if((parseInt(getcurrentpage)>2)&&((parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0))){
                            jQuery(".loader-icon").show();
                            window.location.href = prevpagelink+"#imagescountry-150";
                        }else{
                            $(".customnextbtn").remove();
                        }
                    });

                } else {
                    $(".customprevbtn").remove();
                    $("button.fancybox-button.fancybox-button--arrow_left>div").removeClass('FancyFirstImage');
                }
                
                /*Iframe Logic Load After Fancybox Load */
                var iframestr   =  $(".grid-item1:eq("+currentDivNo+")").find('#custId').val();
                if((typeof(iframestr) != 'undefined') &&(iframestr) && (iframestr !== null) && (iframestr !== '')){
                    var ifrmaesplit = iframestr.split(',');
                    var ihtml = '';
                    for(var i = 0; i < ifrmaesplit.length; i++) {
                       // Trim the excess whitespace.
                        ifrmaesplit[i] = ifrmaesplit[i].replace(/^\s*/, "").replace(/\s*$/, "");
                        // Add additional code here, such as:
                        ihtml +="<iframe src='https://www.xeno-canto.org/"+ifrmaesplit[i]+"/embed?simple=1&darkbg=1' height='110' width='100%' frameborder='0' scrolling='no'></iframe>";
                    }
                    $(".fancybox-container").contents().find( ".fancybox-caption").find('.countrydetails').find(".iframeappend" ).append(ihtml);
                    $(".fancybox-caption .iframeappend iframe").load(function(){
                        $(".iframeloader").hide();
                    });
                }

                /*Key Press Events*/
                    // jQuery(document).on("keydown", function (e) {
                    //     console.log('inin');
                    //     var code = e.which || e.keyCode;
                    //     if (code >= 37 && code <= 40) {
                    //         console.log("press"+code);

                    //         if (e.keyCode == '37') {
                    //         /* left arrow */ //alert('left arrow');
                    //             if (parseInt(getcurrentpage)>0){
                    //                // jQuery('.fancybox-navigation').find(".customprevbtn").trigger( "click" );
                    //             }
                    //         }
                    //         if (e.keyCode == '39') {
                    //         /*right  arrow*/
                    //             if ((instance.currIndex == parseInt(gallerySize) - 1)) { 
                    //                 jQuery('.fancybox-navigation').find(".customnextbtn").trigger( "click" );
                    //             }
                            
                    //         }
                    //         if (e.keyCode == '38') {
                    //         /* up arrow */
                    //             if ((parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0)){
                    //                // jQuery('.fancybox-navigation').find(".customprevbtn").trigger( "click" );
                    //             }
                    //         }
                    //         if (e.keyCode == '40') {
                    //         /*down arrow*/
                    //         if ((instance.currIndex == parseInt(gallerySize) - 1)) {
                    //             jQuery('.fancybox-navigation').find(".customnextbtn").trigger( "click" );
                    //         }
                    //     }
                    //     }
                    
                    // });
                // } //main else close
            },
        });
    });
</script>




<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sortLinks = document.querySelectorAll('.sortby-filter .dropdown-menu a');
        const sortbySelected = document.getElementById('sortbySelected');

        sortLinks.forEach(link => {
            link.addEventListener('click', function (e) {
                e.preventDefault();
                const sortValue = this.getAttribute('data-sort');
                sortbySelected.textContent = this.textContent;

                // Reload the page with the selected sorting parameter
                const url = new URL(window.location.href);
                url.searchParams.set('sort', sortValue);
                window.location.href = url.toString();
            });
        });

        // Set "Sort By" as the default selected option if no sort parameter is present
        const urlParams = new URLSearchParams(window.location.search);
        if (!urlParams.has('sort')) {
            sortbySelected.textContent = 'Sort By'; // Update the displayed text
        }
    });
</script>