<?php

	get_header();
	if( have_posts() ) : while( have_posts() ) : the_post();
?>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">   
		<div class="container">

			<?php the_title( '<h1 class="page-title">', '</h1>' ); ?>

			<div class="row">
				<div class="col-xs-12 col-sm-8">          
					<?php if(has_post_thumbnail() ) : ?>
						<div class="post-image">
							<?php the_post_thumbnail(); ?>
						</div>
					<?php endif; ?>
					<div class="story-content clearfix">
						<?php the_content(); ?>
					</div>
				</div>
				<?php // get_sidebar(); ?>
			</div>
		
		</div>
	</div>
<?php
	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
	get_footer();
?>