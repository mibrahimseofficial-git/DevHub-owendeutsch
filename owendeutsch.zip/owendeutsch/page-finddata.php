<?php

// Template Name:finddata

?> 

<h1>All Records</h1>
<?php



    // function get_species_count_by_name ($name) {
    //     global $wpdb;
    //     $Warbler_arr = array();
    //     $query_3 = "SELECT * FROM `wp_posts` WHERE `post_title` LIKE '%".$name."%' AND `post_type` LIKE 'cp_birds'";
    //     $categories_count2 = $wpdb->get_results($query_3);
    //     // $result2 = count($categories_count2);
    //     echo "<p>How many total species of <b>".$name."s</b> are on my web site?</p>";
    //     foreach ($categories_count2 as $key => $categories_count) {
    //         $b_id = $categories_count->ID;
    //         $genes_value = get_post_meta( $b_id, 'bird_taxonomic_genus' ,true );
    //         if ( ! in_array($genes_value, $Warbler_arr) ) {
    //             $Warbler_arr[] = $genes_value;
    //         }
    //     }
    //     // return count($Warbler_arr);
    //     return "Total species: ".count($Warbler_arr)." Total birds: ".count($categories_count2);
    // }

    function get_species_by_tag ($name) {
        echo "<p>How many total species of <b>".$name."s</b> are on my web site?</p>";
        $species_arr = array();
        $query = new WP_Query( 'post_type=cp_birds&posts_per_page=-1&cp_birds_tag='.$name );
        if ($query->have_posts()) {
            while ( $query->have_posts() ) : $query->the_post();
                $post_id        = get_the_ID();
                $genes_value    = get_post_meta( $post_id, 'bird_taxonomic_genus' ,true );
                if ( ! in_array($genes_value, $species_arr) ) {
                    $species_arr[] = $genes_value;
                }
            endwhile;
        }
        return "Total species: ".count($species_arr)." Total birds: ".$query->post_count;
        wp_reset_postdata();
    }

    // Question #1
    // Is there an easy way to determine how many total species of birds are on my web site?
    $bird_taxonomic_genus = $taxonomy_genus = get_meta_values( 'bird_taxonomic_genus', 'cp_birds' );
    $result = count($bird_taxonomic_genus);
    echo "<p>How many total species of birds are on my web site?</p>";
    echo "Total species: ".$result." (BASED ON GENUS) <br>";

    // Question #2
    // Is there an easy way to determine how many total species of Hummingbirds are on my web site?
    echo get_species_by_tag('Hummingbird');
   
    // Question #3
    // Is there an easy way to determine how many total species of Warblers are on my web site?
    echo get_species_by_tag('Warbler');

    // Question #4
    // Is there an easy way to determine how many total species of flycatchers are on my web site?
    echo get_species_by_tag('Flycatcher');

    // Question #5
    // Is there an easy way to determine how many total species of Raptors are on my web site?
    echo get_species_by_tag('Raptor');

    // Question #6
    // Is there an easy way to determine how many total species of Shorebirds are on my web site?
    echo get_species_by_tag('Shorebird');

    
    

?>
