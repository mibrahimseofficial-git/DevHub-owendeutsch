<?php

/*
Template Name: Home
*/

?>
<?php
	get_header(); 
	?>

<style>
	select#sorting_option {
        position: relative;
        left: unset;
        top: 10px;
        padding: 15px 10px 15px 10px;
        border-radius: 50px;
        border: 0;
        font-weight: 500;
        margin: 0;
        width: 100%;
    }
    div#radio_buttons {
        display: flex;
        align-items: center;
        justify-content: space-evenly;
        margin: 10px 0 0 0;
    }
    input[name='sorting_option']:before {
        content: '';
        display:block;
        width:60%;
        height:60%;
        margin: 20% auto;
        border-radius:50%;
        /* background: white; */
    }

    input[name='sorting_option']:checked:before {
        background: #fff600;
    }

    input[name='sorting_option'] {
        -webkit-appearance: none;
        width: 15px;
        height: 15px;
        border: 1px solid #fff600;
        border-radius: 50%;
        outline: none;
        box-shadow: 0 0 5px 0px grey inset;
        margin-right: 4px;
    }
    div#radio_buttons label {
        font-size: 14px;
        font-weight: 500;
        color: white;
    }

    div#radio_buttons .form-check {
        display: flex;
        align-items: flex-start;
    }

</style>
	
	<?php
	if( have_posts() ) : while( have_posts() ) : the_post();
	?>
	
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<?php  
			$home_banner_bg = get_field('banner_background_image'); 
			$conservation_status_img = get_field('banner_photograph_image');
			$banner_bird_image = get_field('banner_bird_image');
			$banner_bird_circle_image = get_field('banner_bird_background_circle_image');
			$owens_book_image = get_field('owens_book_image');
		?>
		<?php
			$_termsfinal 		= array();
			$current_date 		= date('Y-m');
			$cutout_repeater 	= get_field ('banner_country_cutout_section');
			$final_array 		= array();
			if(!empty($cutout_repeater)){ 
				foreach ($cutout_repeater as $key=>$row) { //pr($row);
					$row['banner_cutout_month'] = (strlen($row['banner_cutout_month']) == 1)? '0'.$row['banner_cutout_month']:$row['banner_cutout_month'];
					$d = $cutout_repeater[$key]['postdate'] = $row['banner_cutout_year'].'-'.$row['banner_cutout_month']; 
					if (strtotime(date('Y-m',strtotime($d))) <= strtotime($current_date) && !empty($row)) {
						$final_array[$d] = $key;                          
					}  /*Foreach loop*/
				}
			}
			function dates_sortblog($a, $b) { 
				return strtotime($a) - strtotime($b);
			}
		?>
		<section class="tilt-home-banner" style="background-image: url(<?php echo $home_banner_bg['url']?>);">
			<div class="banner-text">
				<?php if( !empty( get_field('banner_title_text') ) ){ ?>
						<a href="<?php echo get_field('banner_title_text_link'); ?>" title="<?php echo get_field('banner_title_text')?>">
							<h1><?php echo get_field('banner_title_text'); ?></h1>
						</a>
				<?php } if( !empty( get_field('banner_title_sub_text') )){ ?>
							<h2><?php echo get_field('banner_title_sub_text'); ?></h2>
				<?php } if( !empty( get_field('banner_title_tagline_text') )){ ?>
					<p class="color-yellow"><?php echo get_field('banner_title_tagline_text'); ?></p>
				<?php } ?>
			</div>
			<div class="photographed-peru">
				<?php
					global $term_link_burl;
	                if(!empty($final_array)){ 
                        uksort($final_array, "dates_sortblog");
						$key_value = end($final_array);
						//pr($cutout_repeater[$key_value]);
                        if($cutout_repeater[$key_value]){
							$term_blink = get_term_link( strtoupper($cutout_repeater[$key_value]['banner_cutout_country_list']->slug), 'cp_birds_country');
							$term_link_burl = (!empty($cutout_repeater[$key_value]['banner_cutout_country_list'])) ? $term_blink : '#';
	                		?>
	                			<a href="<?php echo $term_link_burl; ?>">
									<div class="outer-box">
									<?php 
									$img_url = (!empty($cutout_repeater[$key_value]['banner_photograph_image']['url'])) ? $cutout_repeater[$key_value]['banner_photograph_image']['url'] : site_url().'/wp-content/uploads/2019/07/blank.png';
									?>
										<div class="image">
											<img src="<?php echo $img_url; ?>" alt="map">
										</div>
										<div class="text">
											<h5><?php echo $cutout_repeater[$key_value]['banner_photograph_main_text']; ?></h5>
											<h3><?php echo $cutout_repeater[$key_value]['banner_cutout_country_list']->name; ?></h3>
										</div>
									</div>
									<div class="description">
										<p><?php echo $cutout_repeater[$key_value]['banner_convservation_status_text']; ?></p>
										<h5><?php echo $cutout_repeater[$key_value]['banner_convservation_status_title']; ?></h5>
										<h2><?php echo $cutout_repeater[$key_value]['banner_convservation_status_sub_title']; ?></h2>
									</div>
								</a>
	                		<?php

	                	}
                    }
                    else 
                    {
                        //default structure
                    	?>
                    		<a href="<?php echo site_url().'/cp_birds_country/pe/'; ?>">
								<div class="outer-box">
									<div class="image">
										<img src="<?php echo site_url().'/wp-content/uploads/2019/08/perumap.png'; ?>" alt="map">
									</div>
									<div class="text">
										<h5>Photographed in</h5>
										<h3>Peru</h3>
									</div>
								</div>
								<div class="description">
									<p>Conservation status - Least Concern</p>
									<h5>Chestnut-breasted</h5>
									<h2>Peru</h2>
								</div>
							</a>
                    	<?php
                  	}
              	?>
			</div>
			<?php 

				// $temppostyear = array_column($cutout_repeater, 'postdate');
				// $tempunique = array_unique($temppostyear);
				// usort($temppostyear , "dates_sort1");
				// pr($tempunique);

				//$tempunique[$tempunique] = end($temppostyear);
				
					if(!empty($final_array)){ 
						uksort($final_array, "dates_sortblog");
						$key_value = end($final_array);
					}
					if(isset($cutout_repeater[$key_value]) && !empty($cutout_repeater[$key_value])){
						$countrypage_link = get_term_link( strtoupper($cutout_repeater[$key_value]['banner_cutout_country_list']->slug), 'cp_birds_country');
						$header_bird_image = array();
						$country_name = array();
						$head_scheduleimg = $cutout_repeater[$key_value]['banner_bird_schedule'];
						$header_bird_image = (!empty($head_scheduleimg)) ? $head_scheduleimg : site_url().'/wp-content/uploads/2019/05/Hawk-with-Circle.png';
						$country_name = $cutout_repeater[$key_value]['banner_cutout_country_list']->name
						?>
							<a class="tilter tilter--1" href="<?php echo $countrypage_link; ?>">
								<figure class="tilter__figure">
									<img class="tilter__image" src="<?php echo $header_bird_image; ?>" alt="<?php echo $country_name; ?>" />
								</figure>
							</a>
						<?php
					}	
			?>
			
			<div class="responsive-show">
				
				<div class="image">
					<img class="bird-image" src="<?php echo $header_bird_image; ?>" alt="<?php echo $country_name; ?>" />
				</div>
				<div class="bottom-image">
					<div class="photographed-peru show">
						<?php
							if(!empty($final_array)){ 
		                        if($cutout_repeater[$key_value]){
			                		$term_blink = get_term_link( strtoupper($cutout_repeater[$key_value]['banner_cutout_country_list']->slug), 'cp_birds_country');
									$term_link_burl = (!empty($cutout_repeater[$key_value]['banner_cutout_country_list'])) ? $term_blink : '#';
			                		?>
			                			<a href="<?php echo $term_blink; ?>">
											<div class="outer-box test">
												<div class="image">
												<?php 
												$img_url = (!empty($cutout_repeater[$key_value]['banner_photograph_image']['url'])) ? $cutout_repeater[$key_value]['banner_photograph_image']['url'] : site_url().'/wp-content/uploads/2019/07/blank.png';
									?>
													<img src="<?php echo $img_url; ?>" alt="map">
												</div>
												<div class="text">
													<h5><?php echo $cutout_repeater[$key_value]['banner_photograph_main_text']; ?></h5>
													<h3><?php echo $cutout_repeater[$key_value]['banner_cutout_country_list']->name; ?></h3>
												</div>
											</div>
											<div class="description">
												<p><?php echo $cutout_repeater[$key_value]['banner_convservation_status_text']; ?></p>
												<h5><?php echo $cutout_repeater[$key_value]['banner_convservation_status_title']; ?></h5>
												<h2><?php echo $cutout_repeater[$key_value]['banner_convservation_status_sub_title']; ?></h2>
											</div>
										</a>
			                		<?php

			                	}
							}
		                    else 
		                    {
		                        //default structure
		                    	?>
		                    		<a href="<?php echo site_url().'/cp_birds_country/pe/'; ?>">
										<div class="outer-box">
											<div class="image">
												<img src="<?php echo site_url().'/wp-content/uploads/2019/08/perumap.png'; ?>" alt="map">
											</div>
											<div class="text">
												<h5>Photographed in</h5>
												<h3>Peru</h3>
											</div>
										</div>
										<div class="description">
											<p>Conservation status - Least Concern</p>
											<h5>Chestnut-breasted</h5>
											<h2>Peru</h2>
										</div>
									</a>
		                    	<?php
		                  	}
						?>
					</div>
				</div>
			</div>
			<div class="clear"></div>	
		</section>
			
		<!--  Visit a country   -->
		<?php  
    global $wpdb;
    $terms      = get_terms( array(
                        'taxonomy' => 'cp_birds_country',
                        'hide_empty'=> true )
                  );
   // pr($terms);  
   function dates_sort1($a, $b) {  
    return strtotime($a) - strtotime($b);
  }
   $_termsfinal = array();
    foreach ($terms as $key => $countryrow ) 
    {
        $term_link          = get_term_link( strtoupper($countryrow->slug), 'cp_birds_country');
        $cat_term_id        = $countryrow->term_id;
        $p_repeater         = get_field('post_schedule', $countryrow->taxonomy . '_' . $countryrow->term_id);
       
        $current_date       = date('Y-m');
       
        if(($countryrow->count != 0) && (!empty($p_repeater)))
        { 
          foreach ($p_repeater as $key=>$row) { 
            if(!empty($row['display_post'])){
              foreach($row['display_post'] as $innerkey => $display_post){ 
                  $display_post_terms = wp_get_post_terms($display_post->ID, 'cp_birds_country', array("fields" => "ids"));
                  $display_post_term = !empty($display_post_terms)?$display_post_terms[0]:''; 
                
                  if($cat_term_id != $display_post_term){
                      unset($p_repeater[$key]['display_post'][$innerkey]);
                  } 
                  
              }
              if(!empty($p_repeater[$key]['display_post'])){ 
                $current_date   = date('Y-m');
                $postdate = $row['postyear'].'-'.$row['postmonth'];
                if(strtotime(date('Y-m',strtotime($postdate))) <= strtotime($current_date) && !empty($row['display_post']))
                  $p_repeater[$key]['postdate'] = $row['postyear'].'-'.$row['postmonth']; 
                 
              }
            }
            } 
          
          $temppostyear = array_column($p_repeater, 'postdate');
          usort($temppostyear , "dates_sort1");

          $_termsfinal[$cat_term_id] = end($temppostyear);
          $termsslog[$cat_term_id] = $countryrow->slug;
          $termname[$cat_term_id] = $countryrow->name;
        }
        else{ // repeater not assign any value empty then make country = 0;
            $wpdb->update(
                    $wpdb->prefix.'mapsvg_regions_486', 
                    array(
                      'status' => '0',  // string // no dispaly on frnt
                      'status_text' => 'Disabled',
                      'external_link' => NULL,
                    ),
                    array( 'id' => strtoupper($countryrow->slug) )
              );
        }
                      
      }
      foreach($_termsfinal as $terms =>$value){
        if(empty($value)){
              //  value empty then make country = 0;
             $wpdb->update(
              $wpdb->prefix.'mapsvg_regions_486', 
              array(
                'status' => '0',  // string
                'status_text' => 'Disabled',
                'external_link' => NULL,
              ),
              array( 'id' => strtoupper($termsslog[$terms] ))
            );  
            unset($_termsfinal[$terms]);
        } else {   //  value empty then make country = 0;
          $wpdb->update( 
            $wpdb->prefix.'mapsvg_regions_486', 
            array(
              'status' => '1',  // string //dispaly front side 
              'status_text' => 'Enabled',
              'external_link' => $term_link,
            ), 
            array( 'id' => strtoupper($termsslog[$terms]))
          );
         }
      }
?>
		<!-- Start Birds Count -->
		<div class="inner-page-outer-home birds-count" style="margin-top: -20px;">
		    <div class="container-birds-count text-center">
		        <h3 style="color: #fff600;">Featuring photographs of <?php echo number_format( get_option( 'bird-analytics_birds-count' ) ); ?> bird species</h3>
		    </div>
		</div>
		<!-- End Birds Count -->

		<!-- Start Search Filter  -->
		<div class="inner-page-outer-home search">
		    <div class="container-search text-center">
		        <div class="">
		            <div class="col-md-12">
		                <h1 class="large search-title">Search</h1>
		            </div>
		        </div>
		        <?php 
		            $search_subline = get_field('search_subline','option'); 
		            $filter_heading = get_field('search_filter_heading','option'); 
		            $filter_subtitles = get_field('search_filter_subtitles','option'); 
		            if(!empty($search_subline)){ ?>
		                <div class="needhelp"><a href="/faq/#collapse1"><?php echo $search_subline; ?></a></div>
		        <?php } 
		            $search_short_content = get_field('search_short_content','option');
					$searches='';
		            if(!empty($search_short_content)){ 
		            ?>
		                <p><?php echo $search_short_content; ?></p>
		            <?php } 
		                
		        ?>
		        <div class="search-group">
		            <div class="search-input">
					<form action="javascript:;" method="get" id="my-ajax-filter-search">
		                    <input id="searchfocus" class="search-text" type="text" name="s" placeholder="Enter bird species name or keywords" value="<?php echo $searches; ?>">
							<div id="radio_buttons">
								<div class="form-check">
									<input class="form-check-input" type="radio" name="sorting_option" id="sorting_option3" value="by_tags" <?php echo ( !empty($sorting_option) && $sorting_option=='by_tags'  ) ? 'checked' : '';  ?>>
									<label class="form-check-label lll" for="sorting_option3">
										Location
									</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="radio" name="sorting_option" id="sorting_option2" value="exact_match" <?php echo ( !empty($sorting_option) && $sorting_option=='exact_match' || (!isset($_GET['sorting_option'])) || ( empty($sorting_option )) ) ? 'checked' : '';  ?>>
									<label class="form-check-label" for="sorting_option2">
										Bird Name
									</label>
								</div>
								<div class="form-check">
									<input class="form-check-input" type="radio" name="sorting_option" id="sorting_option1" value="contain" <?php echo ( (!empty($sorting_option) && $sorting_option=='contain')) ? 'checked' : '';  ?>>
									<label class="form-check-label" for="sorting_option1">
										Species
									</label>
								</div>
                    		</div>
		                    <input type="submit" id="search_birds" />
		                </form>
		                <span><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/search-icon.png" alt="search"></span>
		            </div>
		            
		        </div>
		        <div class="filterblock">
		            <?php if(!empty($filter_heading)) {  ?>
		                <h3><?php echo $filter_heading; ?></h3>
		            <?php } if(!empty($filter_subtitles)) { ?>
		                <h6><?php echo $filter_subtitles; ?></h6>
		            <?php } ?>
		        </div>
		        <div class="search-filter-outer" >
		            <!-- Country column  -->
		            <div class="search-filter-col">
		                <div class="country-filter dropdown">
		                    <div class="custom-dropdown <?php $country = ''; if($country) { echo 'filterselected'; } ?>" data-toggle="dropdown">
		                        <span id="selected" class="active">Country</span>
		                    </div>
		                    <ul class="dropdown-menu">
		                        <?php //$terms = get_terms( 'cp_birds_country', array( 'hide_empty' => true) ); ?>
		                        <?php $terms = get_terms( array(
		                                                        'order'      => 'ASC',
		                                                        'hide_empty' => true,
		                                                        'exclude'    => array( 994 ),
		                                                        'taxonomy'   => 'cp_birds_country',
		                                                    )); ?>
		                            <?php 
		                                foreach ($terms as $term) {
		                                    //print_r($term);
		                                    ?>
		                                        <li <?php if($country == strtolower($term->term_id)) { echo 'class=active'; } ?>>
		                                            <a href="javascript:void(0);" data-countryfilter="<?php echo strtolower($term->term_id); ?>"><?php echo strtolower($term->name); ?></a>
		                                        </li>
		                                    <?php
		                                    
		                                }
		                            ?>
		                    </ul>
		                </div>
		            </div>

		            <!--Order Column-->
		            <div class="search-filter-col">
		                <div class="bird-family-filter dropdown">
		                    <div class="custom-dropdown <?php $birdfamily = ''; if($birdfamily) { echo 'filterselected'; } ?>" data-toggle="dropdown">
		                        <span id="birdfamilyselected">Order</span>
		                    </div>
		                    <?php
		                        $bird_family_arr = [];
		                        $bird_family = get_meta_values( 'bird_family', 'cp_birds' );
		                        asort($bird_family);
		                        if( !empty( $bird_family ) ) {
		                            ?>
		                                <ul class="dropdown-menu">
		                                    <!--<li><a href="javascript:void(0);">Order</a></li>-->
		                                    <?php
		                                        foreach( $bird_family as $key => $bird_family_value ){
		                                            if( !empty($bird_family_value) && !in_array(trim($bird_family_value), $bird_family_arr)){
		                                                ?>
		                                                <li <?php if($birdfamily == strtolower($bird_family_value)) { echo 'class=active'; } ?>>
		                                                    <a href="javascript:void(0);" data-bird-family="<?php echo strtolower($bird_family_value); ?>">
		                                                        <?php echo strtolower($bird_family_value); ?>
		                                                    </a>
		                                                </li>
		                                                <?php
		                                                $bird_family_arr[] =  trim($bird_family_value);
		                                            }
		                                        }
		                                    ?>
		                                </ul>
		                            <?php
		                        }
		                    ?>
		                </div>
		            </div>

		             <!-- Visual Category Column  -->
		            <div class="search-filter-col">
		                    <div class="visualcategory-filter dropdown">
		                        <div class="custom-dropdown <?php $visualcategory = ''; if($visualcategory) { echo 'filterselected'; } ?>" data-toggle="dropdown">
		                            <span id="visualcategoryselected">Visual Category</span>
		                        </div>
		                        <?php
		                            $bird_visualcategory = get_meta_values( 'bird_visual_country', 'cp_birds' );
		                            asort($bird_visualcategory);
		                            if( !empty( $bird_visualcategory ) ) {
		                                ?>
		                                    <ul class="dropdown-menu">
		                                        <!--<li><a href="javascript:void(0);">Visual Category</a></li>-->
		                                        <?php
		                                            foreach( $bird_visualcategory as $key => $bird_visualcategory_value ){
		                                                if( !empty($bird_visualcategory_value) ){
		                                                    ?>
		                                                    <li <?php if($visualcategory == strtolower($bird_visualcategory_value)) { echo 'class=active'; } ?>>
		                                                        <a href="javascript:void(0);" data-bird-visualcategory="<?php echo strtolower($bird_visualcategory_value); ?>">
		                                                            <?php echo strtolower($bird_visualcategory_value); ?>
		                                                        </a>
		                                                    </li>
		                                                    <?php
		                                                }
		                                            }
		                                        ?>
		                                    </ul>
		                                <?php
		                            }
		                        ?>
		                    </div>
		            </div>

		            <!-- Locations Multi column  -->
					<div class="search-filter-col">
						<div class="locations-filter dropdown">
							<div class="custom-dropdown <?php if($locations) { echo 'filterselected'; } ?>" data-toggle="dropdown">
								<span id="locationselected">Birding Sites and Lodges</span>
							</div>
							<?php 
								$bird_locations_multi = get_meta_values( 'bird_locations_multi', 'cp_birds');

								
								
							
								$postidofmulti = array();
								foreach ($bird_locations_multi as $key => $data) {
									$test = unserialize($data);
									if($test){
										$postidofmulti = array_merge($postidofmulti, $test);
									}   
								}
								
								$value_id = implode(",", $postidofmulti);
                            	global $wpdb;
                            	$get_title = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($value_id) AND post_status = 'publish'", ARRAY_N );
                            	$postidtit = array_column($get_title, 0);

								asort($postidtit);
								if(!empty($postidtit)){
								//	echo count($postidtit);
									?>
									<ul class="dropdown-menu">
										<?php
											foreach (array_unique($postidtit) as $key => $value) {
												if (!empty($value)) {
													?>
														<li <?php if(isset($locations)){   if($locations == strtolower($value)) { echo 'class=active'; } } ?>> 
															<a href="javascript:void(0);" data-bird-locations="<?php  echo strtolower($value); ?>">
															<?php echo $value; ?>
															</a>
														</li>
													<?php
												}
											}
										?>
									</ul>
									<?php
								}
							
							?>
						</div>
					</div> 

		            <!-- Family Column  -->
		            <div class="search-filter-col">
		                <div class="family-filter dropdown">
		                    <div class="custom-dropdown <?php $familycategory = ''; if($familycategory) { echo 'filterselected'; } ?>" data-toggle="dropdown">
		                        <span id="familycategoryselected">Family</span>
		                    </div>
		                    <?php
		                        $bird_familycategory = get_meta_values( 'bfamily', 'cp_birds' );
		                        asort($bird_familycategory);
		                        if( !empty( $bird_familycategory ) ) {
		                            ?>
		                                <ul class="dropdown-menu">
		                                    <!--<li><a href="javascript:void(0);">Visual Category</a></li>-->
		                                    <?php
		                                        foreach( $bird_familycategory as $key => $bird_familycategory_value ){
		                                            // pr($bird_familycategory_value);
		                                            if( !empty($bird_familycategory_value) ){
		                                                ?>
		                                                <li <?php if($familycategory == mb_strtolower($bird_familycategory_value)) { echo 'class=active'; } ?>>
		                                                    <a href="javascript:void(0);" data-bird-familycategory="<?php echo mb_strtolower($bird_familycategory_value); ?>">
		                                                        <?php echo mb_strtolower($bird_familycategory_value); ?>
		                                                    </a>
		                                                </li>
		                                                <?php
		                                            }
		                                        }
		                                    ?>
		                                </ul>
		                            <?php
		                        }
		                    ?>
		                </div>
		            </div>

		             <!-- Activity column  -->
		            <div class="search-filter-col">
		                <div class="activity-filter dropdown">
		                    <div class="custom-dropdown <?php $activity_value = ''; if($activity_value) { echo 'filterselected'; } ?>" data-toggle="dropdown">
		                        <span id="activityselected">Activity</span>
		                    </div>
		                    <?php 
		                        $allBirdactivity = array();
		                        
		                        $bird_activity = get_meta_values( 'bird_activity', 'cp_birds' );
		                        foreach($bird_activity as $activity){ 
		                            $new =array();
		                                $new =explode(",",$activity);
		                                foreach($new as $new_item){
		                                    // $allBirdactivity[] = $new_item;
											$allBirdactivity[] = strtolower(trim($new_item));
		                                }
		                              
		                            }
		                        if( !empty( $allBirdactivity ) ) {
		                            ?>
		                                <ul class="dropdown-menu">
		                                    <!--<li><a href="javascript:void(0);">Activity</a></li>-->
		                                    <?php
		                                        foreach( array_unique($allBirdactivity) as $key => $bird_activity_value ){
		                                            if( !empty($bird_activity_value) ){

		                                                ?>
		                                                <li <?php if($activity_value == strtolower($bird_activity_value)) { echo 'class=active'; } ?>>
		                                                    <a href="javascript:void(0);" data-bird-activity="<?php echo strtolower($bird_activity_value); ?>">
		                                                        <?php echo strtolower($bird_activity_value); ?>
		                                                    </a>
		                                                </li>
		                                                <?php
		                                            }
		                                        }
		                                    ?>
		                                </ul>
		                            <?php
		                        }
		                    ?>
		                </div>
		            </div>
		            
		            <!-- Conservancy column  -->
		            <div class="search-filter-col">
		                <div class="conservancy-filter dropdown">
		                    <div class="custom-dropdown <?php $conservancy = ''; if($conservancy) { echo 'filterselected'; } ?>" data-toggle="dropdown">
		                        <span id="conservancyselected">Conservation Status</span>
		                    </div>
		                    <?php  $getseqs = get_field('field_5d5a95442afc6','option');
		                        $seqs = explode('<br />',$getseqs);
		                        
		                        foreach($seqs as $s){ 
		                            $temp =  trim($s);
		                            $seq[] = strtolower($temp);
		                            } 
		                        //$seq  = array('leastconcern','nearthreatened','vulnerable','endangered','criticallyendangered');  // small later and without space
		                        $bird_conservancy = get_meta_values( 'bird_conservation_status', 'cp_birds' );
		                        foreach ($seq as $row) {
		                           foreach($bird_conservancy as $k => $cons)
		                           {   // echo $row  .'=='. str_replace(' ','',strtolower($cons)).'<br>';
		                                if($row  == str_replace(' ','',strtolower($cons))){
		                                     $result[] = $cons;  break;
		                                }
		                               
		                           }
		                        }
		                      
		                        asort($bird_conservancy);
		                        if( !empty( $result ) ) {
		                            ?>
		                                <ul class="dropdown-menu">
		                                    <!--<li><a href="javascript:void(0);">Conservation Status</a></li>-->
		                                    <?php
		                                        foreach( $result as $key => $bird_conservancy_value ){
		                                            if( !empty($bird_conservancy_value) ){
		                                                ?>
		                                                <li <?php if($conservancy == strtolower($bird_conservancy_value)) { echo 'class=active'; } ?>>
		                                                    <a href="javascript:void(0);" data-bird-conservancy="<?php echo strtolower($bird_conservancy_value); ?>">
		                                                        <?php echo strtolower($bird_conservancy_value); ?>
		                                                    </a>
		                                                </li>
		                                                <?php
		                                            }
		                                        }
		                                    ?>
		                                </ul>
		                            <?php
		                        }
		                    ?>
		                </div>
		            </div>
		            

		            <!--Genus Column-->
		            <div class="search-filter-col">
		                <div class="taxonomic-genus-filter dropdown">
		                    <div class="custom-dropdown <?php $taxonomicgenus = '' ;if($taxonomicgenus) { echo 'filterselected'; } ?>" data-toggle="dropdown">
		                        <span id="taxonomicselected">Genus</span>
		                    </div>
		                    <?php
		                        $taxonomy_genus = get_meta_values( 'bird_taxonomic_genus', 'cp_birds' );
		                        asort($taxonomy_genus);
		                        if( !empty( $taxonomy_genus ) ) {
		                            ?>
		                                <ul class="dropdown-menu">
		                                    <!--<li><a href="javascript:void(0);">Genus</a></li>-->
		                                    <?php
		                                        foreach( $taxonomy_genus as $key => $taxonomy_genus_value ){
		                                            /*$num_of_ratings[] = $taxonomy_genus_value;*/
		                                            if( !empty($taxonomy_genus_value) ){
		                                                ?>
		                                                <li <?php if($taxonomicgenus == strtolower($taxonomy_genus_value)) { echo 'class=active'; } ?>>
		                                                    <a href="javascript:void(0);" data-taxonomic-genus="<?php echo strtolower($taxonomy_genus_value); ?>">
		                                                        <?php echo strtolower($taxonomy_genus_value); ?>
		                                                    </a>
		                                                </li>
		                                                <?php
		                                                
		                                            }
		                                        }
		                                    ?>
		                                </ul>
		                            <?php
		                        }
		                    ?>
		                </div>
		            </div>
		           
		            <div class="search-filter-col">
		                <div class="buttonarea">
		                    <div class="submitsearch"><a class="submitsearchbtn">Search</a></div>
		                    <!-- <div class="filter-clear"><a href="javascript:void(0);" class="custom-clear-btn clear-search">Clear</a></div> -->
		                    <div class="filter-clear"><a href="<?php site_url(); ?>" class="custom-clear-btn clear-search">Clear</a></div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
		<!-- End -->

		<!--  Conservation Section   -->
		<section  class="conservation two-column-center cmn-padding">
			<div class="container">
				<div class="responsive-image">
					<?php $conservation_section_image = get_field('conservation_section_image'); ?>
					<img src="<?php echo $conservation_section_image['url'];?>" alt="<?php echo $conservation_section_image['alt']; ?>">
                    <div class="photographed-peru123">
						<?php
							$cs_date       = date('Y-m');
							$cs_repeater = get_field ('cs_country_cutout_section');
							$final_cs_array = array();
							if(!empty($cs_repeater)){ 
								foreach ($cs_repeater as $key=>$row) { //pr($row);
								    $row['cs_cutout_month'] = (strlen($row['cs_cutout_month']) == 1)? '0'.$row['cs_cutout_month']:$row['cs_cutout_month'];
									$cd = $cs_repeater[$key]['postdate'] = $row['cs_cutout_year'].'-'.$row['cs_cutout_month']; 
										
									if (strtotime(date('Y-m',strtotime($cd))) <= strtotime($current_date) && !empty($row)) {
										$final_cs_array[$cd] = $key;                          
									}  /*Foreach loop*/
								}
							}
							function dates_cs_sort($a, $b) { 
								return strtotime($a) - strtotime($b);
							}
							if(!empty($final_cs_array)){ 
								uksort($final_cs_array, "dates_cs_sort");
								$key_value = end($final_cs_array);
							}
							if(!empty($final_cs_array)){ 
								if($cs_repeater[$key_value]){
									$term_link = '';
									//$term_link = get_term_link( strtoupper($cs_repeater[$key_value]['cs_cutout_country_list']->slug), 'cp_birds_country');
									$term_link_url = (!empty($cs_repeater[$key_value]['cs_cutout_country_list'])) ? $term_link : '#';
									if(!empty($cs_repeater[$key_value]['cs_photograph_image']) && !empty($cs_repeater[$key_value]['cs_photograph_main_text'])) { ?>
										<a href="<?php echo $term_link_burl; ?>">
											
											<div class="outer-box">
												<div class="image">
												<?php 
												//pr($cs_repeater[$key_value]['cs_photograph_image']['url']);
												$img_curl = (!empty($cs_repeater[$key_value]['cs_photograph_image'])) ? $cs_repeater[$key_value]['cs_photograph_image']['url'] : site_url().'/wp-content/uploads/2019/07/blank.png';
												?>
									
													<img src="<?php echo $img_curl; ?>" alt="map">
												</div>
												<div class="text">
													<h5><?php echo $cs_repeater[$key_value]['cs_photograph_main_text']; ?></h5>
													<h3><?php echo $cs_repeater[$key_value]['cs_cutout_country_list']->name; ?></h3>
												</div>
											</div>
										</a>
									<?php } ?>
									
									<div class="description con-desc">
										<h5><?php echo $cs_repeater[$key_value]['cs_status_title']; ?></h5>
										<h2><?php echo $cs_repeater[$key_value]['cs_status_sub_title']; ?></h2>
										<p><?php echo $cs_repeater[$key_value]['cs_status_text']; ?></p>
									</div>
									<?php
									}
							}
							else 
							{
								//default structure
								?>
									<a href="<?php echo $term_link_burl; ?>">
										<div class="outer-box">
											<div class="image">
												<img src="<?php echo site_url().'/wp-content/uploads/2019/08/perumap.png'; ?>" alt="map">
											</div>
											<div class="text">
												<h5>Photographed in</h5>
												<h3>Peru</h3>
											</div>
										</div>
										<div class="description">
											<h5>Chestnut-breasted</h5>
											<h2>Peru</h2>
											<p>Conservation status - Least Concern</p>
										</div>
									</a>
								<?php
							}
						?>											
					</div>
				</div>
				<div class="content">
					<h2><?php echo get_field('conservation_title'); ?></h2>
					<p><?php echo get_field('conservation_description'); ?></p>
					<a href="<?php echo get_field('conservation_button_link'); ?>" class="yellow-btn"><?php echo get_field('conservation_button_text'); ?></a>
				</div>
				<div class="image responsive-hide">
					<img src="<?php echo $conservation_section_image['url'];?>" alt="<?php echo $conservation_section_image['alt']; ?>">
					<div class="photographed-peru second-desc">
						<?php
							if(!empty($final_cs_array)){ 
									if($cs_repeater[$key_value]){
										$term_link = '';//get_term_link( strtoupper($cs_repeater[$key_value]['cs_cutout_country_list']->slug), 'cp_birds_country');
										$term_link_url = (!empty($cs_repeater[$key_value]['cs_cutout_country_list'])) ? $term_link : '#';
										if(!empty($cs_repeater[$key_value]['cs_photograph_image']) && !empty($cs_repeater[$key_value]['cs_photograph_main_text'])) { ?>
												<a href="<?php echo $term_link_url; ?>">
													
													<div class="outer-box">
														<div class="image">
														<?php 
														//pr($cs_repeater[$key_value]['cs_photograph_image']['url']);
														$img_curl = (!empty($cs_repeater[$key_value]['cs_photograph_image'])) ? $cs_repeater[$key_value]['cs_photograph_image']['url'] : site_url().'/wp-content/uploads/2019/07/blank.png';
														?>
											
															<img src="<?php echo $img_curl; ?>" alt="map">
														</div>
														<div class="text">
															<h5><?php echo $cs_repeater[$key_value]['cs_photograph_main_text']; ?></h5>
															<h3><?php echo $cs_repeater[$key_value]['cs_cutout_country_list']->name; ?></h3>
														</div>
													</div>
												</a>
											<?php } ?>
											<div class="description con-desc">
												<h5><?php echo $cs_repeater[$key_value]['cs_status_title']; ?></h5>
												<h2><?php echo $cs_repeater[$key_value]['cs_status_sub_title']; ?></h2>
												<p><?php echo $cs_repeater[$key_value]['cs_status_text']; ?></p>
											</div>
										<?php

									}
								}
								else 
								{
									//default structure
									?>
										<a href="<?php echo site_url().'/cp_birds_country/pe/'; ?>">
											<div class="outer-box">
												<div class="image">
													<img src="<?php echo site_url().'/wp-content/uploads/2019/08/perumap.png'; ?>" alt="map">
												</div>
												<div class="text">
													<h5>Photographed in</h5>
													<h3>Peru</h3>
												</div>
											</div>
											<div class="description">
												<p>Conservation status - Least Concern</p>
												<h5>Chestnut-breasted</h5>
												<h2>Peru</h2>
											</div>
										</a>
									<?php
								}

						?>									
					</div>
				</div>
			</div>
		</section>
		<!--  End   -->
		<!-- About Owen   -->
		<section  class="about-owen two-column-center cmn-padding">
			<div class="container">
				<div class="image">
					<?php $about_owens_image = get_field('about_owens_image'); ?>
					<img src="<?php echo $about_owens_image['url']; ?>" alt="<?php echo $about_owens_image['alt']; ?>">
				</div>
				<div class="content">
					<?php echo get_field('about_owens_title'); ?>
					<p><?php echo get_field('about_owens_description'); ?></p>
					<a href="<?php echo get_field('about_owens_button_description'); ?>" class="yellow-btn"><?php echo get_field('about_owens_button_text'); ?></a>
				</div>
			</div>
		</section>
		<!--  End   -->
		<!--  Section New Book   -->
		<section  class="owen-new-book two-column-center cmn-padding">
			<div class="container">
				<?php
					
					//if(file_exists($owens_book_image['url'])){
						?>
							<div class="responsive-image">
								<img src="<?php echo $owens_book_image['url']; ?>" alt="<?php echo $owens_book_image['alt']; ?>">
							</div>
						<?php
					//}
				?>
				
				<div class="content">
					<?php echo get_field('owens_book_title'); ?>
					<p><?php echo get_field('owens_book_desciption'); ?></p>
					<a href="<?php echo get_field('owens_book_button_link'); ?>" target="_blank" class="yellow-btn"><?php echo get_field('owens_book_button_text'); ?></a>
				</div>
			    <div class="image responsive-hide">
						<img src="<?php echo $owens_book_image['url']; ?>" alt="<?php echo $owens_book_image['alt']; ?>">
				</div>
			</div>
		</section>
		<!--  End   -->
		<!--  Instagram Feed  -->
		<section class="instagram-feed">
			<div class="display-feed">
				<div class="owl-image-instagram">
					<div class="title">
						<div class="title-inner">
							<?php echo get_field('instagram_title', 'option'); ?>
						</div>
					</div>
					<?php $insta_bg_image = get_field('instagram_section_bg_image', 'option'); ?>
					<img src="<?php echo $insta_bg_image['url']; ?>" alt="<?php echo $insta_bg_image['alt']; ?>">
				</div>
				<?php 
					//$instagram_shortcode = get_field('instagram_feed_shortcode', 'option');			
					//echo do_shortcode($instagram_shortcode);
					// echo do_shortcode("[instagram-feed num=8 cols=4 showfollow=false]");
					echo do_shortcode("[instagram-feed num=5 cols=5 showfollow=false]");
				?>
			</div>
		</section>
		<!-- End -->
	</div>
<?php
	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
	get_footer();
?>