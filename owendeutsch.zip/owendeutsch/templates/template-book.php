<?php

/*

Template Name: Book

*/

?>

<?php

	get_header(); 

	if( have_posts() ) : while( have_posts() ) : the_post();

?>

	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">

		<div class="inner-page-outer book">
			<div class="book-title text-center">
				<?php if( !empty( get_field('owens_book_head_title') )) { ?>
						<h1 class="large"><?php echo get_field('owens_book_head_title'); ?></h2>
				<?php } if( !empty( get_field('owens_book_head_sub_title') ))  { ?>
						<p><?php echo get_field('owens_book_head_sub_title'); ?></p>
				<?php } ?>
			</div>
			<!--  Section New Book   -->
			<section  class="owen-new-book two-column-center cmn-padding">

				<div class="container">

					<div class="responsive-image">
						<?php $about_bird_image = get_field('owens_book_image'); ?>
						<img src="<?php echo $about_bird_image['url']; ?>" alt="<?php echo $about_bird_image['alt']; ?>">

					</div>

					<div class="content">

						<?php echo get_field('owens_book_title'); ?>

						<p><?php echo get_field('owens_book_desciption'); ?></p>

						<a href="<?php echo get_field('owens_book_button_link'); ?>" target="_blank" class="yellow-btn"><?php echo get_field('owens_book_button_text'); ?></a>

					</div>

					<div class="image responsive-hide">

					
						<img src="<?php echo $about_bird_image['url']; ?>" alt="<?php echo $about_bird_image['alt']; ?>">

					</div>

				</div>

			</section>

			<!--  End   -->




			<?php $video_array = get_field('video_section'); ?>
		<div class="book-video-section">	

	  	 	<div class="tab-content">
				<?php foreach ($video_array as $key => $videos) {
			  			$key++;
			  			$active_class = ($key == 1) ? 'active' : '' ;
						$video_iframe = $videos['video_source__iframe_'];
						?>
							<div id="video<?php echo $key; ?>" class="tab-pane fade in <?php echo $active_class; ?>">
								<div class='embed-container'>
									<?php echo $video_iframe; ?>
								</div>	
							</div>
				<?php } ?>
			</div>
			<?php /*<ul class="nav nav-tabs text-center">
			  	<?php foreach ($video_array as $key => $videosimg) {
			  			$key++;
			  			$active_cls = ($key == 1) ? 'class="active"' : '' ;
						$video_thumbnail = $videosimg['video_thumbnail'];
						?>
				    		<li <?php echo $active_cls; ?>>
				    			<a data-toggle="tab" href="#video<?php echo $key; ?>"><img src="<?php echo $video_thumbnail['url']; ?>" alt="video"></a>
				    		</li>
			    		<?php
		    		} ?>
	    	</ul>*/ ?>

		</div>



			<!--  Instagram Feed  -->

			<section class="instagram-feed">

				<div class="display-feed">

					<div class="owl-image-instagram">

						<div class="title">
							<div class="title-inner">
								<?php echo get_field('instagram_title', 'option'); ?>
							</div>
						</div>

						<?php $insta_bg_image = get_field('instagram_section_bg_image', 'option'); ?>
						<img src="<?php echo $insta_bg_image['url']; ?>" alt="<?php echo $insta_bg_image['alt']; ?>">

					</div>

					<?php 
							//$instagram_shortcode = get_field('instagram_feed_shortcode', 'option');
							//echo do_shortcode($instagram_shortcode);
							echo do_shortcode("[instagram-feed num=5 cols=5 showfollow=false]");
						?>

				</div>

			</section>

			<!-- End -->



		</div>

	</div>

<?php

	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 

	get_footer();

?>