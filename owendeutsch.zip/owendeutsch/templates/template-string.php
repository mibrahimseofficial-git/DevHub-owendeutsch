<?php
/*
Template Name: Content
*/
?>
<?php
	get_header(); 
	global $wpdb;
	$args = array(
			'post_type'			=> 'cp_birds',
			'post_status'    	=> 'publish',
			'posts_per_page'	=> -1
		);              
	$the_query = new WP_Query( $args );
	if($the_query->have_posts() ) : while ( $the_query->have_posts() ) : $the_query->the_post(); 
		$id 	= get_the_ID();
		$title 	= get_the_title();
		$cs 	= get_post_meta(get_the_ID(), 'bird_conservation_status', true);
		$sn 	= get_post_meta(get_the_ID(), 'bird_scientific_name', true);
		
		
		//echo 	get_the_content();
		$terms 	= wp_get_post_terms(get_the_ID(), 'cp_birds_tag');
		if ($terms) {
			$output = array();
			foreach ($terms as $term) {
				$output[] = $term->name;
			}
			$tagsexplode = join( ',', $output );
		}
		
		
		
		
		$countryoutput = get_the_terms(get_the_ID(), 'cp_birds_country');
		$catname = array();
		foreach ($countryoutput as $cat) {
			$cat_id = $cat->term_id;
			$catname = $cat->name;
		}
		echo $cat_id;
		echo $catname;
	
		$string = array($title,$cs,$sn,$tagsexplode,$countryoutput);
		$implodestring	= implode(",",$string);
		
		/* echo '<pre>';
		print_r($implodestring);
		echo '</pre>'; */
		

?>
<?php
	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
	get_footer();
?>
