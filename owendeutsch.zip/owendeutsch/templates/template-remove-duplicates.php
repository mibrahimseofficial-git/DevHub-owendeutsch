<?php
/*
Template Name: Remove Duplicates
*/
?>
<?php get_header(); ?>
<?php
  /*$str = "684,672,3426,4435,4403,678,4063,2407,4403,4401,4399,4409,4411,4413,4415,4417,4419,4421,4423,4425,4427,4429,4433,4435,4032,4037,4044,4050,4062,4067,4078,4085,4090,4095,4099,4101,4104,4107,4111,4115,4123,4126,4131,4134,4157,4160,4136,4141,4144,4148,4154,4164,4169,4172,4176,4179,4183,4193,4190,4197,4200,4205,4211,4217,4245,4250,4256,4260,4265,4269,4275,4278,4280,4284,4288,4297,4303,4308,4311,4314,4186,4188,4318,4322,4325,4329,4332,4335,4338,4342,4344,4346,4348,4350,4352,4354,4356,4358,4360,4362,4364,4366,4368,4372,4374,4376,4378,4380,4382,4384,4386,4388,4390,4392,4394,4396,4219,4222,4229,4234,4237,4242,4590,2407";
  $straexplode = explode(",",$str);
  foreach ( $straexplode as $mybird ) {
    wp_delete_post( $mybird, true); // Set to False if you want to send them to Trash.
    }*/
?>
<?php 
  global $wpdb;
  // $sql="SELECT ID, `post_title` FROM wp_posts WHERE post_status = 'publish' AND `post_type` = 'cp_birds'";
  // $sql="SELECT Id,post_title,post_status FROM wp_posts WHERE post_date >= '2019-06-19' AND post_type LIKE 'cp_birds'";
  // $sql="SELECT * FROM `wp_postmeta` WHERE `meta_key` LIKE 'bird_conservation_status' AND `meta_value` = 'Least Concern' ORDER BY `wp_postmeta`.`post_id` ASC";
  $sql="SELECT cs.meta_value,c.ID FROM wp_postmeta AS cs INNER JOIN wp_posts AS c ON c.ID = cs.post_id WHERE cs.meta_key LIKE 'bird_visual_country' AND cs.meta_value LIKE 'Passerine (Perching) Birds' AND c.post_status = 'publish'";
  $results = $wpdb->get_results($sql);
  //pr($results);
  print("<ul>");
  foreach ($results as $row)
  {
    echo '<li>'.$row->ID.'</li>';
  }
  foreach ($results as $row)
  {
    echo '<li>'.$row->meta_value.'</li>';
  }
  print("</ul>");
?>
<?php get_footer(); ?>