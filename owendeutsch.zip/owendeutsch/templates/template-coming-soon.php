<?php
/*
Template Name: Coming Soon
*/
?>
<?php
	get_header(); 
	if( have_posts() ) : while( have_posts() ) : the_post();
?>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div style="height: 900px;"></div>
	</div>
<?php
	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
	get_footer();
?>