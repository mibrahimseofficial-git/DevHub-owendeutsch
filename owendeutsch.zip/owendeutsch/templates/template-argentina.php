<?php
/*
Template Name: Argentina
*/
?>
<?php
	get_header(); 
	if( have_posts() ) : while( have_posts() ) : the_post();
?>

<style type="text/css">
.imglist.row a{ margin-bottom:20px; }
.fancybox-thumbs{ background: #000 !important; }
.fancybox-container, .fancybox-slide{background:#000 !important;}
.fancybox-thumbs__list a:before{border: 1px solid #ecff52 !important;}
/* ---- grid ---- */
.grid {
  background: #DDD;
  max-width: 1200px;
}

/* clear fix */
.grid:after {
  content: '';
  display: block;
  clear: both;
}

/* ---- .grid-item ---- */

.grid-item {
  float: left;
  /*width: 100px;
  height: 100px;*/
  /*background: #0D8;*/
  border: 2px solid #333;
  border-color: hsla(0, 0%, 0%, 0.7);
}

.grid-item--width2 { width: 200px; }
.grid-item--height2 { height: 200px; }
.fancybox-bg{
  background: #0e0d11;
}
.fancybox-thumbs{
    height: 401px !important;
    top: 50%;
    transform: translateY(-50%);
}
figcaption h6{ text-transform: uppercase;font-size: 15px;margin-top:10px;}

ul.massonary {
    padding: 0;
    list-style: none;
    display: inline-block;
    width: 100%;
}
ul.massonary li {
	overflow: hidden;
    width: 14%;
    float: left;
    border: 2px solid #000;
    -webkit-transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}
ul.massonary li:hover {
  border-color: #F6EC01;
}
ul.massonary li:nth-child(2), ul.massonary li:nth-child(3), ul.massonary li:nth-child(6), ul.massonary li:nth-child(8) {
    width: 29%;
}
ul.massonary li .image {
    height: 300px;
    display: table-cell;
    vertical-align: middle;
    text-align: center;
}
header#masthead {
    display: none;
}
footer#colophon {
    display: none;
}
h1:not(.site-title):before, h2:before{
  display: none;
}
.fancybox-toolbar {
    top: 87% !IMPORTANT;
    right: 50% !IMPORTANT;
    transform: translateX(50%);
}
ul.massonary li a {
    display: table;
    width: 100%;
    position: relative;
}
.background-image {
    position: absolute;
    height: 100%;
    width: 100%;
    z-index: -1;
    filter: grayscale(30%) blur(13px);
    -webkit-filter: grayscale(30%) blur(13px);
    background-repeat: no-repeat;
    background-size: cover;
}
ul.massonary li img {
    width: auto;
    height: auto;
    max-height: 300px;
}
.view-another {
    clear: both;
    padding: 50px 0;
    text-align: center;
}
.view-another a {
    font-size: 16px;
    text-transform: uppercase;
}
.view-another a i {
    padding-right: 10px;
}
@media ( max-width: 1499px ) {
	ul.massonary li .image { height: 230px; }
	ul.massonary li img { max-height: 230px; }
	.location-single { top: 397px; }
}
@media ( max-width: 991px ) {
  ul.massonary li { width: 50%; }
  ul.massonary li:nth-child(2), ul.massonary li:nth-child(3), ul.massonary li:nth-child(6), ul.massonary li:nth-child(8) { width: 50%; }
  .location-single { top: 0;  }
}
@media ( max-width: 640px ) {
  ul.massonary li { width: 100%; }
  ul.massonary li:nth-child(2), ul.massonary li:nth-child(3), ul.massonary li:nth-child(6), ul.massonary li:nth-child(8) { width: 100%; }
  ul.massonary li .image { height: auto; }
  ul.massonary li img { max-height: 800px; }
  ul.massonary { margin-top: 30px; }
}
</style>

	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div class="inner-page-outer gallery-inner">
			<div class="large-container">
				
				<div class="location-single">
					<h2 class="large"><span>LOCATION :</span> Argentina</h2>
				</div>

				<ul class="massonary contain">
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Green-barred_Woodpecker.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill" >
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Green-barred_Woodpecker.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Green-barred_Woodpecker.jpg" alt="Green barred Woodpecker" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Great_Grebe.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Great_Grebe.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Great_Grebe.jpg" alt="Great Grebe" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Glittering-bellied_Emerald.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Glittering-bellied_Emerald.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Glittering-bellied_Emerald.jpg" alt="Glittering bellied Emerald" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Flying_Steamer_Duck.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Flying_Steamer_Duck.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Flying_Steamer_Duck.jpg" alt="Flying Steamer Duck" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Bay-winged_Cowbird.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Bay-winged_Cowbird.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Bay-winged_Cowbird.jpg" alt="Bay winged Cowbird" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Black-bellied_Whistling_Duck.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Black-bellied_Whistling_Duck.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Black-bellied_Whistling_Duck.jpg" alt="Black bellied Whistling Duck" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Bicolored_Hawk.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Bicolored_Hawk.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Bicolored_Hawk.jpg" alt="Bicolored Hawk" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Bay-winged_Cowbird.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Bay-winged_Cowbird.jpg);"></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Bay-winged_Cowbird.jpg" alt="Bay winged Cowbird" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Austral_Thrush_1.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Austral_Thrush_1.jpg)";></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Austral_Thrush_1.jpg" alt="Austral Thrush 1" />
			            </div>
			          </a>
			      </li>
			      <li>
			        <a class="grid-item1" href="https://www.owendeutsch.com/album/images/gallery/argentina-Austral_Parakeet.jpg" data-fancybox="images" data-caption="Southern Yellow-billed Hornbill">
			        	<div class="background-image" style="background-image: url(https://www.owendeutsch.com/album/images/gallery/argentina-Austral_Parakeet.jpg)";></div>
			            <div class="image">
			              <img class="img-fluid" src="https://www.owendeutsch.com/album/images/gallery/argentina-Austral_Parakeet.jpg" alt="Austral Parakeet" />
			            </div>
			          </a>
			      </li>

			    </ul>

			    <div class="view-another">
			    	<a href="<?php the_permalink(12); ?>"><i class="fa fa-angle-left" aria-hidden="true"></i>visit another country</a>
			    </div>

			</div>
		</div>
	</div>
<?php
	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
	get_footer();
?>