<?php
/*
Template Name: South Africa
*/
?>
<?php
	get_header(); 
	if( have_posts() ) : while( have_posts() ) : the_post();
?>

<style type="text/css">
.imglist.row a{ margin-bottom:20px; }
.fancybox-thumbs{ background: #000 !important; }
.fancybox-container, .fancybox-slide{background:#000 !important;}
.fancybox-thumbs__list a:before{border: 1px solid #ecff52 !important;}
/* ---- grid ---- */
.grid {
  background: #DDD;
  max-width: 1200px;
}

/* clear fix */
.grid:after {
  content: '';
  display: block;
  clear: both;
}

/* ---- .grid-item ---- */

.grid-item {
  float: left;
  /*width: 100px;
  height: 100px;*/
  /*background: #0D8;*/
  border: 2px solid #333;
  border-color: hsla(0, 0%, 0%, 0.7);
}

.grid-item--width2 { width: 200px; }
.grid-item--height2 { height: 200px; }
.fancybox-bg{
  background: #0e0d11;
}
figcaption h6{ text-transform: uppercase;font-size: 15px;margin-top:10px;}

ul.massonary {
    padding: 0;
    list-style: none;
    display: inline-block;
    width: 100%;
}
ul.massonary li {
	overflow: hidden;
    width: 14%;
    float: left;
    border: 2px solid #000;
    -webkit-transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
}
ul.massonary li:hover {
  border-color: #F6EC01;
}
ul.massonary li:nth-child(2), ul.massonary li:nth-child(3), ul.massonary li:nth-child(6), ul.massonary li:nth-child(8) {
    width: 29%;
}
ul.massonary li .image {
    height: 300px;
    display: table-cell;
    vertical-align: middle;
    text-align: center;
}
header#masthead {
    display: none;
}
footer#colophon {
    display: none;
}
h1:not(.site-title):before, h2:before{
  display: none;
}
.fancybox-toolbar {
    top: 87% !IMPORTANT;
    right: 50% !IMPORTANT;
    transform: translateX(50%);
}
ul.massonary li a {
    display: table;
    width: 100%;
    position: relative;
}
.background-image {
    position: absolute;
    height: 100%;
    width: 100%;
    z-index: -1;
    filter: grayscale(30%) blur(13px);
    -webkit-filter: grayscale(30%) blur(13px);
    background-repeat: no-repeat;
    background-size: cover;
}
ul.massonary li img {
    width: auto;
    height: auto;
    max-height: 300px;
}
.view-another {
    clear: both;
    padding: 50px 0;
    text-align: center;
}
.view-another a {
    font-size: 16px;
    text-transform: uppercase;
}
.view-another a i {
    padding-right: 10px;
}
@media ( max-width: 1499px ) {
	ul.massonary li .image { height: 230px; }
	ul.massonary li img { max-height: 230px; }
	.location-single { top: 397px; }
}
@media ( max-width: 991px ) {
  ul.massonary li { width: 50%; }
  ul.massonary li:nth-child(2), ul.massonary li:nth-child(3), ul.massonary li:nth-child(6), ul.massonary li:nth-child(8) { width: 50%; }
  .location-single { top: 0;  }
}
@media ( max-width: 640px ) {
  ul.massonary li { width: 100%; }
  ul.massonary li:nth-child(2), ul.massonary li:nth-child(3), ul.massonary li:nth-child(6), ul.massonary li:nth-child(8) { width: 100%; }
  ul.massonary li .image { height: auto; }
  ul.massonary li img { max-height: 800px; }
  ul.massonary { margin-top: 30px; }
}
</style>

	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div class="inner-page-outer gallery-inner">
			<div class="large-container">
				
				<!-- <div class="location-single">
					<h2 class="large"><span>LOCATION :</span> SOUTH AFRICA</h2>
				</div> -->

				<ul class="massonary">
					<?php
					if( have_rows('gallery') ):
					    while ( have_rows('gallery') ) : the_row(); 
					        $image = get_sub_field('image');
					        $title = get_sub_field('image_title');
					        ?>
					        	<li>
							        <a class="grid-item1" href="<?php echo $image['url']; ?>" data-fancybox="images" data-caption="<?php echo $title; ?>" >
							        	<div class="background-image" style="background-image: url(<?php echo $image['url']; ?>);"></div>
							            <div class="image">
							              <img class="img-fluid" src="<?php echo $image['url']; ?>" />
							            </div>
							          </a>
							      </li>
					        <?php
					    endwhile;
					endif;

					?>


			    </ul>

			    <div class="view-another">
			    	<a href="<?php the_permalink(12); ?>"><i class="fa fa-angle-left" aria-hidden="true"></i>visit another country</a>
			    </div>

			</div>
		</div>
	</div>
<?php
	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
	get_footer();
?>