<?php
/*
Template Name: Bird Sites and Lodges
*/
?>
<?php
get_header();
if (have_posts()):
    while (have_posts()):
        the_post();
        ?>
        <link href="<?php echo get_template_directory_uri(); ?>/css/country-css.css" rel="stylesheet" type="text/css">
        <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
            <div class="inner-page-outer gallery">
                <div class="">
                    <div class="large-container">
                        <h1 class="large text-center"><?php the_title(); ?></h1>
                    </div>
                    <?php
                    // Get the 'recent-sites' term in the 'lodges_country' taxonomy
                    $recent_sites_term = get_term_by('slug', 'recent-sites', 'lodges_country');

                    if ($recent_sites_term):
                        ?>
                        <div class="large-container padding-bottom lodge-site-container">
                            <div class="lodge-country">
                                <h2 class="large text-left main-country"><?php echo esc_html($recent_sites_term->name); ?></h2>
                            </div>
                            <div class="lodge-grid">
                                <?php
                                // Query posts assigned to the 'recent-sites' term
                                $args1 = array(
                                    'post_type' => 'lodges',
                                    'posts_per_page' => 6,
                                    'orderby' => 'title',
                                    'order' => 'ASC',
                                    'tax_query' => array(
                                        array(
                                            'taxonomy' => 'lodges_country',
                                            'field' => 'term_id',
                                            'terms' => $recent_sites_term->term_id,
                                            'include_children' => false,
                                        ),
                                    ),
                                );
                                $lodges = new WP_Query($args1);
                                if ($lodges->have_posts()): ?>
                                    <?php while ($lodges->have_posts()): $lodges->the_post(); ?>
                                        <figure class="lodge-archive responsively-lazy">
                                            <a href="<?php the_permalink(); ?>" target="_self">
                                                <?php the_post_thumbnail("thumbnail"); ?>
                                            </a>
                                            <figcaption class="text-center">
                                                <h6><?php the_title(); ?></h6>
                                            </figcaption>
                                        </figure>
                                    <?php endwhile; ?>
                                    <?php wp_reset_postdata(); ?>
                                <?php else: ?>
                                    <p><?php _e('Sorry, no posts matched your criteria.', 'text-domain'); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php
                    else:
                        // Fallback if the 'recent-sites' term is not found
                        echo '<p>' . __('The "recent-sites" category could not be found.', 'text-domain') . '</p>';
                    endif;

                    $taxonomy = get_terms(array('taxonomy' => 'lodges_country', 'parent' => 0));
                    foreach ($taxonomy as $key => $lodge_country) {
                        if ($lodge_country->slug === "recent-sites") {
                            continue;
                        }
                        ?>
                        <div class="large-container padding-bottom lodge-site-container">
                            <div class="lodge-country">
                                <h2 class="large text-left main-country"><?php echo $lodge_country->name; ?></h2>
                            </div>
                            <div class="lodge-grid">
                                <?php
                                $args1 = array(
                                    'post_type' => 'lodges',
                                    'posts_per_page' => -1,
                                    'orderby' => 'title',
                                    'order' => 'ASC',
                                    'tax_query' => array(
                                        array(
                                            'taxonomy' => 'lodges_country',
                                            'field' => 'term_id',
                                            'terms' => $lodge_country->term_id,
                                            'include_children' => false
                                        )
                                    )
                                );
                                $lodges = new WP_Query($args1);
                                if ($lodges->have_posts()): ?>
                                    <?php while ($lodges->have_posts()):
                                        $lodges->the_post(); ?>
                                        <figure class="lodge-archive responsively-lazy">
                                            <a href="<?php the_permalink(); ?>" target="_self">
                                                <?php the_post_thumbnail("thumbnail"); ?>
                                            </a>
                                            <figcaption class="text-center">
                                                <h6><?php echo the_title(); ?></h6>
                                            </figcaption>
                                        </figure>
                                    <?php endwhile; ?>
                                    <?php wp_reset_postdata(); ?>
                                <?php else: ?>
                                    <!-- <p><?php _e('Sorry, no posts matched your criteria.'); ?></p> -->
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php
                        $myterms = get_terms(array('taxonomy' => 'lodges_country', 'parent' => $lodge_country->term_id));
                        foreach ($myterms as $lodge_cat) { ?>
                            <div class="large-container padding-bottom lodge-site-container">
                                <div class="lodge-country">
                                    <h2 class="large text-center"><?php echo $lodge_cat->name; ?></h2>
                                </div>
                                <div class="lodge-grid">
                                    <?php
                                    $args1 = array(
                                        'post_type' => 'lodges',
                                        'posts_per_page' => -1,
                                        'orderby' => 'title',
                                        'order' => 'ASC',
                                        'tax_query' => array(
                                            array(
                                                'taxonomy' => 'lodges_country',
                                                'field' => 'term_id',
                                                'terms' => $lodge_cat->term_id
                                            )
                                        )
                                    );
                                    $lodges = new WP_Query($args1);
                                    if ($lodges->have_posts()): ?>
                                        <?php while ($lodges->have_posts()):
                                            $lodges->the_post(); ?>
                                            <figure class="lodge-archive responsively-lazy">
                                                <a href="<?php the_permalink(); ?>" target="_self">
                                                    <?php the_post_thumbnail("thumbnail"); ?>
                                                </a>
                                                <figcaption class="text-center">
                                                    <h6><?php echo the_title(); ?></h6>
                                                </figcaption>
                                            </figure>
                                        <?php endwhile; ?>
                                        <?php wp_reset_postdata(); ?>
                                    <?php else: ?>
                                        <p><?php _e('Sorry, no posts matched your criteria.'); ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php }
                    } ?>
                </div>
            </div>
        </div>
        <?php
    endwhile;
else:
endif;
wp_reset_postdata();
wp_reset_query();
get_footer();
?>
<style>

.lodge-grid {
    display: grid;
    grid-template-columns: repeat(6, 1fr); /* Fixed 6 columns */
    gap: 20px; /* Adjust the gap between items */
}

.lodge-archive {
    padding: 5px;
    position: relative;
    margin-bottom: 25px;
    -webkit-transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
    text-align: center; /* Center align content */
}

.lodge-archive img {
    width: 100%;
    -webkit-transition: all 0.6s ease-in-out;
    -moz-transition: all 0.6s ease-in-out;
    transition: all 0.6s ease-in-out;
}

.lodge-archive:hover img {
    -webkit-transform: scale(1.1, 1.1);
    -moz-transform: scale(1.1, 1.1);
    -o-transform: scale(1.1, 1.1);
    transform: scale(1.1, 1.1);
}

.lodge-archive a {
    display: inline-block;
    overflow: hidden;
    border: 1px solid transparent;
    margin-bottom: 0 !important;
    width: 100%;
}

.lodge-archive:hover a {
    border-color: #F6EC01; /* Yellow border on hover */
}

.lodge-archive figcaption h6 {
    text-transform: uppercase;
    font-size: 15px;
    margin-top: 10px;
    text-align: left; /* Align text to the left */
    font-weight: 500;
    -webkit-transition: all 0.3s ease-in-out;
    -moz-transition: all 0.3s ease-in-out;
    transition: all 0.3s ease-in-out;
    margin: 0;
}

.lodge-archive:hover figcaption h6 {
    color: #F6EC01; /* Yellow text on hover */
}
</style>
