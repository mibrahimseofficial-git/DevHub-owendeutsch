<?php
/*
Template Name: Globe
*/
?>
<?php
  get_header(); 
  if( have_posts() ) : while( have_posts() ) : the_post();
?>
<link href="<?php echo get_template_directory_uri(); ?>/css/country-css.css" rel="stylesheet" type="text/css">
<script src="<?php echo get_template_directory_uri(); ?>/js/d3.min.js"></script>

<!-- jQuery is provided by WordPress core (loaded in the document head). -->
<!-- Bootstrap JavaScript -->
<script src="<?php echo get_template_directory_uri(); ?>/js/bootstrap-5.3.0.bundle.min.js"></script>

<!-- d3.min.js, topojson.v1.min.js and queue.v1.min.js are enqueued globally in
     functions.php (theme_name_scripts) and are already loaded in the head. -->

<?php  
    global $wpdb;
    $terms      = get_terms( array(
                        'taxonomy' => 'cp_birds_country',
                        'hide_empty'=> true )
                  );
   // pr($terms);  
   function dates_sort1($a, $b) {  
    return strtotime($a) - strtotime($b);
  }
   $_termsfinal = array();
    foreach ($terms as $key => $countryrow ) 
    {
        $term_link          = get_term_link( strtoupper($countryrow->slug), 'cp_birds_country');
        $cat_term_id        = $countryrow->term_id;
        $p_repeater         = get_field('post_schedule', $countryrow->taxonomy . '_' . $countryrow->term_id);
       
        $current_date       = date('Y-m');
       
        if(($countryrow->count != 0) && (!empty($p_repeater)))
        { 
          foreach ($p_repeater as $key=>$row) 
          { 
            //pr("catid--".$cat_term_id);
           // echo "\n";
            if(!empty($row['display_post'])){
              foreach($row['display_post'] as $innerkey => $display_post){ 
                  $display_post_terms = wp_get_post_terms($display_post->ID, 'cp_birds_country', array("fields" => "ids"));
                  $display_post_term = !empty($display_post_terms)?$display_post_terms[0]:''; 
                
                  if($cat_term_id != $display_post_term){
                      unset($p_repeater[$key]['display_post'][$innerkey]);
                  } 
                  
              }
              if(!empty($p_repeater[$key]['display_post'])){ 
                $current_date   = date('Y-m');
                $row['postmonth'] = (strlen($row['postmonth']) == 1)? '0'.$row['postmonth']:$row['postmonth'];
                $postdate = $row['postyear'].'-'.$row['postmonth'];
                if(strtotime(date('Y-m',strtotime($postdate))) <= strtotime($current_date) && !empty($row['display_post']))
                 { $p_repeater[$key]['postdate'] = $postdate;}
                 
              }
            }
            } 
         
          $temppostyear = array_column($p_repeater, 'postdate');
          usort($temppostyear , "dates_sort1");

          $_termsfinal[$cat_term_id] = end($temppostyear);
          $termsslog[$cat_term_id] = $countryrow->slug;
          $termname[$cat_term_id] = $countryrow->name;
        }
        else{ // repeater not assign any value empty then make country = 0;
            $wpdb->update(
                    $wpdb->prefix.'mapsvg_regions_486', 
                    array(
                      'status' => '0',  // string // no dispaly on frnt
                      'status_text' => 'Disabled',
                      'external_link' => NULL,
                    ),
                    array( 'id' => strtoupper($countryrow->slug) )
              );
        }
                      
      }
      foreach($_termsfinal as $terms =>$value){
        if(empty($value)){
              //  value empty then make country = 0;
             $wpdb->update(
              $wpdb->prefix.'mapsvg_regions_486', 
              array(
                'status' => '0',  // string
                'status_text' => 'Disabled',
                'external_link' => NULL,
              ),
              array( 'id' => strtoupper($termsslog[$terms] ))
            );  
            unset($_termsfinal[$terms]);
        } else {   //  value empty then make country = 0;
          $wpdb->update( 
            $wpdb->prefix.'mapsvg_regions_486', 
            array(
              'status' => '1',  // string //dispaly front side 
              'status_text' => 'Enabled',
              'external_link' => $term_link,
            ), 
            array( 'id' => strtoupper($termsslog[$terms]))
          );
         }
      }
     
?> 
  <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
    <div class="inner-page-outer gallery">
      <div class="">
        <div class="large-container"><div class="gallery-tabs">
        <ul class="nav nav-tabs text-center" id="navcountry">
            <li class="active"><a  href="/globe/#map-view"><i class="fa fa-map-marker" aria-hidden="true"></i>Globe View</a></li>
            <li><a href="/grid/#grid-view"><i class="fa fa-th-large" aria-hidden="true"></i>Grid View</a></li>
          </ul>
        </div></div>
        <div class="gallery-content text-center">
          <div class="tab-content">
              <div id="map-view" class="country-globe tab-pane fade in active">
                <div class="large-container padding-bottom">
                <h1 class="large"><?php echo get_field('c_page_title') ?: esc_html( get_the_title() ); ?></h1>
                <p><?php echo get_field('c_page_sub_title'); ?></p>
                 <p class="color-yellow"><?php echo get_field('c_page_tag_line'); ?></p>  
                </div>
                  <div class="load-map bb">
                    <!-- <div class="globe-loader">
  						 	<img src="<?php echo $HOME_URL; ?>/wp-content/uploads/2019/08/globe_loader-.gif" alt="globe loader">
  					  </div> -->
                      <?php echo do_shortcode('[map]'); ?>
                  </div>
              </div>
              <div id="grid-view" class="tab-pane fade">
              <div class="large-container">
                <div class="imglist row">
                  <?php
                     
                    //  pr($_termsfinal);
                      if ( !empty($_termsfinal) )
                      { 
                        //pr($_termsfinal);
                        foreach ($_termsfinal as  $terms1 =>$value) 
                        {
                          $term_slug_upper    = strtoupper($termsslog[$terms1]);
                          $term_slug_name    = strtoupper($termname[$terms1]);
                          $term_permalink     = get_term_link($termsslog[$terms1], 'cp_birds_country');
                          $thumbnail          = get_field('country_image', 'cp_birds_country_'. $terms1);
                          $previous_date      = get_term_meta( $terms1, 'country_schedule_date');
                          $post_repeater      = get_field('post_schedule', 'cp_birds_country_' . $terms1);
                          $displayDate        = explode('-',$value); 
                          $current_date       = date('Y-m');
                         
                          $img_name = array();
                          // pr($post_repeater['img_data']);
                          if(!empty($post_repeater)){
                            foreach ($post_repeater as $key=>$row) {
                                    $d = $post_repeater[$key]['postdate'] = $row['postyear'].'-'.$row['postmonth']; 
                                    if(!isset($img_name[$d])){
                                      $img_name[$d] = $post_repeater[$key]['display_schedule_image'];
                                    }
                            }  /*Foreach loop*/
                            $post_repeater['img_data'] = $img_name; 
                            
                            $current_fetured_img = array(); 
                            foreach ($post_repeater as $key=>$rows) 
                            {   
                                $rows['postmonth'] = (strlen($rows['postmonth']) == 1)? '0'.$rows['postmonth']:$rows['postmonth'];
                                // pr($rows['postmonth']."-".$rows['postyear']);
                                // pr($rows['display_schedule_image']);
                                if ( $rows['display_post'] ) {
                                  foreach($rows['display_post'] as $innerKey=>$row){
                                    $grid_post_term = wp_get_post_terms($row->ID, 'cp_birds_country', array("fields" => "ids"));
                                    $grid_post_terms = !empty($grid_post_term)? $grid_post_term[0] :'';  
                                    if($terms1 != $grid_post_terms){  
                                      unset($post_repeater[$key]['display_post'][$innerKey]);
                                    } 
                                  }
                                }
                                
                                $postdate1 = $rows['postyear'].'-'.$rows['postmonth']; 
                                $current_month_img = (!empty($rows['display_schedule_image'])) ? $rows['display_schedule_image'] : $thumbnail;
                                //pr($post_repeater['img_data']);
                                
                                $secondaryArray = array();
                                  // pr($post_repeater['img_data']);
                                  foreach ($post_repeater['img_data'] as $key => $valueimg) {

                                      if (strtotime(date('Y-m',strtotime($key))) <= strtotime($current_date) &&  $valueimg !='') {
                                          $secondaryArray[$key] = $valueimg;
                                          // pr($secondaryArray);
                                      }
                                  }
                                  //pr($secondaryArray);
                                  if(!empty($secondaryArray)){ 
                                    usort($secondaryArray, "dates_sort1");
                                    $img = end($secondaryArray);
                                  }else {
                                    $default_placeholder_image = get_template_directory_uri()."/images/placeholder-bird.png";
                                    $thumbnail = (!empty($thumbnail)) ? $thumbnail : $default_placeholder_image;
                                    $img = $thumbnail;
                                  }
                            }

                            
                              // if(!empty($rows['display_post']) && $rows['postyear'] == $displayDate[0] && $rows['postmonth'] == $displayDate[1]){
                            ?>

                                <figure class="col-md-2 on-hover">
                                    <a href="<?php echo $term_permalink; ?>" target="_self">
                                      <img class="img-fluid" src="<?php echo $img; ?>" alt="<?php echo esc_attr( $termname[$terms1] ); ?>" />
                                    </a>
                                    <figcaption class="text-center">
                                      <h6><?php echo $termname[$terms1];?></h6>
                                    </figcaption>
                                </figure>
                             <?php
                              // }
                           }
                          
                        }
                      }// term for close; 
                  ?>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php
  endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
  get_footer();
  
?>
<script>
var $ = jQuery;
$( document ).ready(function() {
	var url = location.href.replace(/\/$/, "/");
 	if (location.hash) {
    var hash = url.split("#");
    $('#navcountry a[href="#'+hash[1]+'"]').tab("show");
    url = location.href.replace(/\/#/, "/#");
    history.replaceState(null, null, url);
  } 
  $('a[data-toggle="tab"]').on("click", function() {
    // alert('in');
    var newUrl;
    var hash = $(this).attr("href");
    newUrl = url.split("#")[0] + hash;
    //newUrl += "/";
    history.replaceState(null, null, newUrl);
    setTimeout(function(){ 
			jQuery('html, body').animate({
				scrollTop: jQuery("body").offset().top - 120
			}, 1000)
		}, 200);
  });
  $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
      localStorage.setItem('activeTab', $(this).attr('href'));
      // alert(localStorage.setItem('activeTab', $(this).attr('href')););
  });

  var activeTab = localStorage.getItem('activeTab');
  // alert(activeTab);
  if(activeTab){
      $('#navcountry a[href="' + activeTab + '"]').trigger('click');
      // $('#navcountry a[href="' + activeTab + '"]').tab('show');
  }
});

 $('a[data-toggle="tab"]').on('show.bs.tab', function(e) {
      localStorage.setItem('activeTab', $(this).attr('href'));
      // alert(localStorage.setItem('activeTab', $(this).attr('href')););
  });
$(window).bind("pageshow", function(event) {
    if (event.originalEvent.persisted) {
        location.reload(true);
     }
});
var $ = jQuery;
$( document ).ready(function() {
	var url = location.href.replace(/\/$/, "/");
 	if (location.hash) {
    var hash = url.split("#");
    $('#navcountry a[href="#'+hash[1]+'"]').tab("show");
    url = location.href.replace(/\/#/, "/#");
    history.replaceState(null, null, url);
    
  } 
   
  $('a[data-toggle="tab"]').on("click", function() {
    var newUrl;
    var hash = $(this).attr("href");
    newUrl = url.split("#")[0] + hash;
    //newUrl += "/";
    history.replaceState(null, null, newUrl);
  });
});
$(window).bind("pageshow", function(event) {
    if (event.originalEvent.persisted) {
        location.reload(true);
     }
});
</script>