<?php
/*
 *  This is Standard Post Format Template
 */
?>
<div class="container">
	
	<?php if ( have_posts() ) : the_archive_title( '<h1 class="page-title">', '</h1>' );  endif; ?>

	<div class="row">
		<div class="col-xs-12 col-sm-8">

			<?php if( have_posts() ) : while( have_posts() ) : the_post(); ?>
				
				<div class="story post-content clearfix">
					<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">

						<?php  if ( has_post_thumbnail() ) { $bgrid1 = '8'; $bgrid2 = '7'; } else { $bgrid1 = '12'; $bgrid2 = '12'; }  ?>
						<div class="post-title">
							<h4><a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a></h4>
						</div>
						<div class="post-info clearfix">
							<span class="post-date"><?php the_time( 'F j, Y' ); ?></span>
							<?php if(is_sticky() ) { ?> <span class="post-sticky">Sticky</span>  <?php } ?>
						</div>

						<div class="row">
							<?php if(has_post_thumbnail() ) : ?>
								<div class="col-xs-12 col-sm-4">
									<div class="post-featured"><?php the_post_thumbnail( 'medium' ); ?></div>
								</div>
							<?php endif; ?>

							<div class="col-xs-12 col-sm-<?php echo $bgrid2; ?> col-md-<?php echo $bgrid1; ?>">
								<div class="story-content clearfix">
									<?php the_excerpt(); ?>
								</div>
								<a href="<?php the_permalink(); ?>" class="read-more">Read More</a>
							</div>
						</div>

					</div>
				</div>

			<?php
				endwhile;
					the_posts_pagination( array(
						'prev_text' => __( '', 'theme' ),
						'next_text' => __( '', 'theme' )
					) );
				else:
			?>
				
				<h2 class="error"><?php _e( 'Not Found.','theme' ); ?></h2>
				<p class="error">Sorry, but you are looking for something that isn't here.</p>
				
			<?php endif; wp_reset_query(); wp_reset_postdata(); ?>

		</div>

		<?php get_sidebar(); ?>
	</div>

</div>