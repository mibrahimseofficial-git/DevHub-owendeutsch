<?php
/*
Template Name: Conservation
*/
?>
<?php get_header(); ?>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/fancybox-common.css">
<?php if( have_posts() ) : while( have_posts() ) : the_post(); ?>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div class="inner-page-outer conservation">
			<div class="conservation-title">
				<h1 class="large text-center"><?php echo get_field('conservation_title'); ?></h1>
				<p class="text-center color-white"><?php echo get_field('conservation_description'); ?></p>
			</div>
			<div class="container">
				<?php
					$cgallery = get_field('conservation_gallery');
					$img_name = array();
					if(!empty($cgallery)){ 
						foreach ($cgallery as $key=>$row) {
							$d = $key; 
								if(!isset($img_name[$d])){
									$img_name[$d] = $row['gallery_image']['url'];
								}
							}  /*Foreach loop*/
							$cgallery['img_data'] = $img_name; 
					} 
					$ImageArray = array();
					foreach($cgallery['img_data'] as $key=>$value){ 
						$ImageArray[$key] = $value;
					} 
					$img = $ImageArray;
					?>
				<ul class="conservation-gallery">
					<?php 
						$conservation_gallery = get_field('conservation_birds_details'); 
						if(is_array($conservation_gallery)){
							foreach ($conservation_gallery as $key => $gallery) {
								$galleryid = $gallery->ID;
								$default_placeholder_image = get_template_directory_uri()."/images/placeholder-bird.png";
								$feat_image_full = wp_get_attachment_image_src( get_post_thumbnail_id( $galleryid ), 'full', false );
								$feat_image_full_src = !empty( $feat_image_full[0] ) ? $feat_image_full[0] : $default_placeholder_image;
								
								$iframedata = get_field('bird_sounds', $galleryid );
								
								?>
								<li data-cspostid=<?php echo $galleryid; ?>>
									<div class="conservationgallery" data-fancybox="conservation-gallery" href="<?php echo $feat_image_full_src; ?>">

										<img class="img-fluid" src="<?php echo $img[$key]; ?>" alt="<?php echo $gallery->post_title; ?>" />
										<div class="image-title">
										<?php if( !empty($iframedata) ) { ?>
												<div class="music-symbol">
												<img src="<?php echo $HOME_URL; ?>/wp-content/uploads/2019/08/musical-notes-symbols-2.png" alt="music">
											</div>
											<?php } ?>
											<?php $trimtitle = $gallery->post_title; 
													//pr(trim($trimtitle,'-'));
													$title = trim($trimtitle);
													_e($title,'owen'); ?>
										</div>
										<!--Bird Detail Layout Start-->
										<figcaption>
											<div class="countrydetails">
											<h4 data-postid=<?php echo $galleryid; ?>>
												<?php echo get_the_title($galleryid); ?>
											</h4>
											<?php /*<h3><?php echo 'ID : ' . $galleryid; ?></h3>*/ ?>
											<div class="custom-table">
                                            <div class="row">
                                              <div class="col-md-6">
                                                <?php 
                                                    $get_order = get_field('bird_family',$gallery->ID);
                                                    if(!empty($get_order)){ 
                                                    $search_order = mb_strtolower($get_order);
                                                    $search_order_url = site_url() . '/?s=&birdfamily='.od_search_param($search_order);
                                                  ?>
                                                    <h5>Order</h5>
                                                    <a href="<?php echo $search_order_url; ?>" class="whitebtn"><?php echo $search_order; ?></a>
                                                  <?php } ?>
                                              </div>
                                              <div class="col-md-6">
                                                  <?php 
                                                    $get_family = get_field('bfamily',$gallery->ID);
                                                    if(!empty($get_family)){ 
                                                    $search_get_family = mb_strtolower($get_family);
                                                    $search_family_url = site_url() . '/?s=&family='.od_search_param($search_get_family);
                                                  ?>
                                                    <h5>Family</h5>
                                                    <a href="<?php echo $search_family_url; ?>" class="whitebtn"><?php echo $search_get_family; ?></a>
                                                  <?php } ?>
                                              </div>
                                            </div>
                                            <div class="row">
                                              <div class="col-md-6">
                                                <h5>Genus <span>( Similar Species )</span>
                                                  <?php
                                                  $gettxgenus = get_field('bird_taxonomic_genus',$gallery->ID);
                                                    if(!empty($gettxgenus)) { 
                                                    $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.od_search_param($gettxgenus);
                                                  ?>
                                                  
                                                    <div class="specbtn">
                                                      <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo $gettxgenus; ?></a>
                                                    </div>
                                                  <?php } ?>
                                              </div>
                                              <?php if(!empty(get_field('bird_scientific_name',$gallery->ID))) { ?>
                                                <div class="col-md-6">
                                                  <h5>Scientific Name</h5>
                                                  <h6><?php echo get_field('bird_scientific_name',$gallery->ID); ?></h6>
                                                </div>
                                            <?php } ?>
                                            </div>
                                           </div>
											<ul>
												<li>
													<?php /*if(!empty(get_field('bird_scientific_name',$galleryid))) { ?>
															<h5>Scientific Name</h5>
															<h6><?php echo get_field('bird_scientific_name',$galleryid); ?></h6>
													
													<?php } 
														$gettxgenus = get_field('bird_taxonomic_genus',$galleryid);
														if(!empty($gettxgenus)) { 
														$gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.od_search_param($gettxgenus);
													?>
													
														<div class="specbtn">
															<a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo "Similar Species"; ?></a>
														</div>
													<?php   } */?>
												</li>
												<?php
												$get_status = get_field('bird_conservation_status',$galleryid);
												if(!empty($get_status)) { 
												$search_status = strtolower($get_status);
												$search_status_url = site_url() . '/?s=&conservancy='.od_search_param($search_status);
												?>
													<li>
														<h5>Conservation Status</h5>
														<a class="whitebtn" href="<?php echo $search_status_url; ?>">
															<?php echo $get_status; ?>
														</a>
													</li>
											<?php } ?>
											<?php 
											    $terms = wp_get_post_terms($galleryid, 'cp_birds_country');
                                                if( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
													$taxonomy = $terms[0]->name;
													$search_country = strtolower($taxonomy);
													$search_country_url = site_url() . '/?s=&country='.od_search_param($search_country);
                                                    ?>
                                                        <li>
                                                            <h5>Country</h5>
                                                            
															<div class="newcountrybtns">
                                                              	<a class="whitebtn" href="<?php echo $search_country_url; ?>">
																	<?php echo $taxonomy; ?>
																</a>
	                                                              <a href="<?php echo site_url().'/countries/'; ?>" class="whitebtn">
	                                                                View more Countries
	                                                              </a>
                                                            </div>
                                                        </li>
                                                    <?php 
                                                } if(!empty(get_field('bird_gender',$galleryid))){ 
											?>
													<li>
														<h5>Gender </h5>
														<h6><?php echo get_field('bird_gender',$galleryid); ?></h6>
													</li>
											<?php } if(!empty(get_field('bird_age',$galleryid))) { ?>
													<li>
														<h5>Age</h5>
														<h6><?php echo get_field('bird_age',$galleryid); ?></h6>
													</li>
											<?php } 
													$getvc = get_field('bird_visual_country',$galleryid);
													if(!empty($getvc)){
													$search_vc = strtolower($getvc);
													$search_vc_url = site_url() . '/?s=&visualcategory='.od_search_param($search_vc);
													?>
													<li>
														<h5>Visual Category</h5>
														<a class="whitebtn" href="<?php echo $search_vc_url; ?>"><?php echo $getvc; ?></a>
													</li>
											<?php } 
													$getloc = get_field('bird_locations_multi',$galleryid);
													if(!empty($getloc) && isset($getloc)) { ?>
													<li>
														<h5>Birding Sites and Lodges</h5>
														<?php 
															if($getloc != ''){
																
																foreach ($getloc as $post) {
																	if (isset($post->post_title)) {
																		$getlocurlMulti = od_location_search_url( $post->post_title );
																		?>
																		<a class="whitebtn" href="<?php echo $getlocurlMulti ?>" target="_self">
																			<?php echo $post->post_title; ?>
																		</a>
																		<?php
																	}
																	if(!empty($post) && !isset($post->post_title)) {
																		$get_title_lodges = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($post) AND post_status = 'publish'", ARRAY_N);
																		$lodges_postidtit = array_column($get_title_lodges, 0);
																		$getlocurlMulti = od_location_search_url( $lodges_postidtit[0] );
																		?>
																		<a class="whitebtn" href="<?php echo $getlocurlMulti; ?>" target="_self">
																			<?php echo $lodges_postidtit[0]; ?>
																		</a>
																		<?php
																	}	
																}
															}
														?>
													</li>
											<?php } ?>
											<?php 
												/*$getbf = get_field('bird_family',$galleryid);
												if(!empty($getbf)) { 
												$search_bf = strtolower($getbf);
												$search_bf_url = site_url() . '/?s=&birdfamily='.od_search_param($search_bf);
												?>
													<li>
														<h5>Order</h5>
														<a class="whitebtn" href="<?php echo $search_bf_url; ?>"><?php echo $getbf; ?></a>
													</li>
											<?php } */
												$get_activity = get_field('bird_activity',$galleryid);
												if(!empty($get_activity) && isset($get_activity)) { ?>
													<li>
														<h5>Activity</h5>
														<?php
															if($get_activity != ''){
															$explodeactivity = explode(",",$get_activity);
															foreach ($explodeactivity as  $activityrow) {
																$search_activityurl = site_url() . '/?s=&activity='.od_search_param($activityrow);
														?>
																<a class="whitebtn" href="<?php echo $search_activityurl; ?>" >
																<?php echo $activityrow; ?>
															</a>
														<?php } } ?>
													</li>
												<?php } ?>
											</ul>
											<?php if(!empty($iframedata)){?>
												<div class="iframeappend">
													<?php $removelastcomma = rtrim($iframedata, ','); ?>
	                                                <input type="hidden" id="custId" name="custId" value="<?php echo $iframedata; ?>">
													<img class="iframeloader" src="<?php echo get_template_directory_uri(). '/images/loader.svg'; ?>" alt="Page Loader"> 
												</div>
											<?php } ?>
											</div>
											<!-- 
                                            <a href="<?php //echo site_url().'/?s=&country='.strtolower($taxonomy); ?>" class='country_btn'>
                                            See all birds from <?php //echo $taxonomy; ?>
                                            </a> -->
										</figcaption>
										<!--Bird Detail Layout End-->

									</div>
								</li>
								<?php # code...
							}
						}
						?>
				</ul>
				<h2 class="Conservation_h2" style="text-align:center"><?php echo get_field('conservation_title_second'); ?></h2>
				<!--  Section New Book   -->
				<section  class="owen-new-book two-column-center cmn-padding">
					<div class="">
						<div class="responsive-image">
							<?php $about_img = get_field('owens_book_image'); ?>
							<img src="<?php echo $about_img['url']; ?>" alt="<?php echo $about_img['alt']; ?>">
						</div>
						<div class="content">
							<?php echo get_field('owens_book_title'); ?>
							<p><?php echo get_field('owens_book_desciption'); ?></p>
							<?php if( !empty( get_field('owens_book_button_link') ) && !empty( get_field('owens_book_button_text') ) ) { ?>
										<a href="<?php echo get_field('owens_book_button_link'); ?>" target="_blank" class="yellow-btn">
											<?php echo get_field('owens_book_button_text'); ?>
										</a>
							<?php } ?>
						</div>
						<div class="image responsive-hide">
							<img src="<?php echo $about_img['url']; ?>" alt="<?php echo $about_img['alt']; ?>">
						</div>
					</div>
				</section>
				<!--  End   -->
			</div>
		</div>
	</div>
<?php
	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 
	get_footer();
?>
<script type="text/javascript">
    var $ = jQuery;
jQuery( document ).ready( function() {
	
    jQuery('[data-fancybox="conservation-gallery"]').fancybox({
    baseClass: "fancybox-conservation-layout",
    loop: true,
    touch: false,
    wheel:false,
    buttons: ["close", "slideShow","fullScreen"],
    animationEffect: "fade",
    transitionEffect: "fade",
	preventCaptionOverlap: false,
	clickSlide:false,
	clickOutside:false,
    idleTime: false,
    gutter: 0,
    // Customize caption area
    caption : function( instance, item ) {
        return $(this).find('figcaption').html();
    },
    afterShow: function( instance, current ) {
        var currentDivNo = instance.currIndex;
        /*Iframe Logic Load After Fancybox Load */
		var iframestr   =  $(".conservationgallery:eq("+currentDivNo+")").find('#custId').val();
		// alert(iframestr);
        if(iframestr != ''){
			
			var ifrmaesplit = iframestr.split(',');
			var ihtml = '';
            for(var i = 0; i < ifrmaesplit.length; i++) {
				// Trim the excess whitespace.
				ifrmaesplit[i] = ifrmaesplit[i].replace(/^\s*/, "").replace(/\s*$/, "");
				/*Add additional code here, such as:*/
				
				ihtml +="<iframe src='https://www.xeno-canto.org/"+ifrmaesplit[i]+"/embed?simple=1&darkbg=1' height='110' width='100%' frameborder='0' scrolling='no'></iframe>";
				
			} console.log(ihtml);
			$(".fancybox-container").contents().find( ".fancybox-caption").find('.countrydetails').find(".iframeappend" ).append(ihtml);
			$(".fancybox-caption .iframeappend iframe").load(function(){
				$(".iframeloader").hide();
			});
		}
    }
});
});
</script>