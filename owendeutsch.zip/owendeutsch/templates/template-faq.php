<?php

/*

Template Name: Faq

*/

?>

<?php

	get_header(); 
  ?>
  <script>
  var $ = jQuery;
  $(window).load(function(){
    var hash = window.location.hash;
    if (hash == '#collapse1') {
        var headerheight = $('header').outerHeight();
        
        $('html, body').animate({
            scrollTop: $("#collapse1").offset().top - headerheight - 70
        }, 1000);
        
        
        $('#collapse1').addClass('in');
        $('#heading1 h2 button').removeClass('collapsed');
        $('#collapse4').removeClass('in');
        $('#heading4 h2 button').addClass('collapsed');
        //$("#heading4").attr("aria-expanded","true");
    }
  });
  

  </script>

  <?php
	if( have_posts() ) : while( have_posts() ) : the_post();

?>

	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div class="inner-page-outer faq">
			<div class="container">
			  <h1 class="large text-center"><?php the_title(); ?></h1>
	      <div class="accordion" id="accordionExample">
	
          <?php
          $i = 1;
            if( have_rows('faq') ):
                while ( have_rows('faq') ) : the_row();
                    ?>
                        <div class="card">
                            <div class="card-header" id="heading<?php echo $i; ?>">
                              <h2 class="mb-0">
                                <button class="btn btn-link <?php if($i > 1) { echo "collapsed"; } ?>" type="button" data-toggle="collapse" data-target="#collapse<?php echo $i; ?>" aria-expanded="true" aria-controls="collapse<?php echo $i; ?>">
                                  <?php the_sub_field('faq_title'); ?>
                                </button>
                              </h2>
                            </div>
                            <div id="collapse<?php echo $i; ?>" class="collapse <?php if ( $i == 1 ) { echo "in"; } ?>" aria-labelledby="heading<?php echo $i; ?>" data-parent="#accordionExample">
                              <div class="card-body">
                                <?php the_sub_field('faq_description'); ?>
                              </div>
                            </div>
                        </div>
                    <?php
                    $i++;
                endwhile;
            endif;
            
            ?>
        </div>
      </div>
    </div>
  </div>
      <?php

	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 

	get_footer();

?>
