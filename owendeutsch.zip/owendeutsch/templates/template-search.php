<?php
/*
* Template Name: Search Template
*/
get_header();
$search         = isset($_GET['s']) ? $_GET['s'] : '';
$search         = stripcslashes($search);
$country        = isset($_GET['country']) ? $_GET['country'] : '';
$gender         = isset($_GET['gender']) ? $_GET['gender'] : '';
$minage         = isset($_GET['minage']) ? $_GET['minage'] : '';
$age            = isset($_GET['age']) ? $_GET['age'] : '';
$maxage         = isset($_GET['maxage']) ? $_GET['maxage'] : '';
$conservancy    = stripcslashes (isset($_GET['conservancy']) ? $_GET['conservancy']: '');
$activity_value = stripcslashes(isset($_GET['activity']) ? $_GET['activity'] : '');
$birdfamily     = stripcslashes(isset($_GET['birdfamily']) ? $_GET['birdfamily'] : '');
$taxonomicgenus = stripcslashes(isset($_GET['taxonomicgenus']) ? $_GET['taxonomicgenus'] : '');
$locations      = stripcslashes(isset($_GET['locations']) ? $_GET['locations'] : '');
$visualcategory = stripcslashes(isset($_GET['visualcategory']) ? $_GET['visualcategory'] : '');
$sorting_option = stripcslashes(isset($_GET['sorting_option'])) ? $_GET['sorting_option'] : '';
$exit = 0;
if(!empty($search) || !empty($country) || !empty($gender) || !empty($age) || !empty($minage) || !empty($maxage) || !empty($conservancy) || !empty($activity_value) || !empty($birdfamily) || !empty($taxonomicgenus) || !empty($locations) || !empty($visualcategory))  {
    $exit = 1;
}
?>
<style type="text/css">

/*** radio button style start */

select#sorting_option {
       position: relative;
       left: unset;
       top: 10px;
       padding: 15px 10px 15px 10px;
       border-radius: 50px;
       border: 0;
       font-weight: 500;
       margin: 0;
       width: 100%;
   }
   div#radio_buttons {
       display: flex;
       align-items: center;
       justify-content: space-evenly;
       margin: 10px 0 0 0;
   }
   input[name='sorting_option']:before {
       content: '';
       display:block;
       width:60%;
       height:60%;
       margin: 20% auto;
       border-radius:50%;
       /* background: white; */
   }

   input[name='sorting_option']:checked:before {
       background: #fff600;
   }

   input[name='sorting_option'] {
       -webkit-appearance: none;
       width: 15px;
       height: 15px;
       border: 1px solid #fff600;
       border-radius: 50%;
       outline: none;
       box-shadow: 0 0 5px 0px grey inset;
       margin-right: 4px;
   }
   div#radio_buttons label {
       font-size: 14px;
       font-weight: 500;
       color: white;
   }

   div#radio_buttons .form-check {
       display: flex;
       align-items: flex-start;
   }

   /*** radio button style end */

   .container-search {padding: 0 50px;margin: auto;}
   .custom-dropdown > span {text-transform: capitalize;}
   @media ( min-width: 1300px ) {.container-search { width: 1260px; }}
   @media ( min-width: 1550px ) {.container-search { width: 1450px; }}
   @media ( max-width: 1200px ) {.relates-search-option a.clear-search { position: relative; top: 0; right: 0; }}
   @media ( max-width: 991px ) {.container-search { padding: 0 15px; }}
   @media ( max-width: 500px ) {ul.search-related li, ul.search-results li { width: 100%; margin-right: 0; }}
   figcaption { display: none; }
   @media all and (min-width: 600px) {
       /* Change color for backdrop */
       .fancybox-search-layout .fancybox-bg {background: #fcfaf9;}
       .fancybox-search-layout.fancybox-is-open .fancybox-bg {opacity: 1;}
       /* Move caption area to the right side */
       .fancybox-search-layout .fancybox-caption {background: #121212;bottom: 0;color: #6c6f73;left: auto;padding: 30px 20px;right: 0;top: 0;width: 300px; }
       .fancybox-search-layout .fancybox-caption h3 {color: #444;font-size: 21px;line-height: 1.3;margin-bottom: 24px;}
       .fancybox-search-layout .fancybox-caption a {color: #444;}
       /* Remove gradient from caption*/
       .fancybox-search-layout .fancybox-caption::before {display: none;}
       /* Adjust content area position */
       .fancybox-search-layout .fancybox-stage {right: 300px;}
       /* Navigation arrows */
       .fancybox-search-layout .fancybox-navigation .fancybox-button div {padding: 2px;}
       .fancybox-search-layout .fancybox-navigation .fancybox-button[disabled] {color: #ddd;}
       .fancybox-search-layout .fancybox-navigation .fancybox-button:not([disabled]) {color: #333;}
       /* Reposition right arrow */
       .fancybox-search-layout .fancybox-button--arrow_right {right: 308px;}
   }
   @media (max-width: 599px) {
       .fancybox-caption {
           height: auto;
           z-index: 99999;
           display: block;
           padding: 10px;
           background: rgba(0,0,0,0.7);
       }
   }
   
</style>
<div class="inner-page-outer search">
    <div class="container-search text-center">
        <div class="row">
            <div class="col-md-12">
                <h1 class="large search-title">Search</h1>
            </div>
        </div>
        <?php 
            $search_subline = get_field('search_subline','option'); 
            $filter_heading = get_field('search_filter_heading','option'); 
            $filter_subtitles = get_field('search_filter_subtitles','option'); 
            if(!empty($search_subline)){ 
        ?>
                <div class="needhelp"><a href="/faq/#collapse1"><?php echo $search_subline; ?></a></div>
        <?php }
            $search_short_content = get_field('search_short_content','option');
            if(!empty($search_short_content)){ ?>
                <p><?php echo $search_short_content; ?></p>
            <?php } 
        ?>
        
        <div class="search-group">
            <div class="search-input">
                <form action="javascript:;" method="get" id="my-ajax-filter-search">
                    <input id="searchfocus" class="search-text" type="text" name="s" placeholder="Enter bird species name or keywords" value="<?php echo $search; ?>" autofocus>
                    <div id="radio_buttons">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="sorting_option" id="sorting_option3" value="by_tags" <?php echo ( !empty($sorting_option) && $sorting_option=='by_tags' ) ? 'checked' : '';  ?>>
                                <label class="form-check-label" for="sorting_option3">
                                    Location
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="sorting_option" id="sorting_option2" value="exact_match" <?php echo ( !empty($sorting_option) && $sorting_option=='exact_match' || (!isset($_GET['sorting_option'])) || ( empty($sorting_option )) ) ? 'checked' : '';  ?>>
                                <label class="form-check-label" for="sorting_option2">
                                    Bird Name
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="sorting_option" id="sorting_option1" value="contain" <?php echo ( (!empty($sorting_option) && $sorting_option=='contain')) ? 'checked' : '';  ?>>
                                <label class="form-check-label" for="sorting_option1">
                                    Species
                                </label>
                            </div>
                        </div>
                    <input type="submit" id="search_birds" />
                </form>
                <span><img src="<?php site_url(); ?>/wp-content/uploads/2019/04/search-icon.png" alt="search"></span>
                
            </div>
            
        </div>
        <div class="filterblock">
            <?php if(!empty($filter_heading)) {  ?>
                <h3><?php echo $filter_heading; ?></h3>
            <?php } if(!empty($filter_subtitles)) { ?>
                <h6><?php echo $filter_subtitles; ?></h6>
            <?php } ?>
        </div>
        <div class="search-filter-outer">
            <!-- Country column  -->
            <div class="search-filter-col">
                <div class="country-filter dropdown">
                    <div class="custom-dropdown <?php if($country) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="selected" class="active">Country</span>
                    </div>
                    <ul class="dropdown-menu">
                        <?php $terms = get_terms( 'cp_birds_country', array( 'hide_empty' => true) ); ?>
                        <?php 

                            foreach ($terms as $term) {
                                ?>
                                    <li <?php if($country == strtolower($term->name)) { echo 'class=active'; } ?>>
                                        <a href="javascript:void(0);" data-countryfilter="<?php echo strtolower($term->name); ?>"><?php echo strtolower($term->name); ?></a>
                                    </li>
                                <?php
                                
                            }
                        ?>
                    </ul>
                </div>
            </div>
            <!--Order Column-->
            <div class="search-filter-col">
                <div class="bird-family-filter dropdown">
                    <div class="custom-dropdown <?php if($birdfamily) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="birdfamilyselected">Order</span>
                    </div>
                    <?php
                        $bird_family = get_meta_values( 'bird_family', 'cp_birds' );
                        asort($bird_family);
                        if( !empty( $bird_family ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Order</a></li>-->
                                    <?php
                                        foreach( $bird_family as $key => $bird_family_value ){
                                            if( !empty($bird_family_value) ){
                                                ?>
                                                <li <?php if($birdfamily == strtolower($bird_family_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-bird-family="<?php echo strtolower($bird_family_value); ?>">
                                                        <?php echo strtolower($bird_family_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>
            <!--Genus Column-->
            <div class="search-filter-col">
                <div class="taxonomic-genus-filter dropdown">
                    <div class="custom-dropdown <?php if($taxonomicgenus) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="taxonomicselected">Genus</span>
                    </div>
                    <?php
                        $taxonomy_genus = get_meta_values( 'bird_taxonomic_genus', 'cp_birds' );
                        asort($taxonomy_genus);
                        if( !empty( $taxonomy_genus ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Genus</a></li>-->
                                    <?php
                                        foreach( $taxonomy_genus as $key => $taxonomy_genus_value ){
                                            /*$num_of_ratings[] = $taxonomy_genus_value;*/
                                            if( !empty($taxonomy_genus_value) ){
                                                ?>
                                                <li <?php if($taxonomicgenus == strtolower($taxonomy_genus_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-taxonomic-genus="<?php echo strtolower($taxonomy_genus_value); ?>">
                                                        <?php echo strtolower($taxonomy_genus_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                                
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>
            <!-- Conservancy column  -->
            <div class="search-filter-col">
                <div class="conservancy-filter dropdown">
                    <div class="custom-dropdown <?php if($conservancy) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="conservancyselected">Conservation Status</span>
                    </div>
                    <?php  $getseqs = get_field('field_5d5a95442afc6','option');
                        $seqs = explode('<br />',$getseqs);
                        
                        foreach($seqs as $s){ 
                            $temp =  trim($s);
                            $seq[] = strtolower($temp);
                            } 
                        //$seq  = array('leastconcern','nearthreatened','vulnerable','endangered','criticallyendangered');  // small later and without space
                        $bird_conservancy = get_meta_values( 'bird_conservation_status', 'cp_birds' );
                        foreach ($seq as $row) {
                           foreach($bird_conservancy as $k => $cons)
                           {   // echo $row  .'=='. str_replace(' ','',strtolower($cons)).'<br>';
                                if($row  == str_replace(' ','',strtolower($cons))){
                                     $result[] = $cons;  break;
                                }
                               
                           }
                        }
                      
                        asort($bird_conservancy);
                        if( !empty( $result ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Conservation Status</a></li>-->
                                    <?php
                                        foreach( $result as $key => $bird_conservancy_value ){
                                            if( !empty($bird_conservancy_value) ){
                                                ?>
                                                <li <?php if($conservancy == strtolower($bird_conservancy_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-bird-conservancy="<?php echo strtolower($bird_conservancy_value); ?>">
                                                        <?php echo strtolower($bird_conservancy_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>
            
            <!-- Activity column  -->
            <div class="search-filter-col">
                <div class="activity-filter dropdown">
                    <div class="custom-dropdown <?php if($activity_value) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="activityselected" class="activityselectedtemplateseach12">Activity</span>
                    </div>
                    <?php 
                        $allBirdactivity = array();
                        
                        $bird_activity = get_meta_values( 'bird_activity', 'cp_birds' );
                        foreach($bird_activity as $activity){ 
                            $new =array();
                                $new =explode(",",$activity);
                                foreach($new as $new_item){
                                    //$allBirdactivity[] = $new_item;
									$allBirdactivity[] = strtolower(trim($new_item));
                                }
                              
                            }
                        if( !empty( $allBirdactivity ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Activity</a></li>-->
                                    <?php
                                        foreach( array_unique($allBirdactivity) as $key => $bird_activity_value ){
                                            if( !empty($bird_activity_value) ){

                                                ?>
                                                <li <?php if($activity_value == strtolower($bird_activity_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-bird-activity="<?php echo strtolower($bird_activity_value); ?>">
                                                        <?php echo strtolower($bird_activity_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>

            <!-- Locations column  -->
            <div class="search-filter-col">
                    <div class="locations-filter dropdown">
                        <div class="custom-dropdown <?php if($locations) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                            <span id="locationselected">Birding Sites and Lodges</span>
                        </div>
                        <?php 
                            $bird_locations_multi = get_meta_values( 'bird_locations_multi', 'cp_birds');
							
								$postidofmulti = array();
								foreach ($bird_locations_multi as $key => $data) {
									$test = unserialize($data);
									if($test){
										$postidofmulti = array_merge($postidofmulti, $test);
									}   
								}
								
								$value_id = implode(",", $postidofmulti);
                            	global $wpdb;
                            	$get_title = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($value_id) AND post_status = 'publish'", ARRAY_N );
                            	$postidtit = array_column($get_title, 0);

								asort($postidtit);
                            if( !empty( $postidtit ) ) {
                              //echo count($postidtit);
                                ?>
                                    <ul class="dropdown-menu">
                                        <!--<li><a href="javascript:void(0);">Locations</a></li>-->
                                        <?php
                                            foreach( array_unique($postidtit) as $key => $bird_locations_value ){
                                                if( !empty($bird_locations_value) ){
                                                    ?>
                                                    <li <?php if($locations == strtolower($bird_locations_value)) { echo 'class=active'; } ?>>
                                                        <a href="javascript:void(0);" data-bird-locations="<?php echo strtolower($bird_locations_value); ?>">
                                                            <?php echo strtolower($bird_locations_value); ?>
                                                        </a>
                                                    </li>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </ul>
                                <?php
                            }
                        ?>
                    </div>
                </div>
            

            <!-- Visual Category Column  -->
            <div class="search-filter-col">
                    <div class="visualcategory-filter dropdown">
                        <div class="custom-dropdown <?php if($visualcategory) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                            <span id="visualcategoryselected">Visual Category</span>
                        </div>
                        <?php
                            $bird_visualcategory = get_meta_values( 'bird_visual_country', 'cp_birds' );
                            asort($bird_visualcategory);
                            if( !empty( $bird_visualcategory ) ) {
                                ?>
                                    <ul class="dropdown-menu">
                                        <!--<li><a href="javascript:void(0);">Visual Category</a></li>-->
                                        <?php
                                            foreach( $bird_visualcategory as $key => $bird_visualcategory_value ){
                                                if( !empty($bird_visualcategory_value) ){
                                                    ?>
                                                    <li <?php if($visualcategory == strtolower($bird_visualcategory_value)) { echo 'class=active'; } ?>>
                                                        <a href="javascript:void(0);" data-bird-visualcategory="<?php echo strtolower($bird_visualcategory_value); ?>">
                                                            <?php echo strtolower($bird_visualcategory_value); ?>
                                                        </a>
                                                    </li>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </ul>
                                <?php
                            }
                        ?>
                    </div>
                </div>
            
           
            <div class="search-filter-col">
                <div class="buttonarea">
                    <div class="submitsearch"><a class="submitsearchbtn">Search</a></div>
                    <div class="filter-clear"><a href="javascript:void(0);" class="custom-clear-btn clear-search">Clear</a></div>
                </div>
            </div>
        </div>
        <div class="search-results-container">
        </div>
        
    </div>
</div>
<?php get_footer(); ?>
<script type="text/javascript">
    var urlsite = "<?php echo site_url(); ?>";
</script>