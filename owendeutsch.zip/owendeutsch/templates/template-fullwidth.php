<?php
/*
Template Name: Full width
*/
?>

<?php
	get_header();
	if( have_posts() ) : while( have_posts() ) : the_post();
?>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div class="container">
			   
			<h1 class="page-title"><?php the_title(); ?></h1>
			<div class="story-content clearfix">
				 <?php the_content(); ?>
			</div>

		</div> 
	</div>
<?php
	endwhile; else: endif; wp_reset_query(); wp_reset_postdata();
	get_footer();
?>