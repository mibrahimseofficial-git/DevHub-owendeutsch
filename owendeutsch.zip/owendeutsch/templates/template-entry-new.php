<?php
/*
Template Name: Entry New
*/
?>

<?php
	get_header();
?>
<!-- <script src="<?php // echo get_template_directory_uri(); ?>/js/jquery.validate.min.js"></script> -->
	<div class="inner-page-outer entryform">
		<div class="container">
			<?php 
			$entrybanner = (!empty(get_field('top_image'))) ? get_field('top_image') : site_url().'/wp-content/uploads/2019/04/black-skimmer-4r-stretch-2-l.jpg.webp';
			$form_heading = (!empty(get_field('heading'))) ? get_field('heading') : 'CONTEST ENTRY';
			?>
			<section class="entryform-banner cmn-padding">
				<h1 class="large text-center"><?php echo $form_heading; ?> </h1>
				<img src="<?php echo $entrybanner; ?>" alt="Contest Entry" title="Contest Entry"/>
			</section>

            <div class="forminator-section">
                <?php echo do_shortcode('[forminator_form id="31993"]'); ?>
                
            </div>
            <div class="forminator-section">
                <?php // echo do_shortcode('[forminator_form id="24029"]'); ?>
            </div>
			
		</div> 
	</div>
<?php
	get_footer();
?>	