<?php

/*

Template Name: Video New Template

*/

?>

<?php

	get_header(); 

	if( have_posts() ) : while( have_posts() ) : the_post();

?>
<div class="vid-main-wrapper clearfix">
		<?php 

			$main_video_id 	= get_field('vd_embedded_video');
			$playalltext 	= get_field('vd_play_all_text');
			$playalllink 	= get_field('vd_play_all_link');

		?>
			    <!-- THE YOUTUBE PLAYER -->
	    
		<div class="vid-playall-container" id="video-placeholder"></div>
		
		<div class="clear"></div>
</div>
      <!-- THE PLAYLIST -->
      <div class="container-fluid">
      		<?php $hello = '';// if( !empty($playalltext) && !empty($playalllink) ) { ?>
				<div class="playallblock text-right">
					<a href="javascript:void(0);" id="play">
						<i class="fa fa-list" aria-hidden="true"></i>
						<?php echo get_field('vd_play_all_text'); ?>
					</a>
				</div>
  			<?php //} ?>
      		<hr class="gray">
      		<div class="row">
	            <ol id="vid-list">
				<?php 
					$vdo_repeater 	= get_field("main_video_embedded_code");
					$array_Key 		= array_keys($vdo_repeater);
					$last_key 		= end($array_Key);
		
					$vdos = '';
					foreach($vdo_repeater as $key => $videosrow){
						if($last_key != $key){
							
							$vdos .=$videosrow['embedded_video_id'].',';
							// if(strpos($videosrow['embedded_video_id'], $main_video_id) !== false){ 
							// 	unset($vdos);
							// 	// echo 'found duplicate';
							// }
						}
						else{
							$vdos .=$videosrow['embedded_video_id'];
						}
					
						?>
						  <li class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
							<a class="viditem" data-video="<?php echo $videosrow['embedded_video_id']; ?>" href="javascript:void(0);" >
							  <div class="vid-thumb"><img src="<?php echo $videosrow['embedded_video_image']['url']; ?>" /></div>
							  <h1 class="desc"><?php echo $videosrow['embedded_video_title']; ?></h1>
							</a>
						  </li>
				<?php } ?>
	              
	            </ol>
	        </div>
       </div>

  	
</div>
<script src="https://www.youtube.com/iframe_api"></script>
<script type="text/javascript">
var mainvideoid = '<?php echo $main_video_id; ?>';
var vdos = '<?php echo $vdos; ?>';
/*Live Example: https://demo.tutorialzine.com/2015/08/how-to-control-youtubes-video-player-with-javascript/*/
var player, time_update_interval = 0; 

window.onYouTubeIframeAPIReady = function() {
    console.log("YouTube API Ready");
    player = new YT.Player('video-placeholder', {
        videoId: mainvideoid,
        playerVars: {
            // 'autoplay':0,
            'color': 'white',
            'rel': 0,
            'iv_load_policy':3,
            'playsinline':1
            //playlist: 'ou8srKBNIyk,XzgpQuNv1aE,uJ5nljMxZP8,5o2ho8KY3gs,bb00EOT_U7w,QMB4Z5p9kp8,svzs8emb3Xc,axoCf4oHfds'
            //playlist:vdos,
        },
        events: {
            'onReady': initialize,
            'onStateChange':onPlayerStateChange,
            'onPlaybackQualityChange' : onPlaybackQualityChange,
        },
    });
}
function initialize(){
    //     player.playVideo();
    //player.playVideo();
	// Update the controls on load
    updateTimerDisplay();
    updateProgressBar();

    // Clear any old interval.
    clearInterval(time_update_interval);

    // Start interval to update elapsed time display and
    // the elapsed part of the progress bar every second.
    time_update_interval = setInterval(function () {
        updateTimerDisplay();
        updateProgressBar();
    }, 1000)
	player.cueVideoById({videoId:mainvideoid,suggestedQuality:'hd1080'});
    
}
// This function is called by initialize()
function updateTimerDisplay(){
    // Update current time text display.
    $('#current-time').text(formatTime( player.getCurrentTime() ));
    $('#duration').text(formatTime( player.getDuration() ));
}
// This function is called by initialize()
function updateProgressBar(){
    // Update the value of our progress bar accordingly.
    $('#progress-bar').val((player.getCurrentTime() / player.getDuration()) * 100);
}
function formatTime(time){
    time = Math.round(time);

    var minutes = Math.floor(time / 60),
    seconds = time - minutes * 60;

    seconds = seconds < 10 ? '0' + seconds : seconds;

    return minutes + ":" + seconds;
}
function onPlayerStateChange(event) {
    if (event.data == YT.PlayerState.BUFFERING) {
        event.target.setPlaybackQuality('hd1080');
    }if (event.data == YT.PlayerState.PLAYING) {
        event.target.setPlaybackQuality('hd1080');
    }
}
function onPlaybackQualityChange(event) {
    if (event.data == YT.PlayerState.BUFFERING) {
        event.target.setPlaybackQuality('hd1080');
    }if (event.data == YT.PlayerState.PLAYING) {
        event.target.setPlaybackQuality('hd1080');
    }
}
// Playback
jQuery('#play').on('click', function () {
    setTimeout(function(){ 
        jQuery('html, body').animate({
            scrollTop: jQuery("body").offset().top - 120
        }, 1000)
    }, 200);
    player.stopVideo();
    //player.cueVideoById(mainvideoid);
    player.cueVideoById({videoId:mainvideoid,suggestedQuality:'hd1080'});
    player.cuePlaylist({playlist:vdos,suggestedQuality:'hd1080'});
    player.setPlaybackQuality('hd1080');
});
jQuery("#vid-list li a").on('click', function(){
		// event.preventDefault();
	var thumbvideo = jQuery(this).data("video");
	player.cueVideoById(thumbvideo);
	// player.cueVideoById({videoId:thumbvideo,suggestedQuality:'hd1080'});
	setTimeout(function(){ 
		jQuery('html, body').animate({
			scrollTop: jQuery("body").offset().top - 120
		}, 1000)
	}, 200);
	
});
</script>
<?php

	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 

	get_footer();

?>
<script>
/*JS FOR SCROLLING THE ROW OF THUMBNAILS*/ 
jQuery(document).ready(function () {
	var deviceAgent = navigator.userAgent.toLowerCase();
	var agentID = deviceAgent.match(/(iphone|ipod|ipad)/);
	var clickevent;
	if (agentID) {
		clickevent = 'touchstart';
		
	}else{
		clickevent = 'click';
	}
	
});
</script>

