<?php

/*

Template Name: About Owen

*/

?>

<?php

	get_header(); 

	if( have_posts() ) : while( have_posts() ) : the_post();

?>
<style>
.fancybox-toolbar { right: 0 !important; }
</style>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">

		<div class="inner-page-outer about">

			<div class="about-container">

				<div class="row">

					<div class="col-xs-12 col-md-6 pull-right">
						<?php $owens_image = get_field('owens_image'); ?>
						<img src="<?php echo $owens_image['url']; ?>" alt="<?php echo $owens_image['alt']; ?>">

					</div>

					<div class="col-xs-12 col-md-6">

						<div class="about-content">

							<?php if( !empty( get_field('about_owen_title') ) ) { ?>
								<h1><?php echo get_field('about_owen_title'); ?></h1>
							<?php } if( !empty( get_field('about_owen_description') )) { ?>
								<?php echo get_field('about_owen_description'); ?>
							<?php } ?>

						</div>

					</div>

				</div>



				<div class="past-life-photographer">

					<h2 class="large"><?php echo get_field('past_life'); ?></h2>
					<?php 
						$past_photo_gallery = get_field('past_life_photogallery'); 

						?>
					<div class="owl-carousel owl-theme" id="past-life">
						<?php foreach ( $past_photo_gallery as $key => $phoyogallery ) { ?>
								<div class="item">
									<a href="<?php echo $phoyogallery['gallery_image']['url']; ?>" class="photograph" data-fancybox="photograph-past">
										<img src="<?php echo $phoyogallery['gallery_thumbnail_image']['url']; ?>" alt="<?php echo $phoyogallery['gallery_thumbnail_image']['alt']; ?>">
								</a>

							    </div>
						<?php } ?>
					</div>

				</div>

			</div>



			<!--  Section New Book   -->

			<section  class="owen-new-book two-column-center cmn-padding">

				<div class="container">

					<div class="responsive-image">
						<?php $abt_img = get_field('owens_book_image'); ?>
						<img src="<?php echo $abt_img['url']; ?>" alt="<?php echo $abt_img['alt']; ?>">
					</div>

					<div class="content">
						<?php echo get_field('owens_book_title'); ?>
						<p><?php echo get_field('owens_book_desciption'); ?></p>
						<?php if( !empty(get_field('owens_book_button_text') ) && !empty( get_field('owens_book_button_link') ) ){?>
							<a href="<?php echo get_field('owens_book_button_link'); ?>" target="_blank" class="yellow-btn">
								<?php echo get_field('owens_book_button_text'); ?>
							</a>
						<?php } ?>
					</div>

					<div class="image responsive-hide">
						<img src="<?php echo $abt_img['url']; ?>" alt="<?php echo $abt_img['alt']; ?>">
					</div>

				</div>

			</section>

			<!--  End   -->



			<!--  Instagram Feed  -->

			<section class="instagram-feed">

				<div class="display-feed">

					<div class="owl-image-instagram">

						<div class="title">
							<div class="title-inner">
								<?php echo get_field('instagram_title', 'option'); ?>
							</div>
						</div>

						<?php $insta_bg_image = get_field('instagram_section_bg_image', 'option'); ?>
						<img src="<?php echo $insta_bg_image['url']; ?>" alt="<?php echo $insta_bg_image['alt']; ?>">

					</div>

					<?php 
							//$instagram_shortcode = get_field('instagram_feed_shortcode', 'option');
							//echo do_shortcode($instagram_shortcode);
							echo do_shortcode("[instagram-feed num=5 cols=5 showfollow=false]");
						?>

				</div>

			</section>

			<!-- End -->



		</div>

	</div>

<?php

	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 

	get_footer();

?>