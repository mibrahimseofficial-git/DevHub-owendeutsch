<?php

/*

Template Name: Sample Page

*/

?>

<?php

	get_header(); 

	if( have_posts() ) : while( have_posts() ) : the_post();

?>
<div class="container" style="height:600px;margin-top: 300px;">
	<div class="row">
		<?php get_sidebar(); ?>
	</div>
</div>

<?php

	endwhile; else: endif; wp_reset_postdata(); wp_reset_query(); 

	get_footer();

?>