<?php
/*
Template Name: Update Post After Insert Data by CSV Code
*/
?>

<?php
get_header(); 

// $myposts = get_posts('showposts=-1');//Retrieve the posts you are targeting
// $post_id_array = array(9298,9471,10298);
$args = array(
    'numberposts'       => 100,
    'paged'             => 1,
    'post_type'         => 'cp_birds',
    'post_status'       => 'publish',
    'order'             => 'ASC'
);

// $args = array(
//     'include'           => 1372,
//     'paged'             => 1,
//     'post_type'         => 'cp_birds',
//     'post_status'       => 'publish',
//     'order'             => 'ASC'
// );
$posts = get_posts($args);
// echo "<pre>";print_r($posts);echo"</pre>";
//exit;
if (!empty($posts)) {
   
    foreach ($posts as $post) {
        //setup_postdata(); 
        $post_id    = get_the_ID();
        $title      = $post->post_title;
        $cs         = get_field('bird_conservation_status', $post_id); //field_5cc1a71db9ad5
        $sn         = get_field('bird_scientific_name', $post_id); //field_5ca2126fea6cd
        $gn         = get_field('bird_gender', $post_id); //field_5d1b3887dd5a5
        $ag         = get_field('bird_age', $post_id); //field_5d1b389bdd5a6
        $co         = get_field('bird_conservancy', $post_id); //field_5d1d9e52da19c
        $ba         = get_field('bird_activity', $post_id); //field_5d1d9e63da19d
        $bf         = get_field('bird_family', $post_id); //field_5d1d9e71da19e
        $tg         = get_field('bird_taxonomic_genus', $post_id); //field_5d1d9e80da19f
        $ec         = get_field('bird_endemic_country', $post_id); //field_5d1b387edd5a4
        $bl         = get_field('bird_locations', $post_id); //field_5d47eb62d75c0
        $vc         = get_field('bird_visual_country', $post_id); //field_5d43d359b3da0
        $bfamily         = get_field('bfamily', $post_id); //field_5e072fb18e1c7
        //echo $gn;
        $tags = get_the_terms($post_id, 'cp_birds_tag');
        $country = get_the_terms($post_id, 'cp_birds_country');
        pr($post_id);
        pr($title);
        pr($sn);
        pr($cs);
        pr($ec);
        pr($gn);
        pr($ag);
        pr($co);
        pr($ba);
        pr($bf);
        pr($tg);
        pr($country);
        pr($tags);
        pr($vc);
        pr($bfamily);
        
        $output = [];
        // Post Title
        $trim_title = trim($title);
        $trim_title = replaceString($trim_title, "-");
        $output[] = $trim_title;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_title));
        if (strpos($trim_title, "'") !== false) {
            $trim_title = replaceString($trim_title, "'") ;
            $trim_title = str_replace(' ', ',' ,$trim_title);
            $output[] = $trim_title;	
        }
        if (strpos($trim_title, "-") !== false) {
            $trim_title = replaceString($trim_title, "-");
            $trim_title = str_replace(' ', ',' ,$trim_title);
            $output[] = $trim_title;
        }       

        // Scientific Name
        if(!empty($sn)){
            $trim_sn = trim($sn);
            $output[] = $trim_sn;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_sn));
            if (strpos($trim_sn, "'") !== false) {
                $trim_sn = replaceString($trim_sn, "'");
                $trim_sn = str_replace(' ', ',' ,$trim_sn);
                $output[] = $trim_sn;
            }
            if (strpos($trim_sn, "-") !== false) {
                $trim_sn = replaceString($trim_sn, "-");
                $trim_sn = str_replace(' ', ',' ,$trim_sn);
                $output[] = $trim_sn;
            }
        }

        // Tags
        // $tags = wp_get_post_terms($post_id, 'cp_birds_tag');
        // pr($tags);
        if ($tags) {
            foreach ($tags as $tag) {
                // pr($tag);
                $tag_name = trim($tag->name);
                // pr($tag_name);
                
                $output[] = $tag_name;
                // $st = htmlspecialchars($tag_name);
                // pr("STRING==".$st);
                // pr("STRING LOWER==".mb_strtolower($st));
                // pr("WHITESPACE==".mb_strtolower(str_replace(' ', '' ,$tag_name)));
                $output[] = mb_strtolower(str_replace(' ', '' ,$tag_name));
                // die;
                if (strpos($tag_name, "'") !== false) {
                    $tag_name = replaceString($tag_name, "'");
                    $tag_name = str_replace(' ', ',' ,$tag_name);
                    $output[] = $tag_name;
                }

                if (strpos($tag_name, "-") === true) {
                    $tag_name = replaceString($tag_name, "-");
                    $tag_name = str_replace(' ', ',' ,$tag_name);
                    $output[] = $tag_name;
                }

                // pr($output);
            }
        }
        
        // Conservation Status
        if(!empty($cs)){
            $trim_cs = trim($cs);
            $output[] = $trim_cs;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_cs));
            if (strpos($trim_cs, "'") !== false) {
                $trim_cs = replaceString($trim_cs, "'");
                $trim_cs = str_replace(' ', ',' ,$trim_cs);
                $output[] = $trim_cs;
            }
            if (strpos($trim_cs, "-") !== false) {
                $trim_cs = replaceString($trim_cs, "-");
                $trim_cs = str_replace(' ', ',' ,$trim_cs);
                $output[] = $trim_cs;
            }
        }
        
        // Gender
        if(!empty($gn)){
            $trim_gn = trim($gn);
            $output[] = $trim_gn;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_gn));

            if (strpos($trim_gn, "'") !== false) {
                $trim_gn = replaceString($trim_gn, "'");
                $trim_gn = str_replace(' ', ',' ,$trim_gn);
                $output[] = $trim_gn;
            }

            if (strpos($trim_gn, "-") !== false) {
                $trim_gn = replaceString($trim_gn, "-");
                $trim_gn = str_replace(' ', ',' ,$trim_gn);
                $output[] = $trim_gn;
            }
        }

        // Age
        if(!empty($ag)){
            $trim_ag = trim($ag);
            $output[] = $trim_ag;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ag));

            if (strpos($trim_ag, "'") !== false) {
                $trim_ag = replaceString($trim_ag, "'");
                $trim_ag = str_replace(' ', ',' ,$trim_ag);
                $output[] = $trim_ag;
            }

            if (strpos($trim_ag, "-") !== false) {
                $trim_ag = replaceString($trim_ag, "-");
                $trim_ag = str_replace(' ', ',' ,$trim_ag);
                $output[] = $trim_ag;
            }
        }

        // Conservancy
        if(!empty($co)){
            $trim_co = trim($co);
            $output[] = $trim_co;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_co));

            if (strpos($trim_co, "'") !== false) {
                $trim_co = replaceString($trim_co, "'");
                $trim_co = str_replace(' ', ',' ,$trim_co);
                $output[] = $trim_co;
            }

            if (strpos($trim_co, "-") !== false) {
                $trim_co = replaceString($trim_co, "-");
                $trim_co = str_replace(' ', ',' ,$trim_co);
                $output[] = $trim_co;
            }
        }

        // Bird Activity
        if(!empty($ba)){
            $trim_ba = trim($ba);
            $output[] = $trim_ba;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ba));

            if (strpos($trim_ba, "'") !== false) {
                $trim_ba = replaceString($trim_ba, "'");
                $trim_ba = str_replace(' ', ',' ,$trim_ba);
                $output[] = $trim_ba;
            }

            if (strpos($trim_ba, "-") !== false) {
                $trim_ba = replaceString($trim_ba, "-");
                $trim_ba = str_replace(' ', ',' ,$trim_ba);
                $output[] = $trim_ba;
            }
        }

        // Bird Family
        if(!empty($bf)){
            $trim_bf = trim($bf);
            $output[] = $trim_bf;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_bf));

            if (strpos($trim_bf, "'") !== false) {
                $trim_bf = replaceString($trim_bf, "'");
                $trim_bf = str_replace(' ', ',' ,$trim_bf);
                $output[] = $trim_bf;
            }

            if (strpos($trim_bf, "-") !== false) {
                $trim_bf = replaceString($trim_bf, "-");
                $trim_bf = str_replace(' ', ',' ,$trim_bf);
                $output[] = $trim_bf;
            }
        }
        
        // Taxonomic Genus
        if(!empty($tg)){
            $trim_tg = trim($tg);
            $output[] = $trim_tg;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_tg));

            if (strpos($trim_tg, "'") !== false) {
                $trim_tg = replaceString($trim_tg, "'");
                $trim_tg = str_replace(' ', ',' ,$trim_tg);
                $output[] = $trim_tg;
            }

            if (strpos($trim_tg, "-") !== false) {
                $trim_tg = replaceString($trim_tg, "-");
                $trim_tg = str_replace(' ', ',' ,$trim_tg);
                $output[] = $trim_tg;
            }
        }

        // Endemic Country
        if(!empty($ec)){
            $trim_ec = trim($ec);
            $output[] = $trim_ec;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ec));

            if (strpos($trim_ec, "'") !== false) {
                $trim_ec = replaceString($trim_ec, "'");
                $trim_ec = str_replace(' ', ',' ,$trim_ec);
                $output[] = $trim_ec;
            }

            if (strpos($trim_ec, "-") !== false) {
                $trim_ec = replaceString($trim_ec, "-");
                $trim_ec = str_replace(' ', ',' ,$trim_ec);
                $output[] = $trim_ec;
            }
        }

        // Bird Locations
        /* if(!empty($bl)){
            $trim_bl = trim($bl);
            $output[] = $trim_bl;
            $output[] = strtolower(str_replace(' ', '' ,$trim_bl));
            if (strpos($trim_bl, "'") !== false) {
                $trim_bl = replaceString($trim_bl, "'");
                $trim_bl = str_replace(' ', ',' ,$trim_bl);
                $output[] = $trim_bl;
            }
            if (strpos($trim_bl, "-") !== false) {
                $trim_bl = replaceString($trim_bl, "-");
                $trim_bl = str_replace(' ', ',' ,$trim_bl);
                $output[] = $trim_bl;
            }
        } */

        if(!empty($bl)){
            //$trim_bl = trim($bl);
            // $trim_bl = preg_replace('/\s/', '', $trim_bl);
            // $trim_bl = str_replace('|', ',' ,$trim_bl);
            $strrpl = str_replace('|', ',' ,$bl);
            $output[] = $strrpl;
            $output[] = preg_replace('/\s/', '', $strrpl);
            $output[] = mb_strtolower(str_replace(' ', '' ,$strrpl));
            $output[] = mb_strtolower(str_replace('|', ',' ,$strrpl));

            //$trim_bl = mb_strtolower(str_replace('|', ',' ,$trim_bl));
            //$output[] = mb_strtolower($trim_bl);
                        
            if (strpos($strrpl, "'") !== false) {
                $strrpl = replaceString($strrpl, "'");
                $strrpl = str_replace(' ', ',' ,$strrpl);
                $output[] = $strrpl;
            }
            if (strpos($strrpl, "-") !== false) {
                $strrpl = replaceString($strrpl, "-");
                $strrpl = str_replace(' ', ',' ,$strrpl);
                $output[] = $strrpl;
            }
            //pr($output);
        }
        // Visual Category
        if(!empty($vc)){
            $trim_vc = trim($vc);
            $output[] = $trim_vc;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_vc));
            if (strpos($trim_vc, "'") !== false) {
                $trim_vc = replaceString($trim_vc, "'");
                $trim_vc = str_replace(' ', ',' ,$trim_vc);
                $output[] = $trim_vc;
            }
            if (strpos($trim_vc, "-") !== false) {
                $trim_vc = replaceString($trim_vc, "-");
                $trim_vc = str_replace(' ', ',' ,$trim_vc);
                $output[] = $trim_vc;
            }
        }
        // $bfamily => Family
        if(!empty($bfamily)){
            $trim_bfamily = trim($bfamily);
            $output[] = $trim_bfamily;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_bfamily));

            if (strpos($trim_bfamily, "'") !== false) {
                $trim_bfamily = replaceString($trim_bfamily, "'");
                $trim_bfamily = str_replace(' ', ',' ,$trim_bfamily);
                $output[] = $trim_bfamily;
            }

            if (strpos($trim_bfamily, "-") !== false) {
                $trim_bfamily = replaceString($trim_bfamily, "-");
                $trim_bfamily = str_replace(' ', ',' ,$trim_bfamily);
                $output[] = $trim_bfamily;
            }
        }

        // Country Name
        $countryoutput = get_the_terms($post_id, 'cp_birds_country');
        if (is_array($countryoutput) && !empty($countryoutput)) {
            foreach ($countryoutput as $cat) {
                $catname  = mb_strtolower(str_replace(' ', '' ,$cat->name));
                $output[] = $catname;
            }
        }
        
        $result = implode(",",$output);
        $return_string = removeComma($result);
        pr("return string==".$return_string);
        $blogtime = current_time( 'mysql', 1);
        $update = $wpdb->query('UPDATE wp_posts SET post_content = "'.$return_string.'"  WHERE ID = '.$post_id);
        $update = $wpdb->query('UPDATE wp_posts SET post_content = "'.$return_string.'", post_modified = "'.$blogtime.'", post_modified_gmt = "'.$blogtime.'"   WHERE ID = '.$post_id);
        pr($update);
        // pr($wpdb->last_query);
         echo "<br><br><br><br>".$wpdb->last_query;
    // exit;
    }
    wp_reset_postdata();
     
}
get_footer();
?>