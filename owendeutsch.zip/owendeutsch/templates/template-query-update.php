<?php
/*
Template Name: update all posts
*/
?>

<?php
get_header(); 
$blogtime = current_time( 'mysql', 1); 
echo $blogtime;

$post_id_array = array(719,749,932,938,940,960,976,1004,1154,1236,1262,1312,1372,1459,1499,1507,1509,1539,1851,2054,2062,2104,2106,2108,2112,2144,2257,2259,2490,2492,2494,2508,2510,2512,2560,2602,2606,2665,2691,2781,2988,3179,3267,3299,3536,3557,3680,3889,3905,3929,4071,4289,4446,4448,4450,4452,4565,4669,4717,4729,4734,4789,4837,5021,5048,5417,5490,5498,6014,6119,6165,6221,6479,6531,6555,6586,6602,6632,6863,6990,6995,6999,7018,7021,7025,7026,7055,7103,7116,7183,7334,7336,7386,7434,7537,7539,7635,7657,7922,7932,7934,7936,7952,7954,7968,7970,8190,8235,8283,8285,8341,8467,8595,8619,8661,8685,8808,8870,8874,8882,8920,8947,9189,9229,9856);
//exit;
//UPDATE $wpdb->posts SET post_modified = $blogtime,post_modified_gmt = $blogtime WHERE ID = $wp_id
//$myposts = get_posts('showposts=-1');//Retrieve the posts you are targeting
$args = array(
        'include'           => $post_id_array,
        'paged'             => 1,
        'post_type'         => 'cp_birds',
        'post_status'       => 'publish',
        'order'             => 'ASC'
    );
$posts = get_posts($args);
echo "<pre>";print_r($posts);echo"</pre>";
if (!empty($posts)) {
   
    foreach ($posts as $post) {
        //setup_postdata(); 
        $post_id    = get_the_ID();
        $title      = $post->post_title;
        $sn         = get_field('bird_scientific_name', $post_id);
        $cs         = get_field('bird_conservation_status', $post_id);
        $ec         = get_field('bird_endemic_country', $post_id);
        $gn         = get_field('bird_gender', $post_id);
        $ag         = get_field('bird_age', $post_id);
        // $co         = get_field('bird_conservancy', $post_id);
        $ba         = get_field('bird_activity', $post_id);
        $bf         = get_field('bird_family', $post_id);
        $tg         = get_field('bird_taxonomic_genus', $post_id);
        $vc         = get_field('bird_visual_country', $post_id);
        $bl         = get_field('bird_locations', $post_id);
       
        $output = [];
            
        // Post Title
        $trim_title = trim($title);
        $output[] = $trim_title;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_title));

        if (strpos($trim_title, "'") !== false) {
            $trim_title = replaceString($trim_title, "'") ;
            $trim_title = str_replace(' ', ',' ,$trim_title);
            $output[] = $trim_title;
        }

        if (strpos($trim_title, "-") !== false) {
            $trim_title = replaceString($trim_title, "-");
            $trim_title = str_replace(' ', ',' ,$trim_title);
            $output[] = $trim_title;
        }
                
        // Scientific Name
        if(!empty($sn)){
            $trim_sn = trim($sn);
            $output[] = $trim_sn;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_sn));
            if (strpos($trim_sn, "'") !== false) {
                $trim_sn = replaceString($trim_sn, "'");
                $trim_sn = str_replace(' ', ',' ,$trim_sn);
                $output[] = $trim_sn;
            }
            if (strpos($trim_sn, "-") !== false) {
                $trim_sn = replaceString($trim_sn, "-");
                $trim_sn = str_replace(' ', ',' ,$trim_sn);
                $output[] = $trim_sn;
            }
        }

        // Tags
        $tags = wp_get_post_terms($post_id, 'cp_birds_tag');
        if ($tags) {
            foreach ($tags as $tag) {
                $tag_name = trim($tag->name);
                $output[] = $tag_name;
                $output[] = mb_strtolower(str_replace(' ', '' ,$tag_name));

                if (strpos($tag_name, "'") !== false) {
                    $tag_name = replaceString($tag_name, "'");
                    $tag_name = str_replace(' ', ',' ,$tag_name);
                    $output[] = $tag_name;
                }

                if (strpos($tag_name, "-") !== false) {
                    $tag_name = replaceString($tag_name, "-");
                    $tag_name = str_replace(' ', ',' ,$tag_name);
                    $output[] = $tag_name;
                }
            }
        }

        // Conservation Status
        if(!empty($cs)){
            $trim_cs = trim($cs);
            $output[] = $trim_cs;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_cs));
            if (strpos($trim_cs, "'") !== false) {
                $trim_cs = replaceString($trim_cs, "'");
                $trim_cs = str_replace(' ', ',' ,$trim_cs);
                $output[] = $trim_cs;
            }
            if (strpos($trim_cs, "-") !== false) {
                $trim_cs = replaceString($trim_cs, "-");
                $trim_cs = str_replace(' ', ',' ,$trim_cs);
                $output[] = $trim_cs;
            }
        }

        // Gender
        if(!empty($gn)){
            $trim_gn = trim($gn);
            $output[] = $trim_gn;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_gn));

            if (strpos($trim_gn, "'") !== false) {
                $trim_gn = replaceString($trim_gn, "'");
                $trim_gn = str_replace(' ', ',' ,$trim_gn);
                $output[] = $trim_gn;
            }

            if (strpos($trim_gn, "-") !== false) {
                $trim_gn = replaceString($trim_gn, "-");
                $trim_gn = str_replace(' ', ',' ,$trim_gn);
                $output[] = $trim_gn;
            }
        }

        // Age
        if(!empty($ag)){
            $trim_ag = trim($ag);
            $output[] = $trim_ag;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ag));

            if (strpos($trim_ag, "'") !== false) {
                $trim_ag = replaceString($trim_ag, "'");
                $trim_ag = str_replace(' ', ',' ,$trim_ag);
                $output[] = $trim_ag;
            }

            if (strpos($trim_ag, "-") !== false) {
                $trim_ag = replaceString($trim_ag, "-");
                $trim_ag = str_replace(' ', ',' ,$trim_ag);
                $output[] = $trim_ag;
            }
        }

        // Bird Activity
        if(!empty($ba)){
            $trim_ba = trim($ba);
            
            $output[] = $trim_ba;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ba));

            if (strpos($trim_ba, "'") !== false) {
                $trim_ba = replaceString($trim_ba, "'");
                $trim_ba = str_replace(' ', ',' ,$trim_ba);
                $output[] = $trim_ba;
            }

            if (strpos($trim_ba, "-") !== false) {
                $trim_ba = replaceString($trim_ba, "-");
                $trim_ba = str_replace(' ', ',' ,$trim_ba);
                $output[] = $trim_ba;
            }
        }

        // Bird Family
        if(!empty($bf)){
            $trim_bf = trim($bf);
            $output[] = $trim_bf;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_bf));

            if (strpos($trim_bf, "'") !== false) {
                $trim_bf = replaceString($trim_bf, "'");
                $trim_bf = str_replace(' ', ',' ,$trim_bf);
                $output[] = $trim_bf;
            }

            if (strpos($trim_bf, "-") !== false) {
                $trim_bf = replaceString($trim_bf, "-");
                $trim_bf = str_replace(' ', ',' ,$trim_bf);
                $output[] = $trim_bf;
            }
        }

        // Taxonomic Genus
        if(!empty($tg)){
            $trim_tg = trim($tg);
            $output[] = $trim_tg;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_tg));

            if (strpos($trim_tg, "'") !== false) {
                $trim_tg = replaceString($trim_tg, "'");
                $trim_tg = str_replace(' ', ',' ,$trim_tg);
                $output[] = $trim_tg;
            }

            if (strpos($trim_tg, "-") !== false) {
                $trim_tg = replaceString($trim_tg, "-");
                $trim_tg = str_replace(' ', ',' ,$trim_tg);
                $output[] = $trim_tg;
            }
        }
        // Endemic Country
        if(!empty($ec)){
            $trim_ec = trim($ec);
            $output[] = $trim_ec;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ec));

            if (strpos($trim_ec, "'") !== false) {
                $trim_ec = replaceString($trim_ec, "'");
                $trim_ec = str_replace(' ', ',' ,$trim_ec);
                $output[] = $trim_ec;
            }

            if (strpos($trim_ec, "-") !== false) {
                $trim_ec = replaceString($trim_ec, "-");
                $trim_ec = str_replace(' ', ',' ,$trim_ec);
                $output[] = $trim_ec;
            }
        }

        // Bird Locations
        if(!empty($bl)){
            //$trim_bl = trim($bl);
            // $trim_bl = preg_replace('/\s/', '', $trim_bl);
            // $trim_bl = str_replace('|', ',' ,$trim_bl);
            $strrpl = str_replace('|', ',' ,$bl);
            $output[] = $strrpl;
            $output[] = preg_replace('/\s/', '', $strrpl);
            $output[] = mb_strtolower(str_replace(' ', '' ,$strrpl));
            $output[] = mb_strtolower(str_replace('|', ',' ,$strrpl));

            //$trim_bl = mb_strtolower(str_replace('|', ',' ,$trim_bl));
            //$output[] = mb_strtolower($trim_bl);
                        
            if (strpos($strrpl, "'") !== false) {
                $strrpl = replaceString($strrpl, "'");
                $strrpl = str_replace(' ', ',' ,$strrpl);
                $output[] = $strrpl;
            }
            if (strpos($strrpl, "-") !== false) {
                $strrpl = replaceString($strrpl, "-");
                $strrpl = str_replace(' ', ',' ,$strrpl);
                $output[] = $strrpl;
            }
            pr($output);
        }
        //exit;

        // Visual Category
        if(!empty($vc)){
            $trim_vc = trim($vc);
            $output[] = $trim_vc;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_vc));
            if (strpos($trim_vc, "'") !== false) {
                $trim_vc = replaceString($trim_vc, "'");
                $trim_vc = str_replace(' ', ',' ,$trim_vc);
                $output[] = $trim_vc;
            }
            if (strpos($trim_vc, "-") !== false) {
                $trim_vc = replaceString($trim_vc, "-");
                $trim_vc = str_replace(' ', ',' ,$trim_vc);
                $output[] = $trim_vc;
            }
        }

        // Country Name
        $countryoutput = get_the_terms($post_id, 'cp_birds_country');
        if (is_array($countryoutput) && !empty($countryoutput)) {
            foreach ($countryoutput as $cat) {
                $catname  = mb_strtolower(str_replace(' ', '' ,$cat->name));
                $output[] = $catname;
            }
        }
                
       
        $result = implode(",",$output);
        $return_string = removeComma($result);
        pr($return_string);
        $update = $wpdb->query('UPDATE wp_posts SET post_content = "'.$return_string.'", post_modified = "'.$blogtime.'", post_modified_gmt = "'.$blogtime.'" WHERE ID = '.$post_id);
        pr($wpdb->last_query);
        //exit;
        if($update){
            echo "update query run successfully";
        }else{
            echo "failed to run query";
        }
        if($wpdb->last_query){
            echo $wpdb->last_query;
        }
        
    }
    wp_reset_postdata();
     
}
get_footer();
?>