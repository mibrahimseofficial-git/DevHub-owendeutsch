<div class="search-area">
	<form action="<?php echo home_url(); ?>" method="get">
		<input class="search-text" type="text" name="s" placeholder="Search here.." />
		<input type="hidden" name="sorting_option" value="exact_match">
		<span>
			<i class="fa fa-light fa-magnifying-glass" aria-hidden="true"></i>
			<input class="search-btn" type="submit" value="" />
		</span>
	</form>
</div>