
<?php
  get_header();
  if( have_posts() ) : while( have_posts() ) : the_post();
  $term = get_the_terms(get_the_ID(),'cp_birds_country');
?>
  <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
    <div class="container-fluid inner-page-outer single-blog-page">
      <div class="custom-single-outer">
        <div class="row">
          <div class="col-sm-8">
            <div class="story">
              <?php if(has_post_thumbnail() ) : ?>
                <div class="post-image">
                    <?php the_post_thumbnail(); ?>
                </div>
              <?php endif; ?>
            </div>
          </div>
            <div class="col-sm-4">
              <figcaption>
                <div class="countrydetails <?php //echo $lastclass; ?>">
                   <h1><?php the_title(); ?></h1>
                   <?php /*<h3><?php echo "ID : " . $row->ID; ?></h3>*/ ?>
                   <div class="custom-table">
                    <div class="row">
                      <div class="col-md-6">
                        <?php
                            $get_order = get_field('bird_family');
                            if(!empty($get_order)){ 
                            $search_order = mb_strtolower($get_order);
                            $search_order_url = site_url() . '/?s=&birdfamily='.$search_order;
                          ?>
                            <h5>Order</h5>
                            <a href="<?php echo $search_order_url; ?>" class="whitebtn"><?php echo $search_order; ?></a>
                          <?php } ?>
                      </div>
                      <div class="col-md-6">
                          <?php 
                            $get_family = get_field('bfamily');
                            if(!empty($get_family)){ 
                            $search_get_family = mb_strtolower($get_family);
                            $search_family_url = site_url() . '/?s=&family='.$search_get_family;
                          ?>
                            <h5>Family</h5>
                            <a href="<?php echo $search_family_url; ?>" class="whitebtn"><?php echo $search_get_family; ?></a>
                          <?php } ?>
                      </div>
                    </div>
                    <div class="row">
                      <div class="col-md-6">
                        <h5>Genus <span>(Similar Species)</span>
                          <?php
                          $gettxgenus = get_field('bird_taxonomic_genus');
                            if(!empty($gettxgenus)) { 
                            $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.strtolower($gettxgenus);
                          ?>
                          
                            <div class="specbtn">
                              <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo $gettxgenus; ?></a>
                            </div>
                          <?php } ?>
                      </div>
                      <?php if(!empty(get_field('bird_scientific_name'))) { ?>
                        <div class="col-md-6">
                          <h5>Scientific Name</h5>
                          <h6><?php echo get_field('bird_scientific_name'); ?></h6>
                        </div>
                    <?php } ?>
                    </div>
                   </div>
                    <ul>
                        <?php
                            $get_cs = get_field('bird_conservation_status');
                            if(!empty($get_cs)) { 
                            $search_cs = strtolower($get_cs);
                            $search_cs_url = site_url() . '/?s=&conservancy='.$search_cs;
                        ?>
                                <li>
                                    <h5>Conservation Status</h5>
                                    <a class="whitebtn" href="<?php echo $search_cs_url; ?>" target="_self"><?php echo $get_cs; ?></a>
                                </li>
                      <?php } ?>
                      </ul>
                      <div class="border-bottom-bird">
                                <div class="row">
                            <?php 
                                $scurl = '';
                                $terms = wp_get_post_terms('cp_birds_country');
                                if( !empty( $terms ) && !is_wp_error( $terms ) ) {
                                    $taxonomy = $terms[0]->name;
                                    $taxonomyid = $terms[0]->term_id;
                                    $scurl = site_url() . '/?s=&country='.strtolower($taxonomyid);
                                    ?>  
                                    <div class="col-md-6 last-child">
                                        <h5>Country</h5>
                                        <div class="newcountrybtns">
                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php echo $taxonomy; ?></a>
                                            <a href="<?php echo site_url().'/countries/'; ?>" class="whitebtn">
                                            View more Countries
                                            </a>
                                        </div>
                                    </div>
                                    <?php 
                                }
                            ?>
                                <?php if (!empty(get_field('state'))){ ?>
                                    <div class="col-md-6">
                                        <h5>State</h5>
                                        <div class="newcountrybtns">
                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php the_field('state'); ?></a>
                                        </div>
                                    </div>
                                    <?php 
                                }
                            ?>
                            </div>
                        </div>
                        <?php if ((!empty(get_field('bird_gender'))) || (!empty(get_field('bird_age')))){ ?>
                        <div class="border-bottom-bird">
                          <div class="row">
                              <?php if(!empty(get_field('bird_gender'))){ ?>
                               <div class="col-md-6 last-child">
                                    <h5>Gender </h5>
                                    <h6><?php echo get_field('bird_gender'); ?></h6>
                                </div>
                                <?php } ?>
                              <?php if(!empty(get_field('bird_age'))) { ?>
                              <div class="col-md-6">
                                <h5>Age</h5>
                                <h6><?php echo get_field('bird_age'); ?></h6>
                              </div>
                          <?php } ?>
                            
                          </div>
                        </div>
                        <?php } ?>
                        <ul>
                      <?php
                          $get_vc = get_field('bird_visual_country');
                          if(!empty($get_vc)){ 
                          $search_vc = strtolower($get_vc);
                          $search_vc_url = site_url() . '/?s=&visualcategory='.$search_vc;
                      ?>
                        <li>
                            <h5>Visual Category</h5>
                            <a class="whitebtn" href="<?php echo $search_vc_url; ?>" target="_self"><?php echo $get_vc; ?></a>
                        </li>
                      <?php } 
                        $getloc = get_field('bird_locations');
                        if(!empty($getloc) && isset($getloc)) { ?>
                        <li>
                          <h5>Birding Sites and Lodges</h5>
                          <?php 
                            if($getloc != ''){
                              $explodelocations = explode("|",$getloc);
                              foreach ($explodelocations as  $locrow) {
                                $getlocurl = od_location_search_url( $locrow );
                              ?>
                                <a class="whitebtn" href="<?php echo $getlocurl; ?>" target="_self">
                                    <?php echo $locrow; ?>
                                </a>
                              <?php
                                }
                            }
                          ?>
                        </li>
                      <?php } ?>
                      <?php 
                        $search_activityurl = '';
                        $get_activity = get_field('bird_activity');
                        if(!empty($get_activity) && isset($get_activity)) { ?>
                              <li>
                                  <h5>Activity</h5>
                                  <?php
                                      if($get_activity != ''){
                                        $explodeactivity = explode(",",$get_activity);
                                        foreach ($explodeactivity as  $activityrow) {
                                            $search_activityurl = site_url() . '/?s=&activity='.$activityrow;
                                  ?>
                                          <a class="whitebtn" href="<?php echo $search_activityurl; ?>" >
                                            <?php echo $activityrow; ?>
                                        </a>
                                  <?php } } ?>
                              </li>
                      <?php } ?>
                    </ul>
                    <?php 
                      //if(!empty($get_activity) && isset($get_activity)) { ?>
                          <div class="custom-table new-cat">
                             <div class="row">
                                  <?php
                                    if( have_rows('categories') ):
                                        while ( have_rows('categories') ) : the_row();
                                            if( get_row_layout() == 'category' ): 
                                                $name = get_sub_field('name');
                                                $value = get_sub_field('value'); ?>
                                                <div class="col-md-6">
                                                    <h5><?php echo $name; ?></h5>
                                                    <a class="whitebtn" href="<?php echo $search_activityurl; ?>" ><?php echo $value; ?></a>
                                                </div>
                                           <?php
                                            endif;                                      
                                        endwhile;
                                    else :                                      
                                    endif;
                                  ?>
                              </div>
                          </div>
                    <?php //} ?>
                   <?php $iframedata = get_field('bird_sounds'); 
                         $datataArray = explode(",", $iframedata);
                   ?>

                    <?php if(!empty($datataArray)){?>
                      <h5>BIRD CALLS</h5>
                      <?php 
                      foreach ($datataArray as $framedata) { ?>
                          <iframe src='https://www.xeno-canto.org/<?=$framedata?>/embed?simple=1&darkbg=1' height='110' width='100%' frameborder='0' scrolling='no'></iframe>                     
                    <?php } ?>
                  <?php } ?>
        
                   <!--  <?php
                    if(!empty($iframedata)) {  ?>
                      <div class="iframeappend">
                          <?php $removelastcomma = rtrim($iframedata, ','); ?>
                          <input type="hidden" id="custId" name="custId" value="<?php echo $removelastcomma; ?>">
                          <img class="iframeloader" src="<?php echo get_template_directory_uri(). '/images/loader.svg'; ?>" alt="Page Loader">
                      </div>
                    <?php  } ?> -->
              </figcaption>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php endwhile; else: ?>
  
  <h2 class="error"><?php _e( 'Not Found.','theme' ); ?></h2>
  <p class="error">Sorry, but you are looking for something that isn't here.</p>
  
<?php
  endif; wp_reset_query(); wp_reset_postdata();
  get_footer();
?>
<script type='text/javascript' src="<?php echo get_template_directory_uri(); ?>/js/hilitor.js"></script>
<script>
 /*Iframe Logic Load After Fancybox Load */
                var iframestr   =  $(".searchgallery:eq("+currentDivNo+")").find('#custId').val();
                if((typeof(iframestr) != 'undefined') &&(iframestr) && (iframestr !== null) && (iframestr !== '')){
                    var ifrmaesplit = iframestr.split(',');
                    var ihtml = '';
                    for(var i = 0; i < ifrmaesplit.length; i++) {
                       // Trim the excess whitespace.
                        ifrmaesplit[i] = ifrmaesplit[i].replace(/^\s*/, "").replace(/\s*$/, "");
                        //ifrmaesplit[i] = ifrmaesplit[i].trim();
                        //ifrmaesplit[i] = ifrmaesplit[i].replace(/^\s*/, "");

                        // Add additional code here, such as:
                        ihtml +="<iframe src='https://www.xeno-canto.org/"+ifrmaesplit[i]+"/embed?simple=1&darkbg=1' height='110' width='100%' frameborder='0' scrolling='no'></iframe>";
                    }
                    $(".fancybox-container").contents().find( ".fancybox-caption").find('.countrydetails').find(".iframeappend" ).append(ihtml);
                    $(".fancybox-caption .iframeappend iframe").load(function(){
                        $(".iframeloader").hide();
                    });
                }
</script>