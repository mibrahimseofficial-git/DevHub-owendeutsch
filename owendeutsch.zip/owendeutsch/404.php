<?php get_header(); ?>

<div class="container search">
	
	<div class="image">
	<img src="<?php echo get_site_url(); ?>/wp-content/uploads/2019/04/error404-compressed-1.jpg" alt="404">
	</div>
		<h1 class="404-page-title">Page not found!</h1>
		<p>The page you are looking for might have been removed, had its name changed or is temporarily unavailable</p>
	
</div>

<?php get_footer(); ?>