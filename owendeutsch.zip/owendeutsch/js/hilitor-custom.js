/*
 *  Customized Jquery for Site.
 */

( function($) {
    $( document ).ready( function() {
       HighlightKeywords();
    });
   function HighlightKeywords(){
        window.addEventListener("DOMContentLoaded", function(e) {
            var myHilitor2 = new Hilitor("playground");
            //myHilitor2.setEndRegExp('^[^\\w-]+|[^\\w]+$');
  			//myHilitor2.setBreakRegExp(new RegExp('[^\\w\' - ]+', "g"));
            myHilitor2.setMatchType("left");
            var searchterm = $("#searchfocus").val();
            myHilitor2.apply(searchterm);
        }, false);
    }
    $(window).load(function() {
        var search_inputFocus = $("#searchfocus");
        if( search_inputFocus.val().length > 0 ){
            var len = search_inputFocus.val().length;
            search_inputFocus[0].focus();
            search_inputFocus[0].setSelectionRange(len, len);
        }
        HighlightKeywords();
    });
   
} )( jQuery );