/*Live Example: https://demo.tutorialzine.com/2015/08/how-to-control-youtubes-video-player-with-javascript/*/
var player, time_update_interval = 0; 

window.onYouTubeIframeAPIReady = function() {
    console.log("YouTube API Ready");
    player = new YT.Player('video-placeholder', {
        videoId: mainvideoid,
        playerVars: {
            // 'autoplay':0,
            'color': 'white',
            'rel': 0,
            'iv_load_policy':3,
            'playsinline':1
            //playlist: 'ou8srKBNIyk,XzgpQuNv1aE,uJ5nljMxZP8,5o2ho8KY3gs,bb00EOT_U7w,QMB4Z5p9kp8,svzs8emb3Xc,axoCf4oHfds'
            //playlist:vdos,
        },
        events: {
            'onReady': initialize,
            'onStateChange':onPlayerStateChange,
            'onPlaybackQualityChange' : onPlaybackQualityChange,
        },
    });
}

function initialize(){
    // Update the controls on load
    //updateTimerDisplay();
    //updateProgressBar();
    // var playButton = document.getElementById("#play");
    //   playButton.addEventListener("click", function() {
    //     player.playVideo();


    //   });
    //player.playVideo();
    
}
function onPlayerStateChange(event) {
    if (event.data == YT.PlayerState.BUFFERING) {
        event.target.setPlaybackQuality('hd1080');
    }if (event.data == YT.PlayerState.PLAYING) {
        event.target.setPlaybackQuality('hd1080');
    }
}
function onPlaybackQualityChange(event) {
    if (event.data == YT.PlayerState.BUFFERING) {
        event.target.setPlaybackQuality('hd1080');
    }if (event.data == YT.PlayerState.PLAYING) {
        event.target.setPlaybackQuality('hd1080');
    }
}


// Playback
jQuery('#play').on('click', function () {
    setTimeout(function(){ 
        jQuery('html, body').animate({
            scrollTop: jQuery("body").offset().top - 120
        }, 1000)
    }, 200);
    player.stopVideo();
    //player.cueVideoById(mainvideoid);
    player.cueVideoById({videoId:mainvideoid,suggestedQuality:'hd1080'});
    player.cuePlaylist({playlist:vdos,suggestedQuality:'hd1080'});
    player.setPlaybackQuality('hd1080');
});

// Helper Functions
