jQuery(document).ready(function ($) {
  $("#sortable-birds").sortable();

  $("#save-bird-order").on("click", function () {
    const order = [];

    $("#sortable-birds .sortable-item").each(function () {
      order.push($(this).data("id"));
    });

    $.post(
      BirdSort.ajax_url,
      {
        action: "save_bird_order",
        order: order,
        nonce: BirdSort.nonce,
      },
      function (res) {
        if (res.success) {
          alert("Order saved!");
        } else {
          alert("Failed to save.");
        }
      }
    );
  });
});
