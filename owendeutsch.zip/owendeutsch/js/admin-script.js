/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

jQuery( document ).ready(function($) {
	jQuery( "input:checkbox[name='tax_input[cp_birds_country][]']" ).addClass( "check" );
	jQuery('.check').click(function() {
		jQuery('.check').not(this).prop('checked', false);
		jQuery( "input[name='tax_input[cp_birds_country][]']" ).not(this).removeAttr('checked');
		jQuery("#cp_birds_countrychecklist li").removeClass('popular-category');
	});

	// jQuery('#publish').click(function() 
	//   {
	//   	//alert('in');
	//     var cats = jQuery('[id^=\"taxonomy-cp_birds_country\"]')
	//       .find('.selectit')
	//       .find('input');
	//     category_selected=false;
	//     for (counter=0; counter<cats.length; counter++) 
	//     {
	//         if (cats.get(counter).checked==true) 
	//         {
	//             category_selected=true;
	//             break;
	//         }
	//     }
	//     if(category_selected==false) 
	//     {
	//       alert('You have not selected any category for the post. Please select post category.');
	//       setTimeout("jQuery('#ajax-loading').css('visibility', 'hidden');", 100);
	//       jQuery('[id^=\"taxonomy-cp_birds_country\"]').find('.tabs-panel').css('background', '#F96');
	//       setTimeout("jQuery('#publish').removeClass('button-primary-disabled');", 100);
	//       return false;
	//     }
	//   });
});