/*
 *  Customized Jquery for Site.
 */

( function($) {
    
    var canBeLoaded = true, 
    bottomOffset = 3000; 
    
    $( document ).ready( function() {

        jQuery('.responsive-menu').click(function () {
            jQuery(".header-menu-responsive").css({"transform": "translateX(0)"});
            setTimeout(
                  function() 
                  {
                      jQuery("body").css({ "overflow-y": "hidden","height": "100%"}  );
                  }, 100);
        });

        jQuery('a.menu-close-btn').click(function () {
            jQuery(".header-menu-responsive").css({"transform": "translateX(100%)"});
            setTimeout(
                  function() 
                  {
                      jQuery("body").css({ "overflow-y": "inherit","height": "inherit" }  );
                  }, 100);
            
        });


           $('#past-life').owlCarousel({
                loop:false,
                margin:10,
                nav:true,
                touchDrag  : true,
                mouseDrag  : false,
                navText: ["<img src='../wp-content/themes/owendeutsch/images/left-arrow.png'>","<img src='../wp-content/themes/owendeutsch/images/right-arrow.png'>"],
                dots:false,
                responsive:{
                    0:{
                        items:1
                    },
                    640:{
                        items:2
                    },
                    1000:{
                        items:7
                    }
                }
            });

            $('.owl-carousel').owlCarousel({
                loop:false,
                margin:10,
                nav:true,
                navText: ["<img src='../wp-content/themes/owendeutsch/images/left-arrow.png'>","<img src='../wp-content/themes/owendeutsch/images/right-arrow.png'>"],
                dots:false,
                responsive:{
                    0:{
                        items:1
                    },
                    640:{
                        items:2
                    },
                    1000:{
                        items:5
                    }
                }
            });

            $('[data-fancybox="images"]').fancybox({
                thumbs : {
                        autoStart : true
                },
                buttons: [
                    "slideShow",
                    "fullScreen",
                    "thumbs",
                    "close"
                  ]
            }); 
			
			jQuery('[data-fancybox="imagescountry"]').fancybox({
				baseClass: "fancybox-custom-layout",
				infobar: false,
				touch: {
				  vertical: false
				},
				buttons: ["close", "slideShow","fullScreen"],
				
				animationEffect: "fade",
				transitionEffect: "fade",
				preventCaptionOverlap: false,
				idleTime: false,
				gutter: 0,
				// Customize caption area
				caption : function( instance, item ) {
					return $(this).find('figcaption').html();
				},
				
			});

            // $('.grid-item1').fancybox({
                // thumbs : {
                        // autoStart : true
                // },
                // buttons: [
                    // "slideShow",
                    // "fullScreen",
                    // "thumbs",
                    // "close"
                  // ],
                  // beforeLoad : function(e) {
                    //var url = window.location.href;
                    // var siteUrl = $('#base_url').val();
                    // console.log(siteUrl);
                    // $('.fancybox-thumbs').append("<a href='"+siteUrl+"/countries/' class='country_btn'>View more Countries</a>");
                  // }
            // }); 
			//jQuery("body").mCustomScrollbar({
				//theme:"light",
				//axis: "y"
			//});

    } );

    $(window).scroll(function(){
      var sticky = $('header'),
          scroll = $(window).scrollTop();
          var navbarHeight1 = 40;

      if (scroll >= navbarHeight1) sticky.addClass('fixed');
      else sticky.removeClass('fixed');
    });


    $( ".search-text" ).autocomplete({
        
        source: function( request, response ) {
            $(".load-more-section").css("display","none");
            search = replaceWordChars(request.term);
            $.ajax({
                
                url: OWNBIRD.ajaxurl,
                type: "POST",
                //dataType: "json",
                data: {
                    'q' : search,
                    'action' : 'autocomplate',
                },
                beforeSend: function(){
                 // Handle the beforeSend event
                 jQuery(".load-more-section").css("display","block");
                },
                success: function( data ) {
                    response( JSON.parse(data) );
                    
                }
            });
        },

        select: function( event, ui ) {
            var place = $(this).data('place');
            var term_id = '';
            var action = 'search_birds_from_keyword';
            var $this = $(this);
            $('#paged').val(1);
            canBeLoaded = true;
            $(".load-more-section").css("display","none");
            
            $("h2.large").css('display','block') ;
            window.location.href = '/?s=' + ui.item.label;
		},
        open: function(event, ui) {
			$('.ui-autocomplete').off('menufocus hover mouseover mouseenter');
            $( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
            
        },
        close: function() {
            $( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
            
        }
        
    });

    $('#s').keypress(function(e){
        if(e.which == 13){//Enter key pressed
            $('#search_birds').click();//Trigger search button click event
        }
    });

    $('.header-search .search-box-header').keypress(function(e){
        //var code = e.keyCode || e.which;
        if(e.which == 13){ //Enter keycode
            
            var val = $('.header-search .search-box-header').val();
            var place = $('.header-search .search-box-header').data('place');
            window.location.href = '/?s=' + val;
        }
    });
    function replaceWordChars (text) {
    var s = text;
    // smart single quotes and apostrophe
    s = s.replace(/[\u2018|\u2019|\u201A]/g, "\'");
    // smart double quotes
    s = s.replace(/[\u201C|\u201D|\u201E]/g, "\"");
    // ellipsis
    s = s.replace(/\u2026/g, "...");
    // dashes
    s = s.replace(/[\u2013|\u2014]/g, "-");
    // circumflex
    s = s.replace(/\u02C6/g, "^");
    // open angle bracket
    s = s.replace(/\u2039/g, "");
    // spaces
    s = s.replace(/[\u02DC|\u00A0]/g, " ");

    return s;
}

    $(document).on('click','.search-custom-related li',function(e){
        e.preventDefault();
        var search = $(this).data('term_name');
        var term_id = $(this).data('term_id');
        $('#s').val(search);
        $('#paged').val(1);
        canBeLoaded = true;
        var $this = $(this);
        $("h2.large").css('display','block') ;
        $(".search-results").html('') ;

        search_callbak(search,term_id,$this);
    });


    function search_callbak(search,term_id,$this) {
        $('.loader-icon').show();
        $(".load-more-section").css("display","none");
        $.ajax({
            url: OWNBIRD.ajaxurl,
            type: "POST",
            data: {
                action  : 'search_birds_from_keyword',
                searchtxt : search,
                paged : 1
            },
            dataType: "json",
            success: function(response){ 
                if($.trim(response.output) == '' ){
                    $(".search-results").html("<h2>No birds found</h2>");
                    //$(".relates-search-option").show();
                    
                }
                else {
                    window.location.href = '/?s=' + searchtxt;
                    /*$(".relates-search-option").hide();*/
                    $(".load-more-section").css("display","block");
                    
                }
                
                if(term_id == '') {
                    $('.search-custom-related li').removeClass('active');
                }
                else {
                     $('.search-custom-related li').removeClass('active');
                    $(this).addClass('active');
                }
                $('.loader-icon').hide();
                
            },
            error: function (jqXHR, textStatus, errorThrown) {
                alert('Something went wrong.');
                $('.loader-icon').hide();
                
            }
        });
    }
    
    
    $('.clear-search').click(function() {
        $('#s').val('');
        window.location.href = '/?s=';
        $('#search-tags-result li').removeClass('active');
        $('h2.large').css('display','none');
        $(".search-results").html('');
        $(".load-more-section").css("display","none");        
    });

    
    
    $('.search-btn').click(function () {
		var val = $('.header-search .search-text').val();
        var place = $('.header-search .search-text').data('place');
        window.location.href ='/?s=' + val;
    });
	
} )( jQuery );
