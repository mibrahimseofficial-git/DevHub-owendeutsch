/*
 *  Customized Jquery for Site.
 */

( function($) {
    
    var canBeLoaded = true, 
    bottomOffset = 3000; 
    $( document ).ready( function() {
        check_height();
        setActiveClassDropdown();
        jQuery('#search_birds').on('click', function(e) {
           // e.preventDefault();
            var search              = replaceWordChars(jQuery('#searchfocus').val());
            var country_value       = jQuery('.country-filter .dropdown-menu li.active a').attr("data-countryfilter");
            var gender_value        = jQuery('.gender-filter .dropdown-menu li.active a').attr("data-gender");
            var min_age             = jQuery('.age-filter .dropdown-menu li.active a').attr("data-minage");
            var max_age             = jQuery('.age-filter .dropdown-menu li.active a').attr("data-maxage");
            var conservancy_value   = jQuery('.conservancy-filter .dropdown-menu li.active a').attr("data-bird-conservancy");
            var activity_value      = jQuery('.activity-filter .dropdown-menu li.active a').attr("data-bird-activity");
            var birdfamily_value    = jQuery('.bird-family-filter .dropdown-menu li.active a').attr("data-bird-family");
            var birdage_value       = jQuery('.age-filters .dropdown-menu li.active a').attr("data-bird-age");
            var taxonomic_value     = jQuery('.taxonomic-genus-filter .dropdown-menu li.active a').attr("data-taxonomic-genus");
            var locations_value     = jQuery('.locations-filter .dropdown-menu li.active a').attr("data-bird-locations");
            var visualcategory_value    = jQuery('.visualcategory-filter .dropdown-menu li.active a').attr("data-bird-visualcategory");
            var current_url         = window.location.href;
            
            var params = {
                country:country_value, 
                gender:gender_value,
                minage:min_age,
                maxage:max_age,
                age:birdage_value,
                conservancy:conservancy_value,
                activity:activity_value,
                birdfamily:birdfamily_value,
                taxonomicgenus:taxonomic_value,
                locations:locations_value,
                visualcategory:visualcategory_value
            };
              
            for(key in params){
                if((params[key] == null || params[key] == "")) {
                    delete params[key];
                }
            }
            var str = jQuery.param( params );
            if(str != ''){
                var newUrl = site_url +'/?s=' + search + '&' + str;
            }else{
                var newUrl = site_url +'/?s=' + search;
            }
            /*window.history.pushState({path:newUrl},'',newUrl);*/
            window.location.href = newUrl;
        });
        
        jQuery('.responsive-menu').click(function () {
            jQuery(".header-menu-responsive").css({"transform": "translateX(0)"});
            setTimeout(
                  function() 
                  {
                      jQuery("body").css({ "overflow-y": "hidden","height": "100%"}  );
                  }, 100);
        });

        jQuery('a.menu-close-btn').click(function () {
            jQuery(".header-menu-responsive").css({"transform": "translateX(100%)"});
            setTimeout(
                  function() 
                  {
                      jQuery("body").css({ "overflow-y": "inherit","height": "inherit" }  );
                  }, 100);
            
        });
        $('#past-life').owlCarousel({
            loop:false,
            margin:10,
            nav:true,
            touchDrag  : true,
            mouseDrag  : false,
            navText: ["<img src='../wp-content/themes/owendeutsch/images/left-arrow.png'>","<img src='../wp-content/themes/owendeutsch/images/right-arrow.png'>"],
            dots:false,
            responsive:{
                0:{
                    items:1
                },
                640:{
                    items:2
                },
                1000:{
                    items:7
                }
            }
        });
        $('.owl-carousel').owlCarousel({
            loop:false,
            margin:10,
            nav:true,
            navText: ["<img src='../wp-content/themes/owendeutsch/images/left-arrow.png'>","<img src='../wp-content/themes/owendeutsch/images/right-arrow.png'>"],
            dots:false,
            responsive:{
                0:{
                    items:1
                },
                640:{
                    items:2
                },
                1000:{
                    items:5
                }
            }
        });
        jQuery('[data-fancybox="imagescountry"]').fancybox({
            baseClass: "fancybox-custom-layout",
            infobar: false,
            touch : false,
            wheel:false,
            buttons: ["close", "slideShow","fullScreen"],
            animationEffect: "fade",
            transitionEffect: "fade",
            preventCaptionOverlap: false,
            idleTime: false,
            clickOutside:false,
            gutter: 0,
            // zoom:false,
            caption : function( instance, item ) {
                return $(this).find('figcaption').html();
            },
            afterShow: function( instance, current ) {
                var currentDivNo = instance.currIndex;
                /*Iframe Logic Load After Fancybox Load */
                var iframestr   =  $(".grid-item1:eq("+currentDivNo+")").find('#custId').val();
                if((typeof(iframestr) != 'undefined') &&(iframestr) && (iframestr !== null) && (iframestr !== '')){
                    var ifrmaesplit = iframestr.split(',');
                    var ihtml = '';
                    for(var i = 0; i < ifrmaesplit.length; i++) {
                       // Trim the excess whitespace.
                        ifrmaesplit[i] = ifrmaesplit[i].replace(/^\s*/, "").replace(/\s*$/, "");
                        /*Add additional code here, such as:*/
                        ihtml +="<iframe src='https://www.xeno-canto.org/"+ifrmaesplit[i]+"/embed?simple=1&darkbg=1' height='110' width='100%' frameborder='0' scrolling='no'></iframe>";
                    }
                    $(".fancybox-container").contents().find( ".fancybox-caption").find('.countrydetails').find(".iframeappend" ).append(ihtml);
                    $(".fancybox-caption .iframeappend iframe").load(function(){
                        $(".iframeloader").hide();
                    });
                }
            }
        });

    });
    
    function check_height() {
                setTimeout(function(){
                    jQuery(".fancybox-navigation").appendTo(jQuery(".fancybox-stage"));
                }, 100);
        }
        jQuery(".grid-item1").on("click", function(){
            check_height();
        });

        jQuery(".conservationgallery").on("click", function(){
            check_height();
        });

        jQuery(".searchgallery").on("click", function(){
            check_height();
    });
        
    function setActiveClassDropdown()
    {
        var getCountryActive = $.trim(jQuery('.country-filter ul.dropdown-menu li.active').text());
        if(getCountryActive != '') {
            jQuery('.country-filter .custom-dropdown span#selected').text(getCountryActive);
        }
        var getGenderActive = $.trim(jQuery('.gender-filter ul.dropdown-menu li.active').text());
        if(getGenderActive != '') {
            jQuery('.gender-filter .custom-dropdown span#genderselected').text(getGenderActive);
        }
        var getAgeActive = $.trim(jQuery('.age-filter ul.dropdown-menu li.active').text());
        if(getAgeActive != '') {
            jQuery('.age-filter .custom-dropdown span#ageselected').text(getAgeActive);
        }
        var getConservancyActive = $.trim(jQuery('.conservancy-filter ul.dropdown-menu li.active').text());
        if(getConservancyActive != '') {
            jQuery('.conservancy-filter .custom-dropdown span#conservancyselected').text(getConservancyActive);
        }
        var getActivityActive = $.trim(jQuery('.activity-filter ul.dropdown-menu li.active').text());
        if(getActivityActive != '') {
            jQuery('.activity-filter .custom-dropdown span#activityselected').text(getActivityActive);
        }
        var getBirdfamilyActive = $.trim(jQuery('.bird-family-filter ul.dropdown-menu li.active').text());
        if(getBirdfamilyActive != '') {
            jQuery('.bird-family-filter .custom-dropdown span#birdfamilyselected').text(getBirdfamilyActive);
        }
        var getTaxonomicActive = $.trim(jQuery('.taxonomic-genus-filter ul.dropdown-menu li.active').text());
        if(getTaxonomicActive != '') {
            jQuery('.taxonomic-genus-filter .custom-dropdown span#taxonomicselected').text(getTaxonomicActive);
        }
        var getAgeActive = $.trim(jQuery('.age-filters ul.dropdown-menu li.active').text());
        if(getAgeActive != '') {
            jQuery('.age-filters .custom-dropdown span#mainageselected').text(getAgeActive);
        }
        var getLocationsActive = $.trim(jQuery('.locations-filter ul.dropdown-menu li.active').text());
        if(getLocationsActive != '') {
            jQuery('.locations-filter .custom-dropdown span#locationselected').text(getLocationsActive);
        }
        var getVisualCategoryActive = $.trim(jQuery('.visualcategory-filter ul.dropdown-menu li.active').text());
        if(getVisualCategoryActive != '') {
            jQuery('.visualcategory-filter .custom-dropdown span#visualcategoryselected').text(getVisualCategoryActive);
        }

        jQuery('.country-filter .dropdown-menu a').click(function(){
            $('.country-filter .dropdown-menu li').removeClass('active');
            jQuery('#selected').text($(this).text());
            $(this).parent().addClass('active');
        });
        jQuery('.gender-filter .dropdown-menu a').click(function(){
            $('.gender-filter .dropdown-menu li').removeClass('active');
            jQuery('#genderselected').text($(this).text());
            $(this).parent().addClass('active');
        });
        jQuery('.age-filter .dropdown-menu a').click(function(){
            $('.age-filter .dropdown-menu li').removeClass('active');
            jQuery('#ageselected').text($(this).text());
            $(this).parent().addClass('active');
            jQuery('.age-filter .dropdown-menu li.active a').attr("data-minage");
        });
        jQuery('.age-filters .dropdown-menu a').click(function(){
            $('.age-filters .dropdown-menu li').removeClass('active');
            jQuery('#mainageselected').text($(this).text());
            $(this).parent().addClass('active');
            jQuery('.age-filters .dropdown-menu li.active a').attr("data-bird-age");
        });
        jQuery('.conservancy-filter .dropdown-menu a').click(function(){
            $('.conservancy-filter .dropdown-menu li').removeClass('active');
            jQuery('#conservancyselected').text($(this).text());
            $(this).parent().addClass('active');
        });
        jQuery('.activity-filter .dropdown-menu a').click(function(){
            $('.activity-filter .dropdown-menu li').removeClass('active');
            jQuery('#activityselected').text($(this).text());
            $(this).parent().addClass('active');
        });
        jQuery('.bird-family-filter .dropdown-menu a').click(function(){
            $('.bird-family-filter li').removeClass('active');
            jQuery('#birdfamilyselected').text($(this).text());
            $(this).parent().addClass('active');
        });
        jQuery('.taxonomic-genus-filter .dropdown-menu a').click(function(){
            $('.taxonomic-genus-filter li').removeClass('active');
            jQuery('#taxonomicselected').text($(this).text());
            $(this).parent().addClass('active');
        });
        jQuery('.locations-filter .dropdown-menu a').click(function(){
            $('.locations-filter li').removeClass('active');
            jQuery('#locationselected').text($(this).text());
            $(this).parent().addClass('active');
        });
        jQuery('.visualcategory-filter .dropdown-menu a').click(function(){
            $('.visualcategory-filter li').removeClass('active');
            jQuery('#visualcategoryselected').text($(this).text());
            $(this).parent().addClass('active');
        });
    }
    $(window).load(function() {
         setTimeout(function(){
          $(".load-map .globe-loader").fadeOut("fast");
        }, 6000);
        $(".se-pre-con").fadeOut();
        $("body").css({"overflow": "visible", "height": "auto"});
        setTimeout(function(){ 
            setActiveClassDropdown(); 
        }, 1000);
        
    });
    $(window).scroll(function(){
      var sticky = $('header'),
          scroll = $(window).scrollTop();
          var navbarHeight1 = 40;

      if (scroll >= navbarHeight1) sticky.addClass('fixed');
      else sticky.removeClass('fixed');
    });
    $( ".search-text" ).autocomplete({
        minLength: 2,
        source: function( request, response ) {
            //$("loader-icon").css("display","none");
            search = replaceWordChars(request.term);
            console.log(search);
            $.ajax({
                url: OWNBIRD.ajaxurl,
                type: "POST",
                //dataType: "json",
                data: {
                    'q' : search,
                    'action' : 'autocomplate',
                },
                beforeSend: function(){
                 // Handle the beforeSend event
                 //jQuery(".loader-icon").css("display","block");
                },
                success: function( data ) {
                    response( JSON.parse(data) );
                    
                }
            });
        },
        select: function( event, ui ) {
            var autocomplateUrl = site_url + '/?s=' + ui.item.label;
            window.location.href = autocomplateUrl;
        },
        open: function(event, ui) {

            $('.ui-autocomplete').off('menufocus hover mouseover mouseenter');
            $( this ).removeClass( "ui-corner-all" ).addClass( "ui-corner-top" );
            
        },
        close: function() {
            $( this ).removeClass( "ui-corner-top" ).addClass( "ui-corner-all" );
            
        }
    });
    // $('#s').keypress(function(e){
    //     if(e.which == 13){//Enter key pressed
    //         $('#search_birds').click();//Trigger search button click event
    //     }
    // });
    $('.header-search .search-box-header').keypress(function(e){
        //var code = e.keyCode || e.which;
        if(e.which == 13){ //Enter keycode
            var val = $('.header-search .search-box-header').val();
            var place = $('.header-search .search-box-header').data('place');
            var headerOnClickUrl = site_url + '/?s=' + val;
            window.location.href = '/?s=' + val;
        }
    });
    function replaceWordChars (text) 
    {
        var s = text;
        // smart single quotes and apostrophe
        s = s.replace(/[\u2018|\u2019|\u201A]/g, "\'");
        // smart double quotes
        s = s.replace(/[\u201C|\u201D|\u201E]/g, "\"");
        // ellipsis
        s = s.replace(/\u2026/g, "...");
        // dashes
        s = s.replace(/[\u2013|\u2014]/g, "-");
        // circumflex
        s = s.replace(/\u02C6/g, "^");
        // open angle bracket
        s = s.replace(/\u2039/g, "");
        // spaces
        s = s.replace(/[\u02DC|\u00A0]/g, " ");

        return s;
    }
    // $(document).on('click','.search-custom-related li',function(e){
    //     e.preventDefault();
    //     var search = $(this).data('term_name');
    //     var term_id = $(this).data('term_id');
    //     // $('#s').val(search);
    //     // $('#paged').val(1);
    //     canBeLoaded = true;
    //     var $this = $(this);
    //     $("h2.large").css('display','block') ;
    //     $(".search-results").html('') ;

    //     search_callbak(search,term_id,$this);
    // });
    $('.clear-search').click(function() {
        $('#searchfocus').val('');
        var blankUrl = site_url + '/?s=';
        window.location.href = blankUrl;
        $('.country-filter .dropdown-menu li').removeClass('active');
        /*$('#search-tags-result li').removeClass('active');
        $('h2.large').css('display','none');
        $(".search-results").html('');
        $(".load-more-section").css("display","none");*/        
    });
    $('.search-btn').click(function () {
        var val = $('.header-search .search-text').val();
        var place = $('.header-search .search-text').data('place');
        var headerUrl = site_url + '/?s=' + val;
        window.location.href = headerUrl;
    });
    $( ".submitsearch a" ).click(function() {
      $( "#search_birds" ).trigger( "click" );
    });
} )( jQuery );