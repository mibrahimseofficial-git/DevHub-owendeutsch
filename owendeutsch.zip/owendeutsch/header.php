<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=0"/>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />
<meta name="msvalidate.01" content="6051B7341FFF7AAC4FE005173941B18C" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!--[if lt IE 9]>

  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>

  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>

<![endif]-->
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-KYQ10WWELQ"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-KYQ10WWELQ');
</script>
<script type="text/javascript">

	var tempdir = "<?php echo get_template_directory_uri(); ?>";

</script>

<script
  src="https://code.jquery.com/jquery-3.6.1.js"
  integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
  crossorigin="anonymous"></script>
<!-- <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js" ></script> -->

<?php //wp_enqueue_script( 'jquery' );  ?>

<?php wp_head(); ?>
<script>
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

ga('create', 'UA-3248496-1', 'auto');
ga('send', 'pageview');
</script>
<script>
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '723046811532883');
fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
src="https://www.facebook.com/tr?id=723046811532883&ev=PageView&noscript=1"/></noscript>
<!-- End Facebook Pixel Code -->
<script type="application/ld+json">{
    "@context": {
	    "@vocab": "https://owendeutsch.com/"
	    },
	    "@graph": [
	    {
	    "@id": " https://owendeutsch.com/",
	    "@type": "Organization",
	    "name": "Owen Deutsch Photography",
	    "url" : " https://owendeutsch.com/",
	    "logo" : " https://owendeutsch.com/wp-content/uploads/2019/05/logo.png",
	    "sameAs" : ["https://www.facebook.com/OwenDeutschPhotography"]         
	    }  ]
    }
        </script>
<script type='text/javascript'>
	window.__lo_site_id = 220193;

	(function() {
		var wa = document.createElement('script'); wa.type = 'text/javascript'; wa.async = true;
		wa.src = 'https://d10lpsik1i8c69.cloudfront.net/w.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(wa, s);
	  })();
</script>

</head>
<?php if ( is_search() ) { ?>
<script type="text/javascript">
  jQuery(document).ready(function() {
	if(window.location.hash != ''){
		var elementOffset = jQuery('.container-search').offset().top-20;
			jQuery('html, body').animate(
				{ scrollTop: elementOffset }, 
			1000);
	}
  });
</script>
<?php }
if ( (isset($_REQUEST['s']) && (!empty($_REQUEST['s'])))  || (isset($_REQUEST['country'])) || (isset($_REQUEST['birdfamily'])) || (isset($_REQUEST['country'])) || (isset($_REQUEST['country'])) || (isset($_REQUEST['country'])) || (isset($_REQUEST['taxonomicgenus'])) || (isset($_REQUEST['conservancy'])) || (isset($_REQUEST['activity'])) || (isset($_REQUEST['locations'])) || (isset($_REQUEST['visualcategory']))) {
	//if(empty($_REQUEST['s']) || (isset($_REQUEST['country']))) {
		?>
			<script>
				jQuery( document ).ready(function() {
					if(window.location.hash == ''){
						var elementOffset = jQuery('#search-results-container').offset().top - 80;
						jQuery('html, body').animate({ scrollTop: elementOffset }, 1000);
					}
				});
			</script>
		<?php
	// }
}
?>


<?php if(!is_page('test')){ ?>
<div class="se-pre-con">
		<div class="se-pre-con-inner">
			<div class="image loading-text">
				<?php 
					$loader_img = get_field('loader_gif_image','option');
					$main_logo = get_field('logo_image','option');
				?>
				<img src="<?php echo $loader_img['url']; ?>" alt="<?php echo $loader_img['alt']; ?>" class="bird" />

				<img src="<?php echo $main_logo['url']; ?>" alt="<?php echo $main_logo['alt']; ?>" class="loader-logo" />

			</div>

		</div>
</div>
<?php } ?>
<main>

<div id="main" class="scrolling-custom">

<?php

	global $THEME_PATH, $HOME_URL;

	$THEME_PATH = get_template_directory_uri();

	$HOME_URL  = esc_url( home_url( '' ) );

?>
<input type="hidden" id="base_url" name="base_url" value="<?php echo $HOME_URL; ?>">
	
    <div class="loader-icon" style="display: none;">
        <div class="before-page-loader">
            <div class="cube">
                <img src="<?php echo get_template_directory_uri(). '/images/loader.svg'; ?>" alt="Page Loader">
            </div>
        </div>
    </div>

	

	<!-- ======================= header start ======================= -->

<body <?php body_class(); ?>>

<style>
body { overflow-y: visible !important; max-height: 100% !important; }
</style>
	<header id="mainhead">

		<div class="header-logo">
			<a href="<?php echo $HOME_URL; ?>">
				<img src="<?php echo $main_logo['url']; ?>" alt="<?php echo $main_logo['alt']; ?>" />
			</a>
		</div>
		<div class="header-menu">
			<div class="menu-container text-right">
				<?php  wp_nav_menu( array( 'theme_location' => 'main-menu', 'container' => 'false' ) ); ?>
			</div>
		</div>
		<div class="header-search">	
			<?php get_search_form(); ?>		
                    <?php
                    // $search = '';
                    // if(isset($_GET['s']) && !empty($_GET['s'])) {
                    //     $search = $_GET['s'];
                    // }
                    ?>
                    <!-- <input class="search-text search-box-header" data-place="header" type="text" value="" placeholder="Search" value="<?php echo $search; ?>"/>
                    <span>
                        <i class="fa fa-search" aria-hidden="true"></i>
                        <input class="search-btn" type="button" value="" />
                    </span> -->
		</div>

                <div class="responsive-search">
                    <a href="<?php echo site_url();?>/?s="><i class="fa fa-search" aria-hidden="true"></i></a>
                 
		</div>
            
		<div class="menu responsive-menu">

			<span class="icon-bar"></span>

			<span class="icon-bar"></span>

			<span class="icon-bar"></span>

		</div>

	</header>



	<!-- ======================= main content ======================= -->

	<div id="content-area" class="main-content">
		