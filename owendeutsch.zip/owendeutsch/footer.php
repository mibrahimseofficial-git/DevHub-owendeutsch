</div>

<?php
global $THEME_PATH, $HOME_URL;
$THEME_PATH = get_template_directory_uri();
$HOME_URL = esc_url(home_url(''));
?>
<!-- ======================= footer start ======================= -->
<footer>
	<div class="large-container">
		<div class="footer-container">
			<div class="custom-row">
				<div class="custom-row-1 row-inner">
					<?php  //wp_nav_menu( array( 'theme_location' => 'footer-menu', 'container' => 'false' ) ); 
					?>
				</div>
				<div class="custom-row-2 row-inner">
					<!-- ===================NEW NEWSLETTER FORM FROM MAILCHIMP=================== -->

					<div id="mc_embed_shell">
						<link href="//cdn-images.mailchimp.com/embedcode/classic-061523.css" rel="stylesheet"
							type="text/css">

						<div id="mc_embed_signup">
							<form
								action="https://owendeutsch.us18.list-manage.com/subscribe/post?u=bb524d65c5996e0d54cda911f&amp;id=cc033265a2&amp;f_id=0005aae6f0"
								method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form"
								class="validate" target="_blank">
								<div id="mc_embed_signup_scroll">
									<label for="mce-EMAIL" class="control-label">Sign up for our newsletter.</label>
									<div class="form-group">

										<div class="mc-field-group">
											<input type="email" name="EMAIL" class="required email form-control"
												id="mce-EMAIL" required="" value="" placeholder="Enter Email Address">
										</div>
										<div aria-hidden="true" style="position: absolute; left: -5000px;">
											<input type="text" name="b_bb524d65c5996e0d54cda911f_cc033265a2"
												tabindex="-1" value="">
										</div>
										<button type="submit" value="" id="mc-embedded-subscribe" href="#"
											class="btn subscribe-btn "><i class="fa fa-long-arrow-right"
												aria-hidden="true"></i>
										</button>
									</div>
								</div>
							</form>


						</div>
						<div class="custom-row-3 row-inner text-right">
							<ul class="social test">
								<li><a href="<?php echo get_field('facebook_url', 'option'); ?>" target="_blank">
										<i class="fa fa-facebook" aria-hidden="true"></i></a>
								</li>
								<li><a href="<?php echo get_field('instagram_url', 'option'); ?>" target="_blank">
										<i class="fa fa-instagram" aria-hidden="true"></i></a>
								</li>
								<li><a href="<?php echo get_field('youtube_link', 'option'); ?>" target="_blank">
										<i class="fa fa-youtube-play" aria-hidden="true"></i></a>
								</li>
							</ul>

						</div>


						<script type="text/javascript"
							src="//s3.amazonaws.com/downloads.mailchimp.com/js/mc-validate.js"></script>
						<script
							type="text/javascript">
							(function($) {
								window.fnames = new Array();
								window.ftypes = new Array();
								fnames[0] = 'EMAIL';
								ftypes[0] = 'email';
								fnames[1] = 'FNAME';
								ftypes[1] = 'text';
								fnames[2] = 'LNAME';
								ftypes[2] = 'text';
								fnames[3] = 'ADDRESS';
								ftypes[3] = 'address';
								fnames[4] = 'PHONE';
								ftypes[4] = 'phone';
								fnames[5] = 'BIRTHDAY';
								ftypes[5] = 'birthday';
							}(jQuery));
							var $mcj = jQuery.noConflict(true);
						</script>

					</div>
					<div id="mce-responses" class="clear">
						<div class="response" id="mce-error-response" style="display: none;"></div>
						<div class="response" id="mce-success-response" style="display: none;"></div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-12">
					<p class="site-by">
						©<?php echo date("Y"); ?> Owen Deutsch
						Photography<br><?php echo get_field('copyright_text', 'option'); ?>
					</p>
				</div>
			</div>
		</div>
	</div>
</footer>

<div class="header-menu-responsive">
	<a href="javascript:Void(0)" class="menu-close-btn">
		<img src="<?php echo $HOME_URL; ?>/wp-content/uploads/2019/04/close-btn.png" alt="close btn">
	</a>
	<div class="header-menu-inner">
		<div class="menu-container">
			<?php wp_nav_menu(array('theme_location' => 'main-menu', 'container' => 'false')); ?>
		</div>
	</div>
</div>
</div>
</main>

</div>




<?php wp_footer(); ?>
<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.validate.min.js"></script>
<script type="text/javascript">
	var site_url = "<?php echo site_url(); ?>";
	var search_page = "<?php echo get_permalink(796); ?>";
	var admin_url = "<?php echo bloginfo('url'); ?>/wp-admin/admin-ajax.php";
	jQuery(document).ready(function($) {

		$("#newsletterform").validate({
			rules: {
				newslettermail: {
					required: true,
					email: true
				}
			},
			messages: {
				newslettermail: "Please enter a valid email address",
			},
			highlight: function(element) {
				$(element)
					.closest('.control-group').addClass('error');
			}
		});

		$('#newsletter_btn').click(function(e) {
			e.preventDefault();
			var UserEmail = $('#newslettermail').val();
			if ($("#newsletterform").valid()) {
				/*Show loader here*/
				$("#sloading").show();
				// $('#newsletterresult').hide();
				$.ajax({
					type: "POST",
					dataType: "json",
					url: admin_url,
					data: {
						action: 'register_email',
						useremail: UserEmail,
					},
					beforeSubmit: function() {


					},
					success: function(data) {
						console.log(data);
						if (data.status === "success") {
							//$(".load-more-section").hide();
							//console.log(data.message);
							$('#newsletterresult').html(data.message);
							$('#newsletterresult').fadeIn('slow', function() {
								$('#newsletterresult').delay(5000).fadeOut();
							});
							$("#newsletterform")[0].reset();
						} else {
							$('#failmessage').html(data.message);
							$('#failmessage').fadeIn('slow', function() {
								$('#failmessage').delay(5000).fadeOut();
							});
						}

					},
					complete: function() {
						/*Hide the loader over here*/
						$('#sloading').hide();
					}
				});
			}

		});

		$('#newslettermail').keypress(function(e) {
			if (e.which == 13) { //Enter key pressed
				e.preventDefault();
				$('#newsletter_btn').click(); //Trigger search button click event
			}
		});

	});
</script>
</body>

</html>