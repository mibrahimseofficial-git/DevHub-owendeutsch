<?php
	get_header();
		get_template_part( 'templates/loop', 'content' );
	get_footer();
?>