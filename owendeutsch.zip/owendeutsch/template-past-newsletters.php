<?php
/*
Template Name: Past Newsletters
*/
get_header();
?>

<style>
/*
  Past Newsletters Popup Gate (STEP 2)
  - Overlay is dark/blackish
  - All text is in English
*/
.past-newsletters-page {
    padding-bottom: 60px;
}

.past-newsletters-page h1 {
  font-size: 40px;
  line-height: 1;
}

@media only screen and (max-width: 667px) {
  .past-newsletters-page h1 {
    font-size: 30px;
  }
}

/* Full screen overlay */
.pn-overlay{
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.97); /* more blackish */
  display: none;
  align-items: center;
  justify-content: center;
  z-index: 99999;
  padding: 20px;
}

/* Popup box */
.pn-popup{
  width: 100%;
  max-width: 520px;
  background: #fff;
  border-radius: 14px;
  padding: 28px;
  box-shadow: 0 15px 40px rgba(0,0,0,0.35);
}

.pn-popup h2{
  margin: 0 0 0;
  font-size: 22px;
  color: #000000;
  padding-bottom: 5px;
}

.pn-popup p{
  margin: 0 0 18px;
  line-height: 1.5;
  color: #444;
}

/* Form layout */
.pn-form{
  display: flex;
  gap: 10px;
  flex-wrap: wrap;
}

.pn-form input{
  flex: 1;
  min-width: 200px;
  padding: 12px 14px;
  border: 1px solid #ddd;
  border-radius: 10px;
  outline: none;
}

.pn-form button{
  height: fit-content;
  padding: 12px 16px;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  background: #111;
  color: #fff;
}

.pn-msg{
  margin-top: 12px;
  font-size: 14px;
}

.pn-error{ color: #b00020; }
.pn-success{ color: #0a7a2f; }

/* Popup image wrapper */
.pn-popup-image{
  width: 100%;
  display: flex;
  justify-content: center;
  margin-bottom: 16px;
}

.pn-popup-image img{
  max-width: 180px;
  width: 100%;
  height: auto;
  display: block;
  border-radius: 12px;
}

/* ACF popup text styling */
.pn-popup-text{
  margin: 0 0 18px;
  line-height: 1.5;
  color: #444;
}

.pn-popup-text p{
  margin: 0 0 12px;
}

/* New Css for post card  */
  /* Newsletter grid layout */
.pn-grid{
  margin-top: 35px;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 35px;
}

@media only screen and (max-width: 991px){
  .pn-grid{
    grid-template-columns: repeat(2, 1fr);
  }
}

@media only screen and (max-width: 600px){
  .pn-grid{
    grid-template-columns: 1fr;
  }
}

/* Card */
  .pn-card{
    text-decoration: none;
    color: inherit;
    display: block;
  }

  .pn-thumb{
    width: 100%;
    aspect-ratio: 1 / 1;
    overflow: hidden;
    background: #111;
  }

  .pn-thumb img{
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    transition: transform 0.25s ease;
  }

  .pn-card:hover .pn-thumb img{
    transform: scale(1.03);
  }

  .pn-meta{
    padding-top: 12px;
  }

  .pn-title{
    margin: 0 0 0;
    font-size: 16px;
    font-weight: 600;
    line-height: 1.4;
    color: #fff;
    padding-bottom: 5px;
  }

  .pn-author{
    font-size: 13px;
    color: rgba(255,255,255,0.75);
  }

  /* Pagination */
  .pn-pagination{
    grid-column: 1 / -1;
    margin-top: 10px;
  }

  .pn-pagination .page-numbers{
    display: inline-block;
    padding: 8px 12px;
    margin-right: 6px;
    background: #222;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
  }

  .pn-pagination .page-numbers.current{
    background: #fff;
    color: #000;
  }


</style>

<?php
$is_admin_user = ( is_user_logged_in() && current_user_can('administrator') );
?>

<?php if( ! $is_admin_user ): ?>

<?php
  // ACF Fields
  $popup_image = get_field('popup_image'); // image (array or url)
  $popup_heading = get_field('popup_heading'); // image (array or url)
  $popup_text  = get_field('popup_text');  // text/textarea
?>

<!-- POPUP OVERLAY -->
<div class="pn-overlay" id="pnOverlay">
  <div class="pn-popup">

    <?php if($popup_image): ?>
      <div class="pn-popup-image">
        <?php
          // If ACF returns array
          if(is_array($popup_image) && !empty($popup_image['url'])){
            echo '<img src="'.esc_url($popup_image['url']).'" alt="'.esc_attr($popup_image['alt'] ?? 'Popup Image').'">';
          }
          // If ACF returns url string
          else{
            echo '<img src="'.esc_url($popup_image).'" alt="Popup Image">';
          }
        ?>
      </div>
    <?php endif; ?>

    <?php if(!empty($popup_heading)): ?>
    <h2><?php echo $popup_heading; ?></h2>
    <?php endif; ?>

    <!-- Popup text from ACF -->
    <?php if(!empty($popup_text)): ?>
      <div class="pn-popup-text">
        <?php echo wpautop(wp_kses_post($popup_text)); ?>
      </div>
    <?php else: ?>
      <p>
        Please enter your email address to access this page.
        You won’t be asked again for the next 30 days.
      </p>
    <?php endif; ?>

    <!-- Email form -->
    <form class="pn-form" id="pnForm">
      <input type="email" id="pnEmail" placeholder="Enter your email" required>
      <button type="submit">Continue</button>
    </form>

    <!-- Message area -->
    <div class="pn-msg" id="pnMsg"></div>

  </div>
</div>

<?php endif; ?>

<!-- PAGE CONTENT -->
<div class="past-newsletters-page container inner-page-outer">
  <h1><?php echo esc_html( get_the_title() ); ?></h1>

  <?php
  while ( have_posts() ) : the_post();
    the_content();
  endwhile;
  ?>
</div>

<script>
jQuery(document).ready(function($){

  let pnNonce = "";

  var isAdminUser = <?php echo $is_admin_user ? 'true' : 'false'; ?>;
  if(isAdminUser){
    return;
  }

  function pnGetCookie(name){
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
  }

  function pnSetCookie(name, value, days){
    let expires = "";
    if(days){
      const date = new Date();
      date.setTime(date.getTime() + (days*24*60*60*1000));
      expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + value + expires + "; path=/";
  }

  // Function: Get fresh nonce
  function pnFetchNonce(callback){
    $.ajax({
      url: "<?php echo admin_url('admin-ajax.php'); ?>",
      type: "POST",
      dataType: "json",
      data: { action: "pn_get_nonce" },
      success: function(res){
        if(res.success && res.data.nonce){
          pnNonce = res.data.nonce;
          if(typeof callback === "function") callback(true);
        } else {
          if(typeof callback === "function") callback(false);
        }
      },
      error: function(){
        if(typeof callback === "function") callback(false);
      }
    });
  }

  // Show popup if no cookie
  const hasAccess = pnGetCookie("pn_access");
  if(!hasAccess){
    $("#pnOverlay").css("display","flex");
    $("body").css("overflow","hidden");

    // fetch nonce on popup open
    pnFetchNonce();
  }

  // Submit email
  $("#pnForm").on("submit", function(e){
    e.preventDefault();

    let email = $("#pnEmail").val().trim();
    $("#pnMsg").html("");

    if(email === ""){
      $("#pnMsg").html("<span class='pn-error'>Please enter your email.</span>");
      return;
    }

    // If nonce not loaded yet, fetch then submit
    if(!pnNonce){
      $("#pnMsg").html("Loading session...");
      pnFetchNonce(function(ok){
        if(!ok){
          $("#pnMsg").html("<span class='pn-error'>Session error. Please refresh and try again.</span>");
          return;
        }
        $("#pnForm").trigger("submit");
      });
      return;
    }

    $("#pnMsg").html("Saving...");

    $.ajax({
      url: "<?php echo admin_url('admin-ajax.php'); ?>",
      type: "POST",
      dataType: "json",
      data: {
        action: "pn_save_email",
        email: email,
        nonce: pnNonce
      },
      success: function(res){
        if(res.success){

          pnSetCookie("pn_access", "1", 30);

          $("#pnMsg").html("<span class='pn-success'>Access granted. Loading...</span>");

          setTimeout(function(){
            $("#pnOverlay").fadeOut(200);
            $("body").css("overflow","auto");
          }, 700);

        } else {
          $("#pnMsg").html("<span class='pn-error'>" + res.data.message + "</span>");
        }
      },
      error: function(){
        $("#pnMsg").html("<span class='pn-error'>Something went wrong. Please try again.</span>");
      }
    });

  });

});
</script>

<?php get_footer(); ?>
