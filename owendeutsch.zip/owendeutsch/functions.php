<?php

/*

 *   Theme Function File.

 *   All The Function are included

 */



/*  ---------------------------------------------------------------------

        Set Content Width.
    --------------------------------------------------------------------- */


if( !isset( $content_width ) ) {

    $content_width = 1000;

}



/*  ---------------------------------------------------------------------

        Set Up the Basic and Necessary Theme Function. 

    --------------------------------------------------------------------- */




function theme_setup() {



    // Remove Defualt Gallery 

    add_filter( 'use_default_gallery_style', '__return_false' );

    

    // Adds RSS feed links to <head> for posts and comments.

    add_theme_support( 'automatic-feed-links' );



    // Register post Thumbnail

    if( function_exists( 'add_theme_support' ) ) {

        add_theme_support( 'post-thumbnails' );

        add_theme_support( 'custom-background' );

        add_theme_support( 'title-tag' );
                
        add_image_size( 'square-medium', 337, 337, false); // name, width, height, crop 
        
        add_image_size( 'square-medium-crop', 350, 350, true); // name, width, height, crop 
        add_image_size( 'contury-large', 500, 500, false); // name, width, height, crop 

    }

    

    // Register Nav Menu

    register_nav_menus(

        array(

          'main-menu'   => 'Main Menu',

          'footer-menu' => 'Footer Menu'

        )

    );
    

}

add_action( 'after_setup_theme', 'theme_setup' );


add_action('admin_notices', function() {
    $taxonomies = get_taxonomies([], 'objects');
    
    echo '<div class="notice notice-info"><p><strong>Available Taxonomies:</strong></p><ul>';
    
    foreach ($taxonomies as $taxonomy) {
        echo '<li>' . esc_html($taxonomy->name) . ' - ' . esc_html($taxonomy->label) . '</li>';
    }
    
    echo '</ul></div>';
});


/*  ---------------------------------------------------------------------

        Include All Stylesheets and Jquery Files

    --------------------------------------------------------------------- */

function theme_name_scripts() {

    

    wp_enqueue_style( 'components' , get_template_directory_uri() . '/css/component.css', array(), '1.0' );

    wp_enqueue_style( 'bootstrap.min' , get_template_directory_uri() . '/css/bootstrap.min.css', array(), '1.0' );

    wp_enqueue_style( 'fancybox' , get_template_directory_uri() . '/css/fancybox-min.css', array(), '1.0' );

    wp_enqueue_style( 'style-fonts'   , get_template_directory_uri() . '/fonts/fonts.css', array(), '1.0' );
        
    wp_enqueue_style( 'jquery-ui'         , get_template_directory_uri() . '/css/jquery-ui.css', array(), '1.0' );

    wp_enqueue_style( 'owl-carousal-min'    , get_template_directory_uri() . '/css/owl.carousel.min.css', array(), '1.0' );

    wp_enqueue_style( 'owl-carousal-theme'    , get_template_directory_uri() . '/css/owl.theme.default.min.css', array(), '1.0' );

    wp_enqueue_style( 'style'         , get_stylesheet_uri(), array(), '1.6' );

    wp_enqueue_style( 'responsive' , get_template_directory_uri() . '/css/responsive.css', array(), '1.0' );
    
    wp_enqueue_script( 'jquery-ui-js'   , get_template_directory_uri() . '/js/jquery-ui.js', array() ,'1.12.1' ,true );

    wp_enqueue_script( 'bootstrap.min'   , get_template_directory_uri() . '/js/bootstrap.min.js', array() ,'3.3.2' ,true );

    wp_enqueue_script( 'fancybox-js'          , get_template_directory_uri() . '/js/fancybox-min.js', array(), '1.0', true );

    wp_enqueue_script( 'image-loaded'          , get_template_directory_uri() . '/js/imagesloaded.pkgd.min.js', array(), '1.0', true );

    wp_enqueue_script( 'anime'          , get_template_directory_uri() . '/js/anime.min.js', array(), '1.0', true );

    wp_enqueue_script( 'main'          , get_template_directory_uri() . '/js/main.js', array(), '1.0', true );

    wp_enqueue_script( 'owl-carousal'          , get_template_directory_uri() . '/js/owl.carousel.js', array(), '1.0', true );

    // if ( is_page(15558) || is_page(12)  ) {
        // wp_enqueue_script( 'd3-1'          , "https://d3js.org/d3.v3.min.js");
        wp_enqueue_script( 'd3-2'          , "https://d3js.org/topojson.v1.min.js");
        wp_enqueue_script( 'd3-3'          , "https://d3js.org/queue.v1.min.js");

    //     wp_script_add_data( 'd3-1', 'async/defer' , true );
        wp_script_add_data( 'jquery-ui-js', 'async/defer' , true );
    // }
    // wp_script_add_data( 'jquery-ui-js', 'async/defer' , true );
    if( is_page(796) || is_search() ){
        //wp_enqueue_style( 'searcg-page-css'    , get_template_directory_uri() . '/css/search-page-css.css', array(), NULL );
        // wp_enqueue_script( 'hilitor', get_template_directory_uri().'/js/hilitor.js', array(), NULL, true );
        // wp_enqueue_script( 'hilitor-custom', get_template_directory_uri().'/js/hilitor-custom.js', array(), NULL, true );
        wp_enqueue_script( 'lazy', get_template_directory_uri().'/js/jquery.lazy.min.js', array(), NULL, true );
    }
    // wp_enqueue_script('google-recaptcha', 'https://www.google.com/recaptcha/api.js');

    // if(!is_page('test')){
        wp_enqueue_script( 'custom', get_template_directory_uri() . '/js/custom.js', array(), NULL, true );
    // }

        wp_localize_script( 'custom', 'OWNBIRD', array(

            'ajaxurl' => admin_url( 'admin-ajax.php', ( is_ssl() ? 'https' : 'http' ) ),

            'url' => get_site_url(),

            )

        );
///     //if it is entry page
    if (is_page(11264)) {
            wp_enqueue_script(
                'jquery-validate',
                'https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js',
                array('jquery'),
                '1.19.3',
                true
            );
        }    
    ///
    if( is_page(13433) ){

        wp_dequeue_style( 'jquery-ui');
        wp_dequeue_style( 'sbi_styles');
        wp_dequeue_style( 'iscwp-public-css');
        wp_dequeue_style( 'wpos-magnific-style');
        wp_dequeue_style( 'fancybox');
        wp_dequeue_style( 'owl-carousal-min');
        wp_dequeue_style( 'owl-carousal-theme');
    }
    if ( is_page(5) ) {
        wp_dequeue_style( 'yith-infs-style');
        wp_dequeue_style( 'owl-carousal-theme');
        wp_dequeue_style( 'wpos-slick-style');
        wp_dequeue_style( 'contact-form-7');
        wp_dequeue_style( 'owl-carousal-min');
        wp_dequeue_style( 'wpos-magnific-style');
        wp_dequeue_style( 'fancybox');
        wp_dequeue_style('iscwp-public-css');
    }
    
    
}

add_action( 'wp_enqueue_scripts', 'theme_name_scripts' );




// if ( isset($_GET['hello']) ) {
//     $body_classes = get_body_class();
//     print_r($body_classes);
// }




function defer_parsing_of_js( $url ) {
    if ( is_user_logged_in() ) return $url; //don't break WP Admin
    if ( FALSE === strpos( $url, '.js' ) ) return $url;
    if ( strpos( $url, 'jquery.js' ) ) return $url;
    return str_replace( ' src', ' defer src', $url );
}
add_filter( 'script_loader_tag', 'defer_parsing_of_js', 10 );



if( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {

    wp_enqueue_script( 'comment-reply' );

}



/*  ---------------------------------------------------------------------

        Register Sidebar to Customize the Widgets

    --------------------------------------------------------------------- */

if( function_exists( 'register_sidebar' ) ) {

    register_sidebar( array(

        'name'          => 'Sidebar',

        'id'            => 'sidebar',

        'before_title'  => '<h3>',

        'after_title'   => '</h3>',

        'before_widget' => '<div class="widget %2$s" id="%1$s">',

        'after_widget'  => '</div>'

    ) );

}



/*  ---------------------------------------------------------------------

        Hook For the Excerpt

    --------------------------------------------------------------------- */

function new_excerpt_length() {

    return 40;

}

add_filter( 'excerpt_length', 'new_excerpt_length' );



function new_excerpt_more() {

    return '';

}

add_filter( 'excerpt_more', 'new_excerpt_more' );

function admin_excerpt() {

    echo "<style>"; 

    echo "textarea#excerpt { height:120px; }"; 

    echo "</style>"; 

}

add_action('admin_head', 'admin_excerpt');



function my_acf_admin_head() {

?>

    <style type="text/css">

        .acf_postbox .field textarea { min-height: inherit; }

    </style>

<?php

}

add_action('acf/input/admin_head', 'my_acf_admin_head');
/**
 * Register Custom Post Types
 */
function birds_register_post_types() {
    /*Bird Post Type*/
    $bird_labels = array(
                            'name'               => _x( 'Birds', 'owen_bird', 'owen' ),
                            'singular_name'      => _x( 'Bird', 'owen_bird', 'owen' ),
                            'menu_name'          => _x( 'Birds', 'owen_bird', 'owen' ),
                            'name_admin_bar'     => _x( 'Birds', 'owen_bird', 'owen' ),
                            'add_new'            => _x( 'Add New', 'owen_bird', 'owen' ),
                            'add_new_item'       => __( 'Add New Bird', 'owen' ),
                            'new_item'           => __( 'New Bird', 'owen' ),
                            'edit_item'          => __( 'Edit Bird', 'owen' ),
                            'view_item'          => __( 'View Bird', 'owen' ),
                            'all_items'          => __( 'All Birds', 'owen' ),
                            'search_items'       => __( 'Search Bird', 'owen' ),
                            'parent_item_colon'  => __( 'Parent Bird:', 'owen' ),
                            'not_found'          => __( 'No birds found.', 'owen' ),
                            'not_found_in_trash' => __( 'No birds found in Trash.', 'owen' ),
                        );
    $bird_args = array(
                            'labels'             => $bird_labels,
                            'public'             => true,
                            'publicly_queryable' => true,
                            'show_ui'            => true,
                            'show_in_menu'       => true,
                            'query_var'          => true,
                            'rewrite'            => array( 'slug'=> 'cp_birds', 'with_front' => false ),
                            'capability_type'    => 'post',
                            'has_archive'        => false,
                            'hierarchical'       => true,
                            'menu_position'      => null,
                            'menu_icon'          => 'dashicons-images-alt2',
                            'supports'           => array( 'title', 'thumbnail','excerpt','editor','author', 'page-attributes' ),
			                'show_in_rest'       => true,
                            
                        );
    register_post_type( 'cp_birds', $bird_args );
    // Add new birds, make it hierarchical (like categories)
    $labels = array(
                    'name'              => _x( 'Categories', 'taxonomy general name', 'owen'),
                    'singular_name'     => _x( 'Category', 'taxonomy singular name','owen' ),
                    'search_items'      => __( 'Search Categories','owen' ),
                    'all_items'         => __( 'All Categories','owen' ),
                    'parent_item'       => __( 'Parent Category','owen' ),
                    'parent_item_colon' => __( 'Parent Category:','owen' ),
                    'edit_item'         => __( 'Edit Category' ,'owen'), 
                    'update_item'       => __( 'Update Category' ,'owen'),
                    'add_new_item'      => __( 'Add New Category' ,'owen'),
                    'new_item_name'     => __( 'New Category Name' ,'owen'),
                    'menu_name'         => __( 'Category' ,'owen')
                );
    $args = array(
                    'hierarchical'      => true,
                    'labels'            => $labels,
                    'show_ui'           => true,
                    'show_admin_column' => true,
                    'query_var'         => true,
                    'rewrite'           => array( 'slug'=> 'cp_birds_taxonomy' )
                );
    //register_taxonomy( 'cp_birds_taxonomy', 'cp_birds', $args );
    // Add new species, make it hierarchical (like categories)
    $species_labels = array(
                    'name'              => _x( 'Species', 'taxonomy general name', 'owen'),
                    'singular_name'     => _x( 'Species', 'taxonomy singular name','owen' ),
                    'search_items'      => __( 'Search Species','owen' ),
                    'all_items'         => __( 'All Species','owen' ),
                    'parent_item'       => __( 'Parent Species','owen' ),
                    'parent_item_colon' => __( 'Parent Species:','owen' ),
                    'edit_item'         => __( 'Edit Species' ,'owen'), 
                    'update_item'       => __( 'Update Species' ,'owen'),
                    'add_new_item'      => __( 'Add New Species' ,'owen'),
                    'new_item_name'     => __( 'New Species Name' ,'owen'),
                    'menu_name'         => __( 'Species' ,'owen')
                );
    $species_args = array(
                    'hierarchical'      => true,
                    'labels'            => $species_labels,
                    'show_ui'           => true,
                    'show_admin_column' => true,
                    'query_var'         => true,
                    'rewrite'           => array( 'slug'=> 'cp_birds_color' )
                );
    //register_taxonomy( 'cp_birds_species', 'cp_birds', $species_args );
     // Add new country, make it hierarchical (like categories)
    $cn_labels = array(
                    'name'              => _x( 'Countries', 'taxonomy general name', 'owen'),
                    'singular_name'     => _x( 'Country', 'taxonomy singular name','owen' ),
                    'search_items'      => __( 'Search Country','owen' ),
                    'all_items'         => __( 'All Country','owen' ),
                    'parent_item'       => __( 'Parent Country','owen' ),
                    'parent_item_colon' => __( 'Parent Country:','owen' ),
                    'edit_item'         => __( 'Edit Country' ,'owen'), 
                    'update_item'       => __( 'Update Country' ,'owen'),
                    'add_new_item'      => __( 'Add New Country' ,'owen'),
                    'new_item_name'     => __( 'New Country Name' ,'owen'),
                    'menu_name'         => __( 'Country' ,'owen')
                );
    $cn_args = array(
                    'hierarchical'      => true,
                    'labels'            => $cn_labels,
                    'show_ui'           => true,
                    'show_admin_column' => true,
                    'show_in_rest'      => true,
                    'query_var'         => true,
                    'rewrite'           => array( 'slug'=> 'cp_birds_country' ),
                    'capabilities'      => array(
                        'manage_terms' => 'manage_categories',
                        'edit_terms'   => 'manage_categories',
                        'delete_terms' => 'manage_categories',
                        'assign_terms' => 'edit_posts',
                    ),
                    
                );
    register_taxonomy( 'cp_birds_country', 'cp_birds', $cn_args );

    // add_action('admin_menu', function() {
    //     add_submenu_page(
    //         'edit.php', // Parent menu (Posts)
    //         'Bird Country', // Page title
    //         'Bird Country', // Menu title
    //         'manage_options', // Capability
    //         'edit-tags.php?taxonomy=cp_birds_country', // Menu slug
    //         '' // Callback function (not needed)
    //     );
    // });

    // add_action('add_meta_boxes', function() {
    //     remove_meta_box('cp_birds_countrydiv', 'post', 'side'); // Remove default placement
    //     add_meta_box('cp_birds_countrydiv', 'Bird Country', 'post_categories_meta_box', 'post', 'side', 'low');
    // });

    // Add new tags, make it hierarchical (like default tags)
    $tags_labels = array(
                    'name'              => _x( 'Tags', 'taxonomy general name', 'owen'),
                    'singular_name'     => _x( 'Tag', 'taxonomy singular name','owen' ),
                    'search_items'      => __( 'Search Tag','owen' ),
                    'all_items'         => __( 'All Tag','owen' ),
                    'parent_item'       => __( 'Parent Tag','owen' ),
                    'parent_item_colon' => __( 'Parent Tag:','owen' ),
                    'edit_item'         => __( 'Edit Tag' ,'owen'), 
                    'update_item'       => __( 'Update Tag' ,'owen'),
                    'add_new_item'      => __( 'Add New Tag' ,'owen'),
                    'new_item_name'     => __( 'New Tag Name' ,'owen'),
                    'menu_name'         => __( 'Tags' ,'owen')
                );
    $tags_args = array(
    		   'hierarchical'      => false,
    		   'labels'            => $tags_labels,
    		   'show_ui'           => true,
    	  	   'show_admin_column' => true,
    		   'query_var'         => true,
    		   'rewrite'           => array( 'slug' => 'cp_birds_tag' ),
    		   'show_in_nav_menus' => true,
    		   'show_tagcloud'     => true,
    		   'show_in_rest'      => true, 
		);
register_taxonomy( 'cp_birds_tag', 'cp_birds', $tags_args );
}
//add action to create custom post type
add_action( 'init', 'birds_register_post_types', 12);

add_action( 'init', function () {
    global $wp_taxonomies;

    if ( isset( $wp_taxonomies['cp_birds_tag'] ) ) {
        $wp_taxonomies['cp_birds_tag']->show_in_rest = true;
    }
}, 20 );

/* Lodges Custom Post Type */
function custom_post_type_lodges() {
 
// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'Lodges', 'Post Type General Name', 'owen' ),
        'singular_name'       => _x( 'Lodges', 'Post Type Singular Name', 'owen' ),
        'menu_name'           => __( 'Lodges', 'owen' ),
        'parent_item_colon'   => __( 'Parent Lodges', 'owen' ),
        'all_items'           => __( 'All Lodges', 'owen' ),
        'view_item'           => __( 'View Lodges', 'owen' ),
        'add_new_item'        => __( 'Add New Lodges', 'owen' ),
        'add_new'             => __( 'Add New', 'owen' ),
        'edit_item'           => __( 'Edit Lodges', 'owen' ),
        'update_item'         => __( 'Update Lodges', 'owen' ),
        'search_items'        => __( 'Search Lodges', 'owen' ),
        'not_found'           => __( 'Not Found', 'owen' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'owen' ),
    );
     
// Set other options for Custom Post Type
     
    $args = array(
        'label'               => __( 'lodges', 'owen' ),
        'description'         => __( 'Birds Sites and Lodges ', 'owen' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        // You can associate this CPT with a taxonomy or custom taxonomy. 
        'taxonomies'          => array( '' ),
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */ 
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'show_in_rest' => true,
 
    );
    $cn_labels = array(
                    'name'              => _x( 'Countries', 'taxonomy general name', 'owen'),
                    'singular_name'     => _x( 'Country', 'taxonomy singular name','owen' ),
                    'search_items'      => __( 'Search Country','owen' ),
                    'all_items'         => __( 'All Country','owen' ),
                    'parent_item'       => __( 'Parent Country','owen' ),
                    'parent_item_colon' => __( 'Parent Country:','owen' ),
                    'edit_item'         => __( 'Edit Country' ,'owen'), 
                    'update_item'       => __( 'Update Country' ,'owen'),
                    'add_new_item'      => __( 'Add New Country' ,'owen'),
                    'new_item_name'     => __( 'New Country Name' ,'owen'),
                    'menu_name'         => __( 'Lodge Country' ,'owen')
                );
    $cn_args = array(
                    'hierarchical'      => true,
                    'labels'            => $cn_labels,
                    'show_ui'           => true,
                    'show_admin_column' => true,
                    'show_in_rest'      => true, // Needed for tax to appear in Gutenberg editor.
                    'query_var'         => true,
                    'rewrite'           => array( 'slug'=> 'cp_birds_country' )
                );
    register_taxonomy( 'lodges_country', 'lodges', $cn_args ); 
    
    // Registering your Custom Post Type
    register_post_type( 'lodges', $args );
 
}
 
/* Hook into the 'init' action so that the function
* Containing our post type registration is not 
* unnecessarily executed. 
*/
 
add_action( 'init', 'custom_post_type_lodges', 0 );
/*Allow shortcode in Text Widget*/
add_filter('widget_text', 'do_shortcode');

if( function_exists('acf_add_options_page') ) {
    acf_add_options_page(array(
        'page_title'    => 'Theme General Settings',
        'menu_title'    => 'Theme Settings',
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
    acf_add_options_sub_page(array(
        'page_title'    => 'Theme Header Settings',
        'menu_title'    => 'Header',
        'parent_slug'   => 'theme-general-settings',
    ));
    acf_add_options_sub_page(array(
        'page_title'    => 'Theme Footer Settings',
        'menu_title'    => 'Footer',
        'parent_slug'   => 'theme-general-settings',
    ));
}
function update_map_status_save_post( $post_id ) {
    global $wpdb;
    $terms          = get_the_terms( $post_id , 'cp_birds_country' );
    $get_tax_list   = wp_get_post_terms( $post_id, 'cp_birds_country' );
    $term_id        = $get_tax_list[0]->term_id;
    $set_tav_slug   = strtoupper($get_tax_list[0]->slug);
    $term_link      = get_term_link( $set_tav_slug, 'cp_birds_country');
    $get_status     = "SELECT status FROM ".$wpdb->prefix."mapsvg_regions_486 WHERE id = '$set_tav_slug'";
    $myrows         = $wpdb->get_results( $get_status );
    $tx_prv_date_meta   = get_term_meta( $term_id, 'country_schedule_date');
    $tx_prv_date_value  = $tx_prv_date_meta[0];
    $tx_selected_date   = date('Y-m',strtotime(get_field('country_schedule_date', 'cp_birds_country' . '_' . $term_id )));
    $thumbnail    = get_field('country_image', 'cp_birds_country' . '_' . $term_id);
    if( !empty( $tx_prv_date_value ) && !empty( $thumbnail )) {
        $today_date     = date('Y-m');
        if ( strtotime($tx_selected_date) <= strtotime($today_date) ){
            if ( $myrows[0]->status == '0' ){
                $wpdb->update( 
                    $wpdb->prefix.'mapsvg_regions_486', 
                    array( 
                        'status'        => '1', // string
                        'status_text'   => 'Enabled',
                        'external_link' => $term_link,
                    ), 
                    array( 'id' => $set_tav_slug )
                );
            }
        }
    }   
}
//add_action( 'save_post_cp_birds', 'update_map_status_save_post', 10, 2 );
//add_action( 'pre_post_update', 'pre_update_birds_posts', 10, 1);
function pre_update_birds_posts($post_id) {
    global $wpdb;
    $term_list      = wp_get_post_terms( $post_id, 'cp_birds_country' );
    $term_id        = $term_list[0]->term_id;
    $term_slug      = strtoupper($term_list[0]->slug);
    $term_link      = get_term_link( $term_slug, 'cp_birds_country');
    $get_pre_status = "SELECT status FROM ".$wpdb->prefix."mapsvg_regions_486 WHERE id = '$term_slug'";
    $get_pre_results= $wpdb->get_results( $get_pre_status );
    $post_meta      = get_the_terms( $post_id , 'cp_birds_country' );
    $selected_region_colorcode  = get_field( 'birds_country_selected_color', 'option' );
    $query      =   "SELECT fields
                    FROM wp_mapsvg_schema
                    WHERE table_name = 'wp_mapsvg_regions_486'  ";
    $snglQuery  =   $wpdb->get_results($query);
    $allfieldscolor = $snglQuery[0];
    // echo '<pre>';
    // print_r( $allfieldscolor );
    // echo '</pre>';
    // die;
    $json = ( json_decode($allfieldscolor->fields,true)) ;
    foreach ( $json[0]['optionsDict'] as $key => $value) {
        if( $key == 0 ){
            $json[0]['optionsDict'][0]['color'] = '#3b3a3f';
        } elseif ($key == 1 ) {
            $json[0]['optionsDict'][1]['color'] = $selected_region_colorcode;
        }
    }
    $searlize_string = json_encode( $json );
    $wpdb->update( 
        'wp_mapsvg_schema', 
        array( 
            'fields' => $searlize_string,
        ), 
        array( 'table_name' => 'wp_mapsvg_regions_486' )
    );
    $tx_prv_date_meta   = get_term_meta( $term_id, 'country_schedule_date');
    $tx_prv_date_value  = $tx_prv_date_meta[0];
    $tx_selected_date   = date('Y-m',strtotime(get_field('country_schedule_date', 'cp_birds_country' . '_' . $term_id )));
    $thumbnail    = get_field('country_image', 'cp_birds_country' . '_' . $term_id);
    if( !empty( $tx_prv_date_value ) && !empty( $thumbnail )) {
        $today_date     = date('Y-m');
        // testing
        if ( ( strtotime($tx_selected_date) <= strtotime($today_date) ) && !empty( $thumbnail ) ){
            if( !empty( $post_meta ) ){
                if( $get_pre_results[0]->status == '0'){
                    $wpdb->update( 
                        $wpdb->prefix.'mapsvg_regions_486', 
                        array( 
                            'status'        => '1', // string
                            'status_text'   => 'Enabled',
                            'external_link' => $term_link,
                        ), 
                        array( 'id' => $term_slug )
                    );
                }
            }
            $posts_array = get_posts(
                    array(
                        'post__not_in' => array($post_id),
                        'posts_per_page' => -1,
                        'post_type' => 'cp_birds',
                        'tax_query' => array(
                            array(
                                'taxonomy' => 'cp_birds_country',
                                'field' => 'term_id',
                                'terms' => $term_id,
                            )
                        )
                    )
            );
            if( !empty( $posts_array ) ){
                $wpdb->update( 
                    'wp_mapsvg_regions_486', 
                    array( 
                                'status' => '1',    // string
                                'status_text'   => 'Enabled',
                                'external_link' => $term_link,
                            ), 
                    array( 'id' => $term_slug )
                );
            }
            else
            {
                $wpdb->update( 
                    'wp_mapsvg_regions_486', 
                    array( 
                                'status'        => '0', // string
                                'status_text'   => 'Disabled',
                                'external_link' => NULL,
                            ), 
                    array( 'id' => $term_slug )
                );
            }
        }
    }
}
function update_country_terms($term_id, $tt_id, $taxonomy) {
    global $wpdb;
    $term = get_term($term_id, $taxonomy);
    $term_slug = strtoupper($term->slug);
    $term_link          = get_term_link( $term_slug, 'cp_birds_country');
    $tx_prv_date_meta   = get_term_meta( $term_id, 'country_schedule_date');
    if(!empty($tx_prv_date_meta)) {
         $tx_prv_date_value     = $tx_prv_date_meta[0];
    }
    else {
        $tx_prv_date_value = '';
    }
    $tx_selected_date   = date('Y-m',strtotime(get_field('country_schedule_date', 'cp_birds_country' . '_' . $term_id )));
    $thumbnail    = get_field('country_image', 'cp_birds_country' . '_' . $term_id);
    if( !empty( $tx_prv_date_value ) && !empty( $thumbnail ) ) {
            $today_date     = date('Y-m');
            if ( ( strtotime($tx_selected_date) <= strtotime($today_date) ) && !empty( $thumbnail ) ){
                if ( $term->count > 0 ){
                    $wpdb->update( 
                        $wpdb->prefix.'mapsvg_regions_486', 
                        array( 
                                    'status' => '1',    // string
                                    'status_text'   => 'Enabled',
                                    'external_link' => $term_link,
                                ), 
                        array( 'id' => $term_slug )
                    );
                }else{
                    $wpdb->update( 
                        $wpdb->prefix.'mapsvg_regions_486', 
                        array( 
                                    'status' => '0',    // string
                                    'status_text'   => 'Disabled',
                                    'external_link' => NULL,
                                ), 
                        array( 'id' => $term_slug )
                    );
                }
            }else{
                $wpdb->update( 
                    'wp_mapsvg_regions_486',
                    array( 
                            'status' => '0',    // string
                            'status_text'   => 'Disabled',
                            'external_link' => NULL,
                        ), 
                    array( 'id' => $term_slug )
               );
            }
    }
    else
    {
        $wpdb->update( 
          $wpdb->prefix.'mapsvg_regions_486', 
          array( 
                'status' => '0',  // string
                'status_text' => 'Disabled',
                'external_link' => NULL,
              ), 
          array( 'id' => $term_slug )
        );
    }
}
//add_action( 'edit_term', 'update_country_terms', 10, 3 );
function load_custom_wp_admin_style() {
    /* Load our admin css.*/
    wp_register_style( 'owendeutsch_wp_admin_css', get_template_directory_uri() . '/css/admin-style.css', false, '1.0.0' );
    wp_enqueue_style( 'owendeutsch_wp_admin_css' );
    
    /* Load our admin script.*/
    wp_enqueue_script( 'owendeutsch-admin-script', get_template_directory_uri() . '/js/admin-script.js' );
}
add_action( 'admin_enqueue_scripts', 'load_custom_wp_admin_style' );
/**
 * Register rest button [country-grid-list] shortcode
 */
function country_gridview_callback($atts)
{
       ob_start();
       $_terms = get_terms( array('cp_birds_country') );
        ?>
        <div class="imglist row">
            <?php
                if ( !empty( ($_terms ) && !is_wp_error( ( $_terms ) ) ) ) { 
                        global $wpdb; 

                        foreach ($_terms as $term) :
                            
                            $term_slug_upper    = strtoupper($term->slug);
                            $term_permalink     = get_term_link($term->slug, 'cp_birds_country');
                            $thumbnail          = get_field('country_image', $term->taxonomy . '_' . $term->term_id);
                            $previous_date      = get_term_meta( $term->term_id, 'country_schedule_date');
                            $post_repeater      = get_field('post_schedule', $term->taxonomy . '_' . $term->term_id);
                            $current_date       = date('Y-m');
                            $current_month      = date('m');
                            $current_year       = date('Y');
                           
                            //pr($current_date);
                            
                            if(!empty($post_repeater)){ 
                                foreach ($post_repeater as $key=>$row) {
                                        $post_repeater[$key]['postdate'] = $row['postyear'].'-'.$row['postmonth']; 
                                }  /*Foreach loop*/
                                $post_fount =0;
                                foreach ($post_repeater as $key => $postrepeater) {  
                                    $current_date   = date('Y-m');
                                    if($post_fount == 0 && strtotime(date('Y-m',strtotime($postrepeater['postdate']))) <= strtotime($current_date) && !empty($postrepeater['display_post']))
                                    {
                                        /*pr($term_slug_upper);
                                        pr($postrepeater);*/
                                        ?>
                                        <figure class="col-md-2 on-hover">
                                                <?php 
                                                    $default_placeholder_image = get_template_directory_uri()."/images/placeholder-bird.png";
                                                    $thumbnail_full_src = !empty( $thumbnail ) ? $thumbnail['url'] : $default_placeholder_image;

                                                ?>
                                                <a href="<?php echo $term_permalink; ?>" target="_self">
                                                    <img class="img-fluid" src="<?php echo $thumbnail_full_src; ?>" />
                                                </a>
                                                <figcaption class="text-center">
                                                    <h6><?php echo $term->name; ?></h6>
                                                </figcaption>
                                            </figure>
                                        <?php
                                        //$post_fount =1;
                                        //foreach ($postrepeater['display_post'] as $key => $row) {


                                       // }*/
                                        break;
                                    }

                                }
                            }
                        endforeach; 
                }

            ?>
        </div>
        <?php   
    $html = ob_get_clean();
    return $html;
}
//add shortcode to display testimonial on  home page
//add_shortcode('country-grid-list', 'country_gridview_callback');


function hide_county_slug_box() {

        global $post;
        global $pagenow;
        if (is_admin() && $pagenow=='term.php' AND $_GET['taxonomy']=='cp_birds_country') {
        echo "<script type='text/javascript'>
        jQuery(document).ready(function($) {
          jQuery('tr.form-field.term-slug-wrap').hide();
        });
        </script>
        ";
          }
        }
add_action( 'admin_head', 'hide_county_slug_box' );


function odp_autocomplate() {
    $search = $_POST['q'];
    
    global $wpdb;
    
    $birds = $wpdb->get_results("SELECT post_title from wp_posts where post_title like '%$search%' and post_status = 'publish' and post_type = 'cp_birds'", OBJECT);
  
    $birds_taxonomy = $wpdb->get_results("SELECT  t.*, tt.* FROM wp_terms AS t  INNER JOIN wp_term_taxonomy AS tt ON t.term_id = tt.term_id "
            . "WHERE tt.taxonomy IN ('cp_birds_tag', 'cp_birds_country') AND t.name like '%$search%'", OBJECT);

    $activity_meta_query = $wpdb->get_results("SELECT DISTINCT(cs.meta_value) FROM wp_postmeta AS cs INNER JOIN wp_posts AS c ON c.ID = cs.post_id WHERE cs.meta_key LIKE 'bird_activity' AND cs.meta_value LIKE '%$search%' AND c.post_status = 'publish'", OBJECT);

    $bird_locations_meta_query = $wpdb->get_results("SELECT DISTINCT(cs.meta_value) FROM wp_postmeta AS cs INNER JOIN wp_posts AS c ON c.ID = cs.post_id WHERE cs.meta_key LIKE 'bird_locations' AND cs.meta_value LIKE '%$search%' AND c.post_status = 'publish'", OBJECT);
  
    $all_meta_query = $wpdb->get_results("SELECT DISTINCT(cs.meta_value) FROM wp_postmeta AS cs INNER JOIN wp_posts AS c ON c.ID = cs.post_id WHERE (cs.meta_key LIKE 'bird_visual_country' OR cs.meta_key LIKE 'bfamily' OR cs.meta_key LIKE 'bird_family' OR cs.meta_key LIKE 'bird_taxonomic_genus' OR cs.meta_key LIKE 'bird_scientific_name' OR cs.meta_key LIKE 'bird_conservancy' OR cs.meta_key LIKE 'bird_conservation_status' OR cs.meta_key LIKE 'bird_activity') AND cs.meta_value LIKE '%$search%' AND c.post_status = 'publish'", OBJECT);



    $data = array();
    
    if($birds) {
        foreach( $birds as $bird ) {
            array_push($data,ucwords($bird->post_title));
        }
    }
    
    if(!empty($birds_taxonomy)) {
        foreach($birds_taxonomy as $bird_taxonomy) {
            if( $bird_taxonomy->count > 0 ){
                array_push($data,ucwords($bird_taxonomy->name));
            }
        }
    }

    if(!empty($all_meta_query)) {
        foreach($all_meta_query as $all_row) {
            array_push($data,ucwords($all_row->meta_value));
        }
    }

    if(!empty($activity_meta_query)) {
        $allBirdactivity =array();
        foreach($activity_meta_query as $bird_activity){
            $activityArray = array();
            $activityArray = explode(",", $bird_activity->meta_value);
            foreach($activityArray as $activity_item){ 
                if (strpos(strtolower($activity_item), strtolower($_POST['q'])) !== false) {  
                    $allBirdactivity[] = $activity_item;
                }
            }
        } 
        $activity_unique = array_unique($allBirdactivity);
        foreach($activity_unique as $activityelement){
            array_push($data, ucwords($activityelement));
        }
    }

    if(!empty($bird_locations_meta_query)) {
        $allBirdlocation =array();
        foreach($bird_locations_meta_query as $location){
            $new = array();
            $new = explode("|",$location->meta_value);
            foreach($new as $new_item){ 
                 
                if (strpos(strtolower($new_item), strtolower($_POST['q'])) !== false) {  
                    
                    $allBirdlocation[] = $new_item;
                }
                
            }
        } 
        $location_unique = array_unique($allBirdlocation);
        foreach($location_unique as $loc){
            array_push($data,ucwords($loc));
        }
    }

    $data = array_unique($data);
    if(!empty($data)) {
        sort($data);
    }
    
    echo json_encode($data);
    
    die(0);
}

add_action('wp_ajax_autocomplate', 'odp_autocomplate');
add_action('wp_ajax_nopriv_autocomplate', 'odp_autocomplate');






if( !function_exists( 'odp_search_birds_from_keyword' ) ) {
    function odp_search_birds_from_keyword() {
        $search_txt = trim($_POST['searchtxt']);
        $search_keywords = explode(",",$search_txt);
        $paged = $_POST['paged'];
        $q1 = $q2 = $q3 = [];
        $output = '';
        
        global $wpdb;
        
        if(!empty($search_txt) && $search_txt != '%') { 
            $search_str = '';
            foreach($search_keywords as $key => $search_keyword) {
                $search_keyword = strtolower($search_keyword);   

                if($key == 0) {
                    $search_str .= ' LOWER(wp_posts.post_title) LIKE \'%'.$search_keyword.'%\' ';
                }
                else {
                    $search_str .= ' OR LOWER(wp_posts.post_title) LIKE \'%'.$search_keyword.'%\' ';
                }
            }
            
            $search_birds = $wpdb->get_results("SELECT wp_posts.ID, wp_posts.post_title FROM wp_posts WHERE 1=1 AND ($search_str) AND wp_posts.post_type = 'cp_birds' "
                    . "AND ((wp_posts.post_status = 'publish')) ORDER BY wp_posts.post_date DESC"); 

            if(!empty($search_birds)) {
                foreach($search_birds as $search_bird) {
                    array_push($q1, $search_bird->ID);
                }
            }
            
            $country_terms = $tag_terms = [];
            
            if(count($search_keywords) > 1) {
                foreach($search_keywords as $keyword) {
                    $keyword = stripslashes($keyword);
                    $search_country_terms = get_terms([
                        'name__like' => $keyword,
                        'taxonomy' => 'cp_birds_country',
                        'fields' => 'ids'
                    ]);

                    $search_tag_terms = get_terms([
                        'name__like' => $keyword,
                        'taxonomy' => 'cp_birds_tag',
                        'fields' => 'ids'
                    ]);
                    
                    $country_terms = array_merge($country_terms, $search_country_terms);
                    $tag_terms = array_merge($tag_terms, $search_tag_terms);
                }
            }
            else {
                $search_txt = stripslashes($search_txt);
                $country_terms = get_terms([
                    'name__like' => $search_txt,
                    'taxonomy' => 'cp_birds_country',
                    'fields' => 'ids'
                ]);
            
                $tag_terms = get_terms([
                    'name__like' => $search_txt,
                    'taxonomy' => 'cp_birds_tag',
                    'fields' => 'ids'
                ]);
            }
            
            array_unique($country_terms);
            array_unique($tag_terms);
            
            $q2 = get_posts(array(
                'fields' => 'ids',
                'post_type' => 'cp_birds',
                'posts_per_page' => -1,
                'tax_query' => array(
                    'relation' => 'OR',
                    array( 
                        'taxonomy' => 'cp_birds_tag',
                        'field' => 'id',
                        'terms' =>  $tag_terms,
                        
                    ),
                    array( 
                        'taxonomy' => 'cp_birds_country',
                        'field' => 'id',
                        'terms' =>  $country_terms,
                        
                    )
                 )
            ));
            
            $q3 = get_posts(array(
                    'fields' => 'ids',
                    'post_type' => 'cp_birds',
                    'posts_per_page' => -1,
                    'meta_query' => array(
                        'relation' => 'OR',
                        array(
                           'key' => 'bird_conservation_status',
                           'value' => $search_keywords,
                           'compare' => 'IN'
                        ),
                        array(
                           'key' => 'bird_scientific_name',
                           'value' => $search_keywords,
                           'compare' => 'IN'
                        )
                     )
            ));
            
            $unique = array_unique( array_merge( $q1, $q2, $q3 ) );
            
            if(!empty($unique)) {
                $posts = get_posts(array(
                    'post_type' => 'cp_birds',
                    'post__in' => $unique,
                    'post_status' => 'publish',
                    'posts_per_page' => 8,
                    'paged' => $paged,
                    'meta_query' => array(
                        array(
                         'key' => '_thumbnail_id',
                         'compare' => 'EXISTS'
                        ),
                    )
                ));

                if( $posts ) {
                    foreach( $posts as $post ) {
                        setup_postdata($post); 
                        $postid = $post->ID;

                        $feat_image_full = wp_get_attachment_image_src( get_post_thumbnail_id( $postid ), 'full', false );
                        $feat_image_full_src = !empty( $feat_image_full[0] ) ? $feat_image_full[0] : '';

                        $feat_image_medium = wp_get_attachment_image_src( get_post_thumbnail_id( $postid ), 'square-medium', false );
                        $feat_image_medium_src = !empty( $feat_image_medium[0] ) ? $feat_image_medium[0] : '';
                        
                        if(!empty($feat_image_medium_src)) {
                            $output .= '<li>
                                <a data-fancybox="search-gallery" data-post_id="'.$postid.'" href="'.$feat_image_full_src.'">
                                    <div class="image"><img src="'.$feat_image_medium_src.'" alt="'.get_the_title($postid).'" /></div>
                                    <div class="image-title">'.get_the_title($postid).'</div>
                                </a>
                                
                            </li>';
                        }
                    }
                }
            }
        }
        
        $return['output'] = $output;
        $return['paged'] = $paged;
        
        echo json_encode($return);
        
        die(0);
    }
}

//add_action('wp_ajax_search_birds_from_keyword', 'odp_search_birds_from_keyword');
//add_action('wp_ajax_nopriv_search_birds_from_keyword', 'odp_search_birds_from_keyword');

if( !function_exists( 'odp_search_birds_from_tags_and_keywords' ) ) {
    function odp_search_birds_from_tags_and_keywords() {
        $search_keyword = $_POST['searchtxt'];
        $termtxt = $_POST['termtxt'];
        $paged = $_POST['paged'];
        
        $q1 = $q2 = $q3 = [];
        
        if(!empty($search_keyword)) {
            global $wpdb;
            $search_birds = $wpdb->get_results("SELECT wp_posts.ID FROM wp_posts WHERE 1=1 AND wp_posts.post_title LIKE '$search_keyword%' AND wp_posts.post_type = 'cp_birds' "
                    . "AND ((wp_posts.post_status = 'publish')) ORDER BY wp_posts.post_date DESC"); 

            if(!empty($search_birds)) {
                foreach($search_birds as $search_bird) {
                    array_push($q1, $search_bird->ID);
                }
            }
            
            $q2 = get_posts(array(
                'fields' => 'ids',
                'post_type' => 'cp_birds',
                'posts_per_page' => -1,
                'tax_query' => array(
                    'relation' => 'OR',
                    array( 
                        'taxonomy' => 'cp_birds_tag',
                        'field' => 'name',
                        'terms' =>  $search_keyword,
                    ),
                    array( 
                        'taxonomy' => 'cp_birds_country',
                        'field' => 'name',
                        'terms' =>  $search_keyword,
                    )
                )
            ));
        }
        
        if(!empty($termtxt)) {
            $q3 = get_posts(array(
                'fields' => 'ids',
                'post_type' => 'cp_birds',
                'posts_per_page' => -1,
                'tax_query' => array(
                    'relation' => 'OR',
                    array( 
                        'taxonomy' => 'cp_birds_tag',
                        'field' => 'id',
                        'terms' =>  $termtxt,
                    )
                )
            ));
        }
        
        $unique = array_unique( array_merge( $q1, $q2, $q3 ) );
        
        if(!empty($unique)) {
            $posts = get_posts(array(
                'post_type' => 'cp_birds',
                'paged' => $paged,
                'post_status' => 'publish',
                'posts_per_page' => 8,
                'orderby' => 'post__in',
                'post__in' => $unique,
            ));
            
            $output = '';
            
            if( $posts ) {
                foreach( $posts as $post ) {
                    setup_postdata($post); 
                    $postid = $post->ID;
                    
                    $feat_image_full = wp_get_attachment_image_src( get_post_thumbnail_id( $postid ), 'full', false );
                    $feat_image_full_src = !empty( $feat_image_full[0] ) ? $feat_image_full[0] : '';
                    
                    $feat_image_medium = wp_get_attachment_image_src( get_post_thumbnail_id( $postid ), 'square-medium', false );
                    $feat_image_medium_src = !empty( $feat_image_medium[0] ) ? $feat_image_medium[0] : '';
                    
                    if(!empty($feat_image_medium_src)) {
                        $output .= '<li>
                            <a data-fancybox="search-gallery" href="'.$feat_image_full_src.'">
                                <div class="image"><img src="'.$feat_image_medium_src.'" alt="'.get_the_title($postid).'" /></div>
                                <div class="image-title">'.get_the_title($postid).'</div>
                            </a>
                            
                        </li>';
                    }
                }
            }
        }

        $return['output'] = $output;
        $return['paged'] = $paged;

        echo json_encode($return);
        
        die(0);
        
        if( isset( $_POST ) && !empty( $_POST['ajaxsubmit'] ) ){                    
            exit();
        }
   }
}

//add_action('wp_ajax_search_birds_from_tags_and_keywords', 'odp_search_birds_from_tags_and_keywords');
//add_action('wp_ajax_nopriv_search_birds_from_tags_and_keywords', 'odp_search_birds_from_tags_and_keywords');

function custom_birds_taxonomy_month_picker( $field ){

  
    $past_year    = date("Y",strtotime("-1 year"));
    $next_year    = date("Y",strtotime("+1 year"));
    
    $field['choices'][''] = 'Select Month and Year';
    $field['choices'][$past_year.'-10-01 00:00:00'] = '10-'.$past_year;
    $field['choices'][$past_year.'-11-01 00:00:00'] = '11-'.$past_year;
    $field['choices'][$past_year.'-12-01 00:00:00'] = '12-'.$past_year;
    for($i=1;$i<=12;$i++){
        
        if($i<10){
           $key = date('Y').'-0'.$i.'-01 00:00:00';
        }else{
           $key = date('Y').'-'.$i.'-01 00:00:00';
        }
        $field['choices'][$key] = $i.'-'.date('Y');
    }
    $field['choices'][$next_year.'-01-01 00:00:00'] = '01-'.$next_year;
    $field['choices'][$next_year.'-02-01 00:00:00'] = '02-'.$next_year;
    $field['choices'][$next_year.'-03-01 00:00:00'] = '03-'.$next_year;
    return $field;
}
 
// acf/load_field/key={$field_key} - filter for a specific field based on it's key name , CHANGE THIS TO YOUR FIELDS KEY!
//add_filter('acf/load_field/key=field_5cadb8d4a8f1b', 'custom_birds_taxonomy_month_picker');
function remove_quick_edit_options_of_county($actions, $tag) {
    // unset($actions['edit']); // Edit link
    unset($actions['inline hide-if-no-js']); //Inline Edit link
    // unset($actions['delete']); // Delete link
    //unset($actions['view']); // view link
    return $actions;
}
add_action( 'cp_birds_country_row_actions', 'remove_quick_edit_options_of_county', 10, 2 );
function ssp_remove_member_bulk_actions( $actions ){
    unset( $actions[ 'delete' ] );
    return $actions;
}
add_filter('bulk_actions-edit-cp_birds_country','ssp_remove_member_bulk_actions');

add_filter('manage_cp_birds_posts_columns', 'posts_columns', 5);
add_action('manage_cp_birds_posts_custom_column', 'posts_custom_columns', 5, 2);
 
function posts_columns($defaults){
    $defaults['bird_post_thumbs'] = __('Thumbs');
    $defaults['conservationstatus'] = __('Conservation Status');
    $defaults['scientificname'] = __('Scientific Name');
    $defaults['birdids'] = __('Bird ID');
    return $defaults;
}

function posts_custom_columns($column_name, $id){
    if($column_name === 'bird_post_thumbs'){
        if ( has_post_thumbnail() ) {
            echo basename ( get_attached_file( get_post_thumbnail_id( $id ) ) );
            echo '<br>';
            // echo get_the_title( get_post_thumbnail_id( $id ) );
        }
        else{
            echo '--';
        }
    }
    if($column_name === 'conservationstatus'){
        if( !empty(get_field('bird_conservation_status',$id)) ){
            $cs = get_field('bird_conservation_status',$id);
            echo $cs;
        }
        else{
            echo '—';
        }
    }
    if($column_name === 'scientificname'){
        if( !empty(get_field('bird_scientific_name',$id)) ){
            $sn = get_field('bird_scientific_name',$id);
            echo $sn;
        }
        else{
            echo '—';
        }
    }
    if($column_name === 'birdids'){
        echo $id;
    }
}
add_filter('post_limits', 'postsperpage');
function postsperpage($limits) {
    if (is_search()) {
        global $wp_query;
        $wp_query->query_vars['posts_per_page'] = 100;
    }
    return $limits;
}
/* add_filter( 'relevanssi_modify_wp_query', 'rlv_manage_queries' );
function rlv_manage_queries( $query ) {
    if ( false === strpos( $query->query_vars['s'], ',' ) ) {
        // No comma, so make it a phrase search.
        $query->set( 'sentence', true );
    }
    return $query;
} */
function pr($x = array())
{
    //echo "<pre>"; print_r($x);echo "</pre>";
}
add_filter('query_vars', 'relevanssi_qvs');
function relevanssi_qvs($qv) {
    $qv[] = 'country';
    $qv[] = 'gender';
    $qv[] = 'minage';
    $qv[] = 'maxage';
    $qv[] = 'conservancy';
    $qv[] = 'activity';
    $qv[] = 'birdfamily';
    $qv[] = 'taxonomicgenus';
    $qv[] = 'age';
    $qv[] = 'locations';
    $qv[] = 'locations_multi';
    $qv[] = 'visualcategory';
    $qv[] = 'family';
    $qv[] = 'sorting_option';
    //pr($qv);
    return $qv;
}

function cus_posts_where($where, $query) {
    global $wpdb;

    $exact_match    = esc_sql($query->get('exact_match'));
    $title_match    = $query->get('title_match');
    $by_tags        = esc_sql($query->get('by_tags'));
    $exact_match1   =  $exact_match." ";
    $exact_match2   =  " ".$exact_match;
    $exact_match3   =  " ".$exact_match." ";
    $exact_match4   =  $exact_match."-";
    $exact_match7   =  " ".$exact_match."-";
    $exact_match5   =  "-".$exact_match;
    $exact_match6   =  "-".$exact_match." ";
    $exact_match8 = preg_replace('/(?:s|es|ies)$/', '', $exact_match);

    $by_tags1       =  $by_tags." ";
    $by_tags2       =  " ".$by_tags;
    $by_tags3       =  " ".$by_tags." ";
    $by_tags4       =  $by_tags.",";
    $by_tags5       =  ",".$by_tags;
    $by_tags6       =  ",".$by_tags.",";
    $by_tags7       =  $by_tags;

    $exact_match_sanitized = str_replace(array(' ', '-'), '_', $exact_match);
    $title_match = stripslashes_deep($title_match);

    // Removing special characters from $title_match
    $title_match = preg_replace('/(?:[\'",\-]|s|es|ies)/', '_', $title_match);
    $title_match = str_replace(array(' ', '-'), '_', $title_match);
    if ($exact_match) {
        $where .= " AND(
        ( $wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '$exact_match1%' ) 
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '$exact_match4%')
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '%$exact_match8%')
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '%$exact_match7%')
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '%$exact_match5')
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '%$exact_match6%')
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '%$exact_match2')
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '%$exact_match3%')
        OR ($wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '$exact_match')
        OR( $wpdb->posts.post_type = 'cp_birds'  AND $wpdb->posts.post_status = 'publish' AND $wpdb->posts.post_title LIKE '%$exact_match_sanitized%' ))";
    }
    if ($title_match) {
        $post_id = $wpdb->get_var("
            SELECT ID
            FROM $wpdb->posts
            WHERE post_type = 'cp_birds'
            AND post_status = 'publish'
            AND post_title LIKE '%$title_match%'
        ");

        // Check if genus exists and apply it to the query
        $genus = get_post_meta($post_id, 'bird_taxonomic_genus', true);
        if ($genus) {
            $where .= " OR $wpdb->posts.ID IN (
                SELECT post_id
                FROM $wpdb->postmeta
                WHERE meta_key = 'bird_taxonomic_genus'
                AND meta_value = '$genus'
            )";
        }
    }

    if ($by_tags) {
        global $wpdb;

        // Remove WordPress default "title/content LIKE" conditions.
        // This ensures we search only by taxonomy tags.
        $where = preg_replace(
            "/AND\s+\(\s*\(\s*$wpdb->posts\.post_title\s+LIKE\s+'.*'\s+OR.*post_content\s+LIKE\s+'.*'\s*\)\s*\)/isU",
            '',
            $where
        );

        // Add our custom taxonomy-based filter
        $where .= " AND $wpdb->posts.ID IN (
            SELECT tr.object_id
            FROM $wpdb->term_relationships AS tr
            INNER JOIN $wpdb->term_taxonomy AS tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
            INNER JOIN $wpdb->terms AS t ON tt.term_id = t.term_id
            WHERE tt.taxonomy = 'cp_birds_tag'
            -- AND (t.name LIKE '%$by_tags%' OR t.slug LIKE '%$by_tags%')
            AND (t.name = '$by_tags' OR t.slug = '$by_tags')

        )
        AND $wpdb->posts.post_type = 'cp_birds'
        AND $wpdb->posts.post_status = 'publish'";
    }

    // Return the modified $where clause, which now includes the existing filters and the custom conditions
    return $where;
}

add_filter('posts_where', 'cus_posts_where', 10, 2);


function birds_date_orderby($query) {
    if ($query->is_search() && !is_admin()) {

        $sortby = isset($_GET['sortby']) ? sanitize_text_field($_GET['sortby']) : '';

        switch ($sortby) {
            case 'newest':
                $query->set('orderby', 'date');
                $query->set('order', 'DESC');
                break;
            case 'oldest':
                $query->set('orderby', 'date');
                $query->set('order', 'ASC');
                break;

            default:
                $query->set('orderby', 'relevance'); // Default sorting
        }
    }
}
add_action('pre_get_posts', 'birds_date_orderby');


function birds_name__orderby($orderby, $query) {
    global $wpdb;

    if ($query->is_search() && $query->is_main_query() && !is_admin()) {  
        $sortby = isset($_GET['sortby']) ? sanitize_text_field($_GET['sortby']) : '';

        switch ($sortby) {
            case 'name-asc':
                return "$wpdb->posts.post_title ASC";
            case 'name-desc':
                return "$wpdb->posts.post_title DESC";
        }
    }

    return $orderby; 
}
add_filter('posts_orderby', 'birds_name__orderby', 10, 2);

function get_id_by_title( $post_title ){
    global $wpdb;
    $post_tit_repl = str_replace("'", "\'", $post_title);
    $get_post_id = $wpdb->get_var( "SELECT ID FROM wp_posts WHERE post_type ='lodges' AND post_status = 'publish' AND post_title LIKE '$post_tit_repl'");
    settype($get_post_id, "integer");
    return $get_post_id;
}
// get_id_by_title( 'Delray Beach - Florida, USA' );

/*  ---------------------------------------------------------------------
        Build a percent-encoded bird-search URL for a location.

        Location names contain spaces, en-dashes and accented characters
        (e.g. "San Diego - California, USA", "Tapirai - Brazil"). Emitting the
        raw value into an href produces an invalid URL; crawlers that trust a
        conflicting charset declaration then re-encode it as %FF and report the
        link as broken. rawurlencode() keeps the URL valid and the query
        structure (?s=&locations=) intact.
    --------------------------------------------------------------------- */
/*  ---------------------------------------------------------------------
        Normalise a user-entered URL from an ACF field.

        Lodge editors enter website addresses without a scheme, e.g.
        "www.cabanassanisidro.com". Printed straight into an href the browser
        treats it as a path relative to the current page, so the link resolves
        to /lodges/<slug>/www.cabanassanisidro.com and lands on the homepage
        instead of the intended site. Prefix https:// when the scheme is
        missing and upgrade http:// to https://.
    --------------------------------------------------------------------- */
function od_normalize_url( $url ) {
    $url = trim( (string) $url );
    if ( $url === '' ) {
        return '';
    }
    if ( stripos( $url, 'http://' ) === 0 ) {
        return 'https://' . substr( $url, 7 );
    }
    if ( stripos( $url, 'https://' ) === 0 ) {
        return $url;
    }
    if ( strpos( $url, '//' ) === 0 ) {
        return 'https:' . $url;
    }
    return 'https://' . ltrim( $url, '/' );
}

function od_location_search_url( $location ) {
    return site_url() . '/?s=&locations=' . rawurlencode( mb_strtolower( (string) $location, 'UTF-8' ) );
}


// add_filter( 'relevanssi_modify_wp_query', 'rlv_manage_queries');
add_action('pre_get_posts', 'rlv_manage_queries');

function rlv_manage_queries( $query ) { 

    // global $wpdb;
    
    if( isset($_GET['navnav']) ){
        echo '<pre>';
        // mail('nadeem77599@gmail.com', 'sfdfd', print_r( $query->query_vars, true ) );
            // print_r($wp_query);
            // print_r($query->get('post_type'));
            // print_r($query->query_vars);


            echo '<br/>';
            echo '<br/>';
            echo '<br/>';
            echo '<br/>';
            echo '<br/>';
            echo '<br/>';
            echo '<br/>';
            echo '</pre>';
        // die;
        // return $query;
    }else{
        if ( $query->is_search ){
            if( is_admin() || $query->get('post_type') == 'nav_menu_item' || $query->get('post_type') == 'page' ){

            }else{
                $search = trim($query->query_vars['s']);

                // $searchlocations = trim($query->query_vars['locations']);
                if (strpos($search, "/") !== false) {
                    $search = str_replace("/", "", $search);
                }
                
                if (strpos($search, ".") !== false) {
                    $search = str_replace(".", "", $search);
                }
                
                $trim_search  = rtrim($search, 's');
                
                $query->set('s', $trim_search);
                $query->set( 'post_type', array( 'cp_birds' ) );
                if (isset($query->query_vars['sorting_option'])) {
                    if ( !empty($query->query_vars['sorting_option']) ) {
                        // do something
                        if ( 'exact_match' == $query->query_vars['sorting_option'] ) {
                            // $query->set( 'exact_match', " ".$search );
                            // $query->set( 'exact_match', $search." " );
                            
                            $query->set( 'exact_match', $search );
                        }
                         elseif (  'contain' == $query->query_vars['sorting_option']  ) {
                            $query->set('title_match', $search);

                        } 
                        elseif (  'by_tags' == $query->query_vars['sorting_option']  ) {
                            $query->set('by_tags', $search);
                        }
                    }
                }

                if (isset($query->query_vars['country'])) {
                    if (!empty($query->query_vars['country'])) {
                        $tax_query = array(
                            array(
                                'taxonomy' => 'cp_birds_country',
                                'field'    => 'id',
                                'terms'    => stripcslashes($query->query_vars['country']),
                            ),
                        );
                        $query->set( 'tax_query', $tax_query );
                        //pr($query); die;
                    }
                }

                $meta_query = array();
                if (!empty($query->query_vars['gender'])) {
                    $meta_query[] = array(
                        'key'       => 'bird_gender',
                        'value'     => stripcslashes($query->query_vars['gender']),
                        'compare'   => '=',
                    );
                }
                // pr($query);
                if (!empty($query->query_vars['minage']) && !empty($query->query_vars['maxage'])) {
                    $meta_query[] = array(
                        'relation' => 'AND',
                        array(
                            'key'       => 'bird_age',
                            'value'     => '',
                            'compare'   => '!='
                        ),
                        array(
                            'key'     => 'bird_age',
                            'value'   => $query->query_vars['minage'],
                            'compare'   => '>=',
                        ),
                        array(
                            'key'     => 'bird_age',
                            'value'   => $query->query_vars['maxage'],
                            'compare' => '<=',
                        ),
                    );
                }
                if (!empty($query->query_vars['conservancy'])) {
                    $meta_query[] = array(
                        'key'       => 'bird_conservation_status',
                        'value'     => stripcslashes($query->query_vars['conservancy']),
                        'compare'   => '=',
                    );
                }
                if (!empty($query->query_vars['age'])) {
                    $meta_query[] = array(
                        'key'       => 'bird_age',
                        'value'     => stripcslashes($query->query_vars['age']),
                        'compare'   => '=',
                    );
                }
                if (!empty($query->query_vars['activity'])) {
                    $meta_query[] = array(
                        'key'       => 'bird_activity',
                        'value'     => stripcslashes($query->query_vars['activity']),
                        'compare'   => 'LIKE',
                    );
                }
                if (!empty($query->query_vars['birdfamily'])) {
                    $meta_query[] = array(
                        'key'       => 'bird_family',
                        'value'     => stripcslashes($query->query_vars['birdfamily']),
                        'compare'   => '=',
                    );
                }
                if (!empty($query->query_vars['taxonomicgenus'])) {
                    $meta_query[] = array(
                        'key'       => 'bird_taxonomic_genus',
                        'value'     => stripcslashes($query->query_vars['taxonomicgenus']),
                        'compare'   => '=',
                    );
                }
                if (!empty($query->query_vars['locations'])) {
                    $location_value = stripcslashes($query->query_vars['locations']);
                    $loc_meta_value = get_id_by_title($location_value);
                    if($loc_meta_value == 0){
                        $loc_meta_value = NULL; 
                    }
                    $loc_meta_value1 = ':"' . $loc_meta_value .'";';
                    $loc_meta_value2 = ':' . $loc_meta_value .';';

                    $meta_query[] = array(
                        'relation' => 'OR',
                        array(
                        'key'       => 'bird_locations_multi',
                        'value'     =>  $loc_meta_value1, 
                        'compare'   => 'LIKE',
                        ),
                        array(
                            'key'       => 'bird_locations_multi',
                            'value'     =>  $loc_meta_value2, 
                            'compare'   => 'LIKE',
                        ),
                            
                    );
                }

                if (!empty($query->query_vars['visualcategory'])) {
                    $meta_query[] = array(
                        'key'       => 'bird_visual_country',
                        'value'     => stripcslashes($query->query_vars['visualcategory']),
                        'compare'   => '=',
                    );
                }
                if (!empty($query->query_vars['family'])) {
                    $meta_query[] = array(
                        'key'       => 'bfamily',
                        'value'     => stripcslashes($query->query_vars['family']),
                        'compare'   => '=',
                    );
                }
                
                if (!empty($meta_query)) {
                    $meta_query['relation'] = 'AND'; // you can also use 'OR' here
                    $query->set('meta_query', $meta_query);
                }
                //$query->set( 'post_type', 'nav_menu_item' );
                // $query->set('order', 'ASC');
                // pr(stripcslashes($query));
                }
            }
            // print_r($query);
        return $query;
    } 

}

add_filter('relevanssi_search_ok', 'search_trigger');
if( !function_exists( 'search_trigger' ) ) {
    function search_trigger($search_ok) {
        global $wp_query;
        /*if(!empty(isset($wp_query->query['s']))){
            //$wp_query->query['s'];
            $search_ok = true;
        }*/
        if (!empty($wp_query->query_vars['tax_query'])) {
            $search_ok = true;
        }
        if (!empty($wp_query->query_vars['meta_query'])) {
            $search_ok = true;
        }

        /*if ( !isset($wp_query->query['s']) && isset( $wp_query->query_vars['tax_query']) && isset( $wp_query->query_vars['gender']) ) {
            $search_ok = true;
        }*/
        //pr($search_ok);
        return $search_ok;
    }
}

add_filter('relevanssi_hits_filter', 'rlv_hits_filter');
/**
 * return results when there are active filters but no search term
 * @param  array $hits $hits[0] is a list of matched WP_Post objects
 *                     $hits[1] is the search term if any
 * @return array       $hits
 */
if( !function_exists( 'rlv_hits_filter' ) ) {
    function rlv_hits_filter($hits) {
        global $wp_query;
        //pr($hits);
        if( $wp_query->is_search && $wp_query->get('post_type') != 'nav_menu_item' ){

            if ( !$hits[1] && isset( $wp_query->query_vars['tax_query']) ) {
                $wp_query->set('nopaging', true);
                $hits[0] = get_posts( $wp_query->query_vars );
            }

            if ( !$hits[1] && isset( $wp_query->query_vars['meta_query']) ) {
                //pr($wp_query);
                $wp_query->set('nopaging', true);
                $hits[0] = get_posts( $wp_query->query_vars );
            }
        }

        return $hits;
        /*global $wp_query;
        if (isset($wp_query->query_vars['tax_query'])) {
            $correct_colour = array();
            pr($wp_query->query_vars['tax_query']);
            foreach ($hits[0] as $hit) {
                $colour = get_post_meta($hit->ID, 'colour', true);
                if ($colour == $wp_query->query_vars['colour']) $correct_colour[] = $hit;
            }
            $hits[0] = $correct_colour;
        }
        return $hits;*/
    }
}
if( !function_exists( 'update_save_post_content_callback' ) ) {
    function update_save_post_content_callback($post_id,$update) {
        global $wpdb;
        $title = $update->post_title;
        $cs = $_POST['acf']['field_5cc1a71db9ad5']; //bird_conservation_status
        $sn = $_POST['acf']['field_5ca2126fea6cd']; //bird_scientific_name
        $gn = $_POST['acf']['field_5d1b3887dd5a5']; //bird_gender
        $ag = $_POST['acf']['field_5d1b389bdd5a6']; //bird_age
        $co = $_POST['acf']['field_5d1d9e52da19c']; //bird_conservancy
        $ba = $_POST['acf']['field_5d1d9e63da19d']; //bird_activity
        $bf = $_POST['acf']['field_5d1d9e71da19e']; //bird_family
        $tg = $_POST['acf']['field_5d1d9e80da19f']; //bird_taxonomic_genus
        $ec = $_POST['acf']['field_5d1b387edd5a4']; //bird_endemic_country
        $lc = $_POST['acf']['field_5d47eb62d75c0']; //bird_locations
        $lcm= $_POST['acf']['field_63a40d7311248']; //bird_locations_multi
        $vc = $_POST['acf']['field_5d43d359b3da0']; //bird_visual_country
        $bfamily = $_POST['acf']['field_5e072fb18e1c7']; //bfamily

        $output = [];
        // Post Title
        $trim_title = trim($title);
        $output[] = $trim_title;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_title));
        if (strpos($trim_title, "'") !== false) {
            $trim_title = replaceString($trim_title, "'") ;
            $trim_title = str_replace(' ', ',' ,$trim_title);
            $output[] = $trim_title;
        }
        if (strpos($trim_title, "-") !== false) {
            $trim_title = replaceString($trim_title, "-");
            $trim_title = str_replace(' ', ',' ,$trim_title);
            $output[] = $trim_title;
        }
        // Scientific Name
        $trim_sn = trim($sn);
        $output[] = $trim_sn;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_sn));
        if (strpos($trim_sn, "'") !== false) {
            $trim_sn = replaceString($trim_sn, "'");
            $trim_sn = str_replace(' ', ',' ,$trim_sn);
            $output[] = $trim_sn;
        }
        if (strpos($trim_sn, "-") !== false) {
            $trim_sn = replaceString($trim_sn, "-");
            $trim_sn = str_replace(' ', ',' ,$trim_sn);
            $output[] = $trim_sn;
        }
        // Tags
        $tags = wp_get_post_terms($update->ID, 'cp_birds_tag');
        if ($tags) {
            foreach ($tags as $tag) {
                $tag_name = trim($tag->name);
                $output[] = $tag_name;
                $output[] = mb_strtolower(str_replace(' ', '' ,$tag_name));
                if (strpos($tag_name, "'") !== false) {
                    $tag_name = replaceString($tag_name, "'");
                    $tag_name = str_replace(' ', ',' ,$tag_name);
                    $output[] = $tag_name;
                }
                if (strpos($tag_name, "-") !== false) {
                    $tag_name = replaceString($tag_name, "-");
                    $tag_name = str_replace(' ', ',' ,$tag_name);
                    $output[] = $tag_name;
                }
            }
        }
        // Conservation Status
        $trim_cs = trim($cs);
        $output[] = $trim_cs;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_cs));
        if (strpos($trim_cs, "'") !== false) {
            $trim_cs = replaceString($trim_cs, "'");
            $trim_cs = str_replace(' ', ',' ,$trim_cs);
            $output[] = $trim_cs;
        }
        if (strpos($trim_cs, "-") !== false) {
            $trim_cs = replaceString($trim_cs, "-");
            $trim_cs = str_replace(' ', ',' ,$trim_cs);
            $output[] = $trim_cs;
        }

        // Gender
        $trim_gn = trim($gn);
        $output[] = $trim_gn;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_gn));
        if (strpos($trim_gn, "'") !== false) {
            $trim_gn = replaceString($trim_gn, "'");
            $trim_gn = str_replace(' ', ',' ,$trim_gn);
            $output[] = $trim_gn;
        }
        if (strpos($trim_gn, "-") !== false) {
            $trim_gn = replaceString($trim_gn, "-");
            $trim_gn = str_replace(' ', ',' ,$trim_gn);
            $output[] = $trim_gn;
        }

        // Age
        $trim_age = trim($ag);
        $output[] = $trim_age;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_age));
        if (strpos($trim_age, "'") !== false) {
            $trim_age = replaceString($trim_age, "'");
            $trim_age = str_replace(' ', ',' ,$trim_age);
            $output[] = $trim_age;
        }
        if (strpos($trim_age, "-") !== false) {
            $trim_age = replaceString($trim_age, "-");
            $trim_age = str_replace(' ', ',' ,$trim_age);
            $output[] = $trim_age;
        }

        // Conservancy
        $trim_co = trim($co);
        $output[] = $trim_co;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_co));
        if (strpos($trim_co, "'") !== false) {
            $trim_co = replaceString($trim_co, "'");
            $trim_co = str_replace(' ', ',' ,$trim_co);
            $output[] = $trim_co;
        }
        if (strpos($trim_co, "-") !== false) {
            $trim_co = replaceString($trim_co, "-");
            $trim_co = str_replace(' ', ',' ,$trim_co);
            $output[] = $trim_co;
        }

        // Bird Activity
        $trim_ba = trim($ba);
        $output[] = $trim_ba;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ba));
        if (strpos($trim_ba, "'") !== false) {
            $trim_ba = replaceString($trim_ba, "'");
            $trim_ba = str_replace(' ', ',' ,$trim_ba);
            $output[] = $trim_ba;
        }
        if (strpos($trim_ba, "-") !== false) {
            $trim_ba = replaceString($trim_ba, "-");
            $trim_ba = str_replace(' ', ',' ,$trim_ba);
            $output[] = $trim_ba;
        }

        // Bird Family
        $trim_bf = trim($bf);
        $output[] = $trim_bf;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_bf));
        if (strpos($trim_bf, "'") !== false) {
            $trim_bf = replaceString($trim_bf, "'");
            $trim_bf = str_replace(' ', ',' ,$trim_bf);
            $output[] = $trim_bf;
        }
        if (strpos($trim_bf, "-") !== false) {
            $trim_bf = replaceString($trim_bf, "-");
            $trim_bf = str_replace(' ', ',' ,$trim_bf);
            $output[] = $trim_bf;
        }

        // Taxonomic Genus
        $trim_tg = trim($tg);
        $output[] = $trim_tg;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_tg));
        if (strpos($trim_tg, "'") !== false) {
            $trim_tg = replaceString($trim_tg, "'");
            $trim_tg = str_replace(' ', ',' ,$trim_tg);
            $output[] = $trim_tg;
        }
        if (strpos($trim_tg, "-") !== false) {
            $trim_tg = replaceString($trim_tg, "-");
            $trim_tg = str_replace(' ', ',' ,$trim_tg);
            $output[] = $trim_tg;
        }

        // Endemic country
        $trim_ec = trim($ec);
        $output[] = $trim_ec;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_ec));
        if (strpos($trim_ec, "'") !== false) {
            $trim_ec = replaceString($trim_ec, "'");
            $trim_ec = str_replace(' ', ',' ,$trim_ec);
            $output[] = $trim_ec;
        }
        if (strpos($trim_ec, "-") !== false) {
            $trim_ec = replaceString($trim_ec, "-");
            $trim_ec = str_replace(' ', ',' ,$trim_ec);
            $output[] = $trim_ec;
        }

        // Locations Column
        // Bird Locations
        if(!empty($lc)){
            //$trim_bl = trim($bl);
            // $trim_bl = preg_replace('/\s/', '', $trim_bl);
            // $trim_bl = str_replace('|', ',' ,$trim_bl);
            $strrpl = str_replace('|', ',' ,$lc);
            $output[] = $strrpl;
            $output[] = preg_replace('/\s/', '', $strrpl);
            $output[] = mb_strtolower(str_replace(' ', '' ,$strrpl));
            $output[] = mb_strtolower(str_replace('|', ',' ,$strrpl));

            //$trim_bl = mb_strtolower(str_replace('|', ',' ,$trim_bl));
            //$output[] = mb_strtolower($trim_bl);
                        
            if (strpos($strrpl, "'") !== false) {
                $strrpl = replaceString($strrpl, "'");
                $strrpl = str_replace(' ', ',' ,$strrpl);
                $output[] = $strrpl;
            }
            if (strpos($strrpl, "-") !== false) {
                $strrpl = replaceString($strrpl, "-");
                $strrpl = str_replace(' ', ',' ,$strrpl);
                $output[] = $strrpl;
            }
            //pr($output);
        }
        // visual category
        $trim_vc = trim($vc);
        $output[] = $trim_vc;
        $output[] = mb_strtolower(str_replace(' ', '' ,$trim_vc));
        if (strpos($trim_vc, "'") !== false) {
            $trim_vc = replaceString($trim_vc, "'");
            $trim_vc = str_replace(' ', ',' ,$trim_vc);
            $output[] = $trim_vc;
        }
        if (strpos($trim_vc, "-") !== false) {
            $trim_vc = replaceString($trim_vc, "-");
            $trim_vc = str_replace(' ', ',' ,$trim_vc);
            $output[] = $trim_vc;
        }

        // $bfamily => Family
        if(!empty($bfamily)){
            $trim_bfamily = trim($bfamily);
            $output[] = $trim_bfamily;
            $output[] = mb_strtolower(str_replace(' ', '' ,$trim_bfamily));

            if (strpos($trim_bfamily, "'") !== false) {
                $trim_bfamily = replaceString($trim_bfamily, "'");
                $trim_bfamily = str_replace(' ', ',' ,$trim_bfamily);
                $output[] = $trim_bfamily;
            }

            if (strpos($trim_bfamily, "-") !== false) {
                $trim_bfamily = replaceString($trim_bfamily, "-");
                $trim_bfamily = str_replace(' ', ',' ,$trim_bfamily);
                $output[] = $trim_bfamily;
            }
        }
        // Country Name
        $countryoutput = get_the_terms($update->ID, 'cp_birds_country');
        foreach ($countryoutput as $cat) {
            $catname  = mb_strtolower(str_replace(' ', '' ,$cat->name));
            $output[] = $catname;
        }
        $result = implode(",",$output);
        $return_string = removeComma($result);
        pr("return string==".$return_string);
        $blogtime = current_time( 'mysql', 1);
        $update = $wpdb->query('UPDATE wp_posts SET post_content = "'.$return_string.'"  WHERE ID = '.$post_id);
        $update = $wpdb->query('UPDATE wp_posts SET post_content = "'.$return_string.'", post_modified = "'.$blogtime.'", post_modified_gmt = "'.$blogtime.'"   WHERE ID = '.$post_id);
        return $update;
    } 
}
add_action( 'save_post_cp_birds', 'update_save_post_content_callback', 10, 2 );

function replaceString($string, $character) {
    $words = explode($character, $string);
    $new_string = '';
    if(!empty($words)) {
        foreach($words as $key => $word) {
            if($key > 0) {
                $word = $character . $word;
                $find_character = getBetween($word,$character," ");
                $count = strlen($find_character);
                
                if($count > 2) {
                    $find_word = $character;
                    $replace_word = ",";
                }
                else {
                    $find_word = $character . $find_character;
                    $replace_word = ",";
                }
                $new_word = str_replace($find_word, $replace_word ,$word);
                $new_string .= $new_word;
            }
            else {
                $new_string .= $word;
            }
        }
    }
    
    return $new_string;
}

function getBetween($string, $start = "", $end = ""){
    if (strpos($string, $start) !== false) { 
    // required if $start not exist in $string
        $startCharCount = strpos($string, $start) + strlen($start);
        $firstSubStr = substr($string, $startCharCount, strlen($string));
        $endCharCount = strpos($firstSubStr, $end);
        if ($endCharCount == 0) {
            $endCharCount = strlen($firstSubStr);
        }
        return substr($firstSubStr, 0, $endCharCount);
    } else {
        return '';
    }
}

function removeComma($string = "") {
    $return_string = '';
    if(!empty($string)) {
        $prev_character = '';
        for($i=0; $i<strlen($string); $i++) {
            if($string[$i] == ',') {
                if($string[$i] != $prev_character) {
                    $return_string .= $string[$i];
                }
            }
            else {
                $return_string .= $string[$i];
            }
            $prev_character = $string[$i];
        }
    }
    
    return $return_string;
}

add_action('wp_ajax_get_country_code', 'get_country_code');
add_action('wp_ajax_nopriv_get_country_code', 'get_country_code');
function get_country_code(){
    
    global $wpdb;
    $data['status'] = false;
    $data['operation'] = '';
    $country_id = $_POST['cnt_id'];
    $country = $wpdb->get_row("SELECT * FROM wp_mapsvg_regions_486 WHERE `country_id`= $country_id" );
    
    if(!empty($country)){
        $data['status'] = true;
        $data['cnt_code'] = $country->id;
        $data['cnt_status'] = $country->status;
        $data['cntry_select_id'] = $country->country_select_id;
        $data['msg'] = "Code found";
    }else{
        $data['status'] = false;
         $data['cnt_code'] = "";
         $data['cnt_status'] = 0;
        $data['msg'] = "Code not found";
    }

    echo json_encode($data);
    die();
}
add_action('wp_ajax_get_country_bird', 'get_country_bird');
add_action('wp_ajax_nopriv_get_country_bird', 'get_country_bird');
function get_country_bird(){
    global $wpdb;
    // if ( isset( $_POST['cnt_id'] ) ) {
        $country_id = @$_POST['cnt_id'];
        $data['status'] = false;
        $country_status = $wpdb->get_results("SELECT * FROM wp_mapsvg_regions_486 WHERE status = 1 ORDER BY region_title ASC" );


        $countryData = array();
        foreach ($country_status as $cs) {

            if(!empty($cs)){
                $data['status'] = true;
                $data['cnt_code'] = $cs->id;
                $data['cntry_status'] = $cs->status;
                $data['cntry_id'] = $cs->country_id;
                $data['cntry_select_id'] = $cs->country_select_id;
                $data['msg'] = "Status Enabled";
            }else{
                $data['status'] = false;
                $data['cnt_code'] = "";
                $data['cntry_status'] = 0;
                $data['msg'] = "Status Disabled";
            }
            array_push($countryData,$data);
        }

        echo json_encode($countryData);
    // }
    die();
}

function globe(){ ?>

    <script>
  
  //   var width = 500,
  //   height = 550,
  var height = jQuery(window).height() - 20,
      width = jQuery(window).width() - 20,
      sens = 0.25,
      focused;
  
  const config = {
                speed: 0.005,
                verticalTilt: -180,
                horizontalTilt: -180
              }
  
  enableRotation();
  time = Date.now();
  
    //Setting projection
      if (window.width < 980) { 
  
       var projection = d3.geo.orthographic()
        .scale(width/2)
        .rotate([0,0])
        .translate([width / 2, height / 2])
        .clipAngle(90);
  
      } else { 
  
       var projection = d3.geo.orthographic()
        .scale(width/5)
        .rotate([0,0])
        .translate([width / 2, height / 2])
        .clipAngle(90);
  
      } 
  
  
    var path = d3.geo.path()
    .projection(projection);
  
    //SVG container
  
    var svg = d3.select("body .load-map").append("svg")
                  .style("width", width + 'px')
                  .style("height", height + 'px');
  
    //Adding water
  
    svg.append("path")
    .datum({type: "Sphere"})
    .attr("class", "water")
    .attr("d", path)
    .call(d3.behavior.drag()
      .origin(function() { 
              var r = projection.rotate(); 
              return {x: r[0] / sens, y: -r[1] / sens}; 
                  }
              )
      .on("drag", function() {
          var rotate = projection.rotate();
          projection.rotate([d3.event.x * sens, -d3.event.y * sens, rotate[2]]);
              svg.selectAll("path.land").attr("d", path);
              svg.selectAll(".focused").classed("focused", focused = false);
            })
        )
    .on("click",function(){
      intialcall =1 ;
    })
    .call(d3.behavior.zoom().on('zoom', function() {
          svg.attr("transform","scale(" + d3.event.scale + ")")
        }))
  
  
    var countryTooltip = d3.select("body").append("div").attr("class", "countryTooltip"),
    countryList = d3.select("body .load-map").append("select").attr("name", "countries");
  
    jQuery(function(jQuery){
          jQuery("select").dropdown();
          jQuery("select").prepend('<option selected disabled hidden>Select Country</option>');
          jQuery("select").attr('autocomplete', 'off');
      });
  
    queue()
    .defer(d3.json, "https://owendeutsch.com/wp-content/themes/owendeutsch/world.json")
    .defer(d3.tsv, "https://owendeutsch.com/wp-content/themes/owendeutsch/names.tsv")
    .await(ready);
  
  var intialcall = 0;
   function enableRotation() {
      //debugger;
                d3.timer(function (elapsed) {
                  //debugger;
                  if(intialcall == 0) {
                       projection.rotate([config.speed * elapsed - 120, config.verticalTilt, config.horizontalTilt]);
                      svg.selectAll("path").attr("d", path);
                  }                 
                  });
  
              }
  
    //Main function
    var Country = {};
    function ready(error, world, countryData) {
  
      var countryById = {},
      countries = topojson.feature(world, world.objects.countries).features;
  
      //Adding countries to select
  
      // countryData.forEach(function(d) {
      //   countryById[d.id] = d.name;
      //   option = countryList.append("option");
      //   option.text(d.name);
      //   option.property("value", d.id);
      // });
  
      //Drawing countries on the globe
  
      var world = svg.selectAll("path.land")
      .data(countries)
      .enter().append("path")
      .attr("class", "land")
      .attr("d", path)
  
      //Drag event
  
      .call(d3.behavior.drag()
        .origin(function() { var r = projection.rotate(); return {x: r[0] / sens, y: -r[1] / sens}; })
        .on("drag", function() {
          var rotate = projection.rotate();
          projection.rotate([d3.event.x * sens, -d3.event.y * sens, rotate[2]]);
          svg.selectAll("path.land").attr("d", path);
          svg.selectAll(".focused").classed("focused", focused = false);
        }))
      .call(d3.behavior.zoom().on('zoom', function() {
          svg.attr("transform","scale(" + d3.event.scale + ")")
        }))
  
      //Mouse events
  
      .on("mouseover", function(d) {
        countryTooltip.text(countryById[d.id])
        .style("left", (d3.event.pageX + 7) + "px")
        .style("top", (d3.event.pageY - 15) + "px")
        .style("display", "block")
        .style("opacity", 1);
        Country = countryById[d.id]
      })
  
      // Onclick display particular country Birds
      .on("click", function(d,Country) {
        // window.open("http://localhost/owen/cp_birds_country/"+Country+"/")
        getCountry(Country);
      })
  
      .on("mouseout", function(d) {
        countryTooltip.style("opacity", 0)
        .style("display", "none");
      })
      .on("mousemove", function(d) {
        countryTooltip.style("left", (d3.event.pageX + 7) + "px")
        .style("top", (d3.event.pageY - 15) + "px");
      });
              /* Custom Code By Nikunj */
              jQuery( ".land" ).each(function( index ) {
                jQuery( this ).attr("data-country_id",index);
                jQuery( this ).attr("id",index);
              });
              
  
              // Get the Bird Country
              function getBirdCountry(Country){
                var my_ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
                  jQuery.ajax({
                    url: my_ajaxurl,
                    type: 'POST',
                    dataType: 'json',
                    data: {'action' : 'get_country_bird'},
                  })
                  .done(function(data) {
                      console.log(data);
                     data.forEach(function(index1) 
                     {
                      jQuery('path.land').attr('class', function(index, classNames) {
                          if(index1.cntry_id == index){
                              return classNames + ' birds';                            
                          }
                      }); 
                              countryData.forEach(function(d) {
  
                              countryById[d.id] = d.name;
                              if(index1.cntry_select_id == d.id){
                                  option = countryList.append("option");
                                  option.text(d.name);
                                  option.property("value", d.id);
                              }
                              
                          }); 
                    });
                    
                  })
                }
                getBirdCountry(Country);
  
              // onclick move to country page
              function getCountry(Country){
                  var my_ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
                  jQuery.ajax({
                      url: my_ajaxurl,
                      type: 'POST',
                      dataType: 'json',
                      data: {'action' : 'get_country_code', cnt_id:Country},
                  })
                  .done(function(data) {
                      if(data.status == true){
                          
                          window.open("https://owendeutsch.com/cp_birds_country/"+data.cnt_code+"/","_self")
                      }else{
                          jQuery('path .land').off('click');
                      }
                  })
                  .fail(function(err) {
                      console.log(err);
                  });
                }
  
      //Country focus on option select
  
      d3.select("select").on("change", function() {
          intialcall = 1;
          //enableRotation();
          if(jQuery('body.home, body.page-template-template-countries').length ){
              if( jQuery( window ).width() >= 767 ) {
                  jQuery('html, body').animate({
                      scrollTop: jQuery(".visit-a-country, .country-globe").offset().top - ( jQuery('#mainhead').outerHeight())
                  }, 800);
              }
              if( (jQuery( window ).width() <= 767) && (window.innerHeight > window.innerWidth)) {
                  // alert('portrait');
                  jQuery('html, body').animate({
                      scrollTop: jQuery(".visit-a-country,  .country-globe").offset().top - (jQuery("#mainhead").outerHeight())
                  }, 800);
              }
          }
          var rotate = projection.rotate(),
   
          focusedCountry = country(countries, this),
          p = d3.geo.centroid(focusedCountry);
          
          svg.selectAll(".focused").classed("focused", focused = false);
  
      //Globe rotating
  
          (function transition() {
            d3.transition()
            .duration(2500)
            .tween("rotate", function() {
          
               var r = d3.interpolate(projection.rotate(), [ -p[0], -p[1], 0 ]);
              
              return function(t) {
                projection.rotate(r(t));
   
                svg.selectAll("path").attr("d", path)
                .classed("focused", function(d, i) { return d.id == focusedCountry.id ? focused = d : false; });
              };
            })
            })();
          });
  
          function country(cnt, sel) { 
            for(var i = 0, l = cnt.length; i < l; i++) {
              if(cnt[i].id == sel.value) {return cnt[i];}
            }
          };
  
    };
    </script>
  
  <?php } 
  
  add_shortcode('map','globe');
  
  
function get_meta_values( $key = '', $type = 'post', $status = 'publish' ) {

    global $wpdb;

    if( empty( $key ) )
        return;

    $r = $wpdb->get_col( $wpdb->prepare( "
        SELECT DISTINCT(pm.meta_value) FROM {$wpdb->postmeta} pm
        LEFT JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = %s 
        AND p.post_status = %s 
        AND p.post_type = %s
    ", $key, $status, $type ) );

    return $r;
}
function excerpt($limit) {
  $excerpt = explode(' ', get_the_excerpt(), $limit);
  if (count($excerpt)>=$limit) {
    array_pop($excerpt);
    $excerpt = implode(" ",$excerpt).'...';
  } else {
    $excerpt = implode(" ",$excerpt);
  } 
  $excerpt = preg_replace('`[[^]]*]`','',$excerpt);
  return $excerpt;
}
 
function content($limit) {
  $content = explode(' ', get_the_content(), $limit);
  if (count($content)>=$limit) {
    array_pop($content);
    $content = implode(" ",$content).'...';
  } else {
    $content = implode(" ",$content);
  } 
  $content = preg_replace('/[.+]/','', $content);
  $content = apply_filters('the_content', $content); 
  $content = str_replace(']]>', ']]>', $content);
  return $content;
}
add_filter( 'relevanssi_didyoumean_url', 'rlv_modify_didyoumean_url' );
function rlv_modify_didyoumean_url( $url ) {
    //pr($url);
    /*$parts = parse_url($url);
    parse_str($parts['query'], $query);
    echo $query['email'];*/
    $get_string = parse_url($url);

    parse_str($get_string['query'], $get_array);
    $suggestion_search = $get_array['s'];
    //echo $suggestion_search;
    if( ( isset($_GET['country']) && !empty($_GET['country'])) || ( isset($_GET['gender']) && !empty($_GET['gender']) ) ||
        ( isset($_GET['minage']) && !empty($_GET['minage']) && isset($_GET['maxage']) && !empty($_GET['maxage'])) ||
        ( isset($_GET['conservancy']) && !empty($_GET['conservancy']) ) || 
        ( isset($_GET['activity']) && !empty($_GET['activity']) ) || 
        ( isset($_GET['birdfamily']) && !empty($_GET['birdfamily']) ) ||
        ( isset($_GET['sorting_option']) && !empty($_GET['sorting_option']) ) ||
        ( isset($_GET['taxonomicgenus']) && !empty($_GET['taxonomicgenus']) ||  ( isset($_GET['locations']) && !empty($_GET['locations']) ) ||  ( isset($_GET['locations_multi']) && !empty($_GET['locations_multi']) ) ||  ( isset($_GET['visualcategory']) && !empty($_GET['visualcategory']) ) )
    ){
        $querycounty = $_GET['country'];
        $querygender = $_GET['gender'];
        $queryminage = $_GET['minage'];
        $querymaxage = $_GET['maxage'];
        $queryconservancy = $_GET['conservancy'];
        $queryactivity = $_GET['activity'];
        $querybirdfamily = $_GET['birdfamily'];
        $querytaxonomicgenus = $_GET['taxonomicgenus'];
        $querylocations = $_GET['locations'];
        $querylocations_multi = $_GET['locations_multi'];
        $queryvisualcategory = $_GET['visualcategory'];
        $querysorting_option = $_GET['sorting_option'];
    }
    else{
        remove_query_arg( 'country' );
        remove_query_arg( 'gender' );
        remove_query_arg( 'minage' );
        remove_query_arg( 'maxage' );
        remove_query_arg( 'conservancy' );
        remove_query_arg( 'activity' );
        remove_query_arg( 'birdfamily' );
        remove_query_arg( 'taxonomicgenus' );
        remove_query_arg( 'locations' );
        remove_query_arg( 'locations_multi' );
        remove_query_arg( 'visualcategory' );
        remove_query_arg( 'sorting_option' );
    }
   /* if(isset($_GET['gender']) && !empty($_GET['gender'])){
        $querygender = $_GET['gender'];
    }
    else{
        remove_query_arg( 'gender' );
    }*/
    
    $url = add_query_arg( array(
        
        'country'           => $querycounty,
        'gender'            => $querygender,
        'minage'            => $queryminage,
        'maxage'            => $querymaxage,
        'conservancy'       => $queryconservancy,
        'activity'          => $queryactivity,
        'birdfamily'        => $querybirdfamily,
        'taxonomicgenus'    => $querytaxonomicgenus,
        'locations'         => $querylocations,
        'locations_multi'   => $querylocations_multi,
        'visualcategory'    => $queryvisualcategory,
        'sorting_option'    => $querysorting_option,
    ), $url );
    //pr($url);
    return $url;
}
function force_post_categ( $post ) 
{
    $current_screen = get_current_screen();
    // pr($current_screen);
    // pr($current_screen->post_type);
    if($current_screen->post_type=='cp_birds' && $current_screen->id=='cp_birds') {
        // echo "<h2 class='country_guideline'>Please select country for filter and also schedule this post the same country.</h2>";
        
  ?>
  <script type='text/javascript'>
    jQuery('#publish').click(function() 
        {
            var cats = jQuery('#taxonomy-cp_birds_country')
            .find('.selectit')
            .find('input');
            category_selected=false;
            for (counter=0; counter<cats.length; counter++) 
            {
                if (cats.get(counter).checked==true) 
                {
                    category_selected=true;
                    break;
                }
            }
            if(category_selected==false) 
            {
            alert('You have not selected any category for the post. Please select post category.');
            setTimeout("jQuery('#ajax-loading').css('visibility', 'hidden');", 100);
            jQuery('#taxonomy-cp_birds_country').find('.tabs-panel').css('background', '#F96');
            setTimeout("jQuery('#publish').removeClass('button-primary-disabled');", 100);
            return false;
            }
        });
  </script>
   <?php
    }
}
add_action( 'edit_form_advanced', 'force_post_categ', 10, 1 );

add_action( 'admin_head-edit.php', 'wpse_59871_script_enqueuer' );

function wpse_59871_script_enqueuer() 
{    
    
    global $current_screen;
    //pr($current_screen);
    if('cp_birds' != $current_screen->post_type && 'cp_birds' != $current_screen->id)
        return;
    
    ?>
    <script type="text/javascript">         
        jQuery( window ).load(function() {
            jQuery('.row-actions span.inline.hide-if-no-js').hide();
            jQuery('select#bulk-action-selector-top option.hide-if-no-js').hide();
        });    
    </script>
    <?php
}

/**
 * New User registration
 *
 */
function owen_newsletter_user() {
 
    // Post values
    $email    = $_POST['useremail'];
    $params = array(
                        array(
                            'email' => $email,
                        )
            );
    $json_post_fields = json_encode($params);
    // pr($email);
    $curl = curl_init();
    curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.sendgrid.com/v3/marketing/contacts/search",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "POST",
    CURLOPT_POSTFIELDS => "{\"query\":\"email LIKE '".$email."%' AND CONTAINS(list_ids, 'f721db62-3102-4405-9daf-16b615a97378')\"}",
    CURLOPT_HTTPHEADER => array(
        "authorization: Bearer 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",
        "content-type: application/json"
    ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);


    if ($err) {
        echo json_encode(array('status'=>'fail','message'=>'Something went wrong'));
    } 
    else 
    {
         $isExits = json_decode($response);
    
         if(isset($isExits->contact_count) && $isExits->contact_count == '0' && empty($isExits->result)){
            $curl = curl_init();
            curl_setopt_array($curl, array(
            CURLOPT_URL => "https://api.sendgrid.com/v3/marketing/contacts",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "PUT",
            CURLOPT_POSTFIELDS => "{\"list_ids\":[\"f721db62-3102-4405-9daf-16b615a97378\"],\"contacts\":".$json_post_fields."}",
            CURLOPT_HTTPHEADER => array(
                "Authorization: Bearer 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",
                "Content-Type: application/json"
            ),
            ));
            $response = curl_exec($curl);
            $err = curl_error($curl);
            curl_close($curl);
            if ($err) {
                    //echo "cURL Error #:" . $err;
               echo json_encode(array('status'=>'fail','message'=>'Something went wrong'));
            } else {
               echo json_encode(array('status'=>'success','message'=>'Thank you for subscribing, a confirmation email has been sent, please check your spam/junk folder if you don’t see it'));
            }
        }else{
            echo json_encode(array('status'=>'fail','message'=>'Email is already subscribed.'));
        }
    }
    die();
   
  }
   
  add_action('wp_ajax_register_email', 'owen_newsletter_user');
  add_action('wp_ajax_nopriv_register_email', 'owen_newsletter_user');
/*Insertion in Entry Page*/
function addEntry()
{   
    
    $errors = array();

    // Validate required fields
    $required_fields = array(
        'fname' => 'First name',
        'lname' => 'Last name',
        'email' => 'Email',
        'address1' => 'Address Line 1',
        'city' => 'City',
        'state' => 'State',
        'zipcode' => 'Zip code',
    );

    foreach ($required_fields as $field => $name) {
        if (empty($_POST[$field])) {
            $errors[] = "$name is required";
        }
    }

    // Validate field lengths
    $min_lengths = array(
        'fname' => 2,
        'lname' => 2,
        'address1' => 2,
        'city' => 2,
        'state' => 2,
    );

    foreach ($min_lengths as $field => $length) {
        if (isset($_POST[$field]) && strlen($_POST[$field]) < $length) {
            $errors[] = ucfirst(str_replace('_', ' ', $field)) . " must be at least $length characters";
        }
    }

    // Validate email
    if (!empty($_POST['email']) && !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format";
    }

    // Validate zip code
    if (!empty($_POST['zipcode'])) {
        $zip = sanitize_text_field($_POST['zipcode']);
        if (!preg_match('/^\d{5,7}$/', $zip)) {
            $errors[] = "Zip code must be 5-7 digits";
        }
    }

    if (!empty($errors)) {
        wp_send_json_error(array(
            'message' => 'Validation failed',
            'errors' => $errors
        ));
        
        wp_die();
    }
    
    
    global $wpdb;
    $table = $wpdb->prefix.'contest';
    $response= array();
    $email = $_POST['email'];
    $wpdb->get_results("SELECT * FROM ".$table." WHERE email = '".$email."'");
    $isExits = $wpdb->num_rows;
    // pr($_POST['agree']);
    if($_POST['agree'] == 'true' && isset($_POST['agree'])){
        $email_notification = 'yes';
    }else{
        $email_notification = 'no';
    }


    
    $data = array(
        'cm_fname' => $_POST['fname'], 
        'cm_lname' => $_POST['lname'],
        'address1' =>$_POST['address1'],
        'address2' =>$_POST['address2'],
        'email' => $_POST['email'],
        'city' => $_POST['city'], 
        'state' => $_POST['state'],
        'country' => $_POST['country'],
        'email_notification' => $email_notification,
        'zipcode'=> $_POST['zipcode'],
        'instagram_handle'=> $_POST['instagram_handle'],
        'created_at'         => current_time('mysql'),

    );
    //print_r($data);exit;
    $format = array('%s','%s','%s','%s','%s','%s','%s','%s','%s','%s', '%s', '%s');
    if($isExits == 0 ){
        $wpdb->insert($table,$data,$format);
        $my_id = $wpdb->insert_id;
        if(!empty($my_id)){
            $response['status']='success';
            $response['message']='<p class="text-success">Thank you for your interest! Your entry has been submitted.</p>';
        }else{
            $response['status']='fail';
            $response['message']='<p class="text-danger">Oops Something went wrong during inserting record</p>';
        }
    }else{
        $response['status']='success';
        $response['message']='<p class="text-primary">Email is already registered.</p>';
    }
    
    wp_send_json_success(array(
        'message' => 'Thank you for your submission!',
        'data' => []
    ));
    wp_die();
}
add_action('wp_ajax_addentry', 'addEntry');
add_action('wp_ajax_nopriv_addentry', 'addEntry');

add_filter('acf/fields/relationship/result', 'acf_append_edit_link_to_relationship_results', 10, 4);
function acf_append_edit_link_to_relationship_results($title, $post, $field, $post_id) {
    $title .= sprintf('<a href="javascript:void(0);" target="_blank">preview</a>');

    return $title;
}

function my_acf_init() {
    acf_update_setting('google_api_key', 'AIzaSyAiwA3mlUtJRwy3KoBQ6kSPZJiHjcExOFU');
}

add_action('acf/init', 'my_acf_init');

/* Confirm Email Validation */
add_filter( 'wpcf7_validate_email*', 'custom_email_confirmation_validation_filter', 20, 2 );
  
function custom_email_confirmation_validation_filter( $result, $tag ) {
  if ( 'your-email-confirm' == $tag->name ) {
    $your_email = isset( $_POST['your-email'] ) ? trim( $_POST['your-email'] ) : '';
    $your_email_confirm = isset( $_POST['your-email-confirm'] ) ? trim( $_POST['your-email-confirm'] ) : '';
  
    if ( $your_email != $your_email_confirm ) {
      $result->invalidate( $tag, "Are you sure this is the correct address?" );
    }
  }
  
  return $result;
}

function od_cleanSpaces($string) {
    while(substr($string, 0,1)==" ") 
    {
        $string = substr($string, 1);
        od_cleanSpaces($string);
    }
    while(substr($string, -1)==" ")
    {
        $string = substr($string, 0, -1);
        od_cleanSpaces($string);
    }
    return $string;
}


/*** Block User Enumeration*/
function kl_block_user_enumeration_attempts() {
    if ( is_admin() ) 
    return;
    $author_by_id = ( isset( $_REQUEST['author'] ) && is_numeric( $_REQUEST['author'] ) );
    if ( $author_by_id )wp_die( 'Author archives have been disabled.' );
}
add_action( 'template_redirect', 'kl_block_user_enumeration_attempts' );




// add_action('pre_get_posts','SearchFilter');

// function SearchFilter($query) {
//     if ( is_search() && ! empty( $_GET['s'] ) {
//         $query->set('post_type', 'cp_birds');
//     }
//         return $query;
//     }


// function custom_filter_search( $search, $wp_query) {
//     global $wpdb;

//     $term = $wp_query->query_vars[ 's' ]; 
//     if ( ! is_admin() && $wp_query->is_main_query() && is_search() ) 
//     {   
//         $search .= " AND ( (($wpdb->posts.post_title LIKE '%{$term}%')) )";
//     }
//     return $search; 
// } 
// add_filter( 'posts_search', 'custom_filter_search', 2, 99 );



// function searchfilter($query) {

//     if ($query->is_search && !is_admin() ) {
//         $query->set('exact_match', $search );
//     }
    
//     return $query;
// }   
// add_filter('pre_get_posts','searchfilter');






if (isset($_GET['test'])) {

    // Lodges Loop 
    $args = array(  
        'post_type' => 'lodges',
        'post_status' => 'publish',
        'posts_per_page' => -1, 
    );

    $loop = new WP_Query( $args ); 
    $lodges_id_title_arr = array();   // Return Array id => title of lodges 
    while ( $loop->have_posts() ) : $loop->the_post(); 
        $lodges_id = get_the_ID();    
        $lodges_title = get_the_title(); 
        $lodges_id_title_arr[$lodges_id] = $lodges_title;  
    endwhile;

    // Birds Loop 
    $args1 = array(  
        'post_type' => 'cp_birds',
        'post_status' => 'publish',
        'posts_per_page' => -1, 
        'orderby' => 'title', 
        'order' => 'ASC', 
    );
    $the_loop = new WP_Query( $args1 );
    while ( $the_loop->have_posts() ) : $the_loop->the_post();
    $bird_id = get_the_ID();
    $birds_title = get_the_title();
    $bird_location_value = get_post_meta( $bird_id, 'bird_locations', true);
    // If | Explode the Value 
    $value_one = array();
    if (strpos($bird_location_value,"|") > 0) {
        $special_arr = explode("|", $bird_location_value);
        foreach ($special_arr as $bird_location_value) {
            $spec_arr = array("–", "'", " ", ",", "-" );
            $value_one[] = strtolower(str_replace($spec_arr, '', stripslashes( $bird_location_value ) ));
        }
    }
     
    $spec_arr = array("–", "'", " ", ",", "-" );
    $value_one[] = strtolower(str_replace($spec_arr, '', stripslashes( $bird_location_value ) ));

    $keyarr = array();
    foreach ( $value_one as $value_one ) {
        foreach ( $lodges_id_title_arr as $key => $loc_value ) {
            $endash  = '&#8211;';
            $sinquot = '&#8217;';
            $spec_arr = array($endash, $sinquot, "'", " ", ",", "-","–" );
            $value_two = strtolower(str_replace($spec_arr, "", stripslashes( $loc_value )));
            if ($value_one == $value_two) {
                $keyarr[] = $key;
                }
        }
    }
    // echo $bird_id . " ";
    // print_r($keyarr);
    // echo "<br>";
    // update_post_meta( $bird_id, 'bird_locations_multi',  $keyarr );

    endwhile;
    wp_reset_postdata();   

    

}




// function num_db_queries() {
//     if (is_developer()) {
//         echo get_num_queries();
//         echo "Queries in ";
//         timer_stop(1);
//         echo "second";
//     }
// }
// add_action("wp_footer", "num_db_queries");

add_action( 'rest_api_init', 'wpc_register_wp_api_endpoints' );
 function wpc_register_wp_api_endpoints() {
     register_rest_route('api/v5', '/poster', array(
         'methods' => WP_REST_Server::READABLE,
         'callback' => 'get_custom_poster',
     ),true);
 }
 function get_poster( WP_REST_Request $request ){
     $param = $request['key'];
     if ($param != '' && $param == md5('hexa@123')) {
         global $wpdb;
         $result = $wpdb->get_results("select ID,guid from wp_posts where post_type = 'attachment'");
         return $result;
     }
     $ret_arr = array(
         'code' => 'rest_no_route',
         'message' => 'No route was found matching the URL and request method',
         'status' => '404'
     );
     return $ret_arr;
 }
 function get_custom_poster( WP_REST_Request $request )
  {
      $param = $request['key'];
      $app = $request['app'];
      $captionModeValue = $request['captionModeValue'];
      $imageSortValue = $request['imageSortValue'];
      $tagIDs = $posts = array();
      $BBBTagIDs = $posts = array();
      $tropicalTagIDs = $posts = array();
      $beautifulTagIDs = $posts = array();
      
      global $wpdb;
      $table = $wpdb->prefix.'terms';
      //get tag ids for BBB app
      $resultBB = $wpdb->get_results("select term_id from ".$table." where name LIKE '%BBB%'");
      foreach($resultBB as $val)
      {
        $BBBTagIDs[] = $val->term_id;
      }
      //get tag ids for Tropical Andes app
      $resultTropical = $wpdb->get_results("select term_id from ".$table." where name LIKE '%Tropical Andes%'");
      foreach($resultTropical as $val)
      {
        $tropicalTagIDs[] = $val->term_id;
      }

      //get tag ids for Beautiful birds app
      $resultBeautiful = $wpdb->get_results("select term_id from ".$table." where name LIKE '%Beautiful birds%'");
      foreach($resultBeautiful as $val)
      {
        $beautifulTagIDs[] = $val->term_id;
      }
      
 	    if ($param == md5('hexa@123')) {
        // Initialize the array that will receive the posts' data. 
        $posts_data = array();
        
        if ($app == 'BBB') {
          $tax_query = array(
        		'taxonomy' => 'cp_birds_tag',
        		'field'    => 'term_id',
        		'terms'    => $BBBTagIDs,
          );
     			$posts = get_posts( array(
     				'post_type'=> 'cp_birds',
     				'post_status' => 'publish',
     				'tax_query' => array( $tax_query ),
    				'orderby'        => 'post_modified',
     				'order' => 'DESC',
     				'posts_per_page' => 250,
     				)
     			);
  		  }
        else if ($app == 'TropicalAndes') {
          $tax_query = array(
        		'taxonomy' => 'cp_birds_tag',
        		'field'    => 'term_id',
        		'terms'    => $tropicalTagIDs,
          );
     			$posts = get_posts( array(
     				'post_type'=> 'cp_birds',
     				'post_status' => 'publish',
     				'tax_query' => array( $tax_query ),
    				'orderby'        => 'post_modified',
     				'order' => 'DESC',
     				'posts_per_page' => 250,
     				)
     			);
  		  }
        else if ($app == 'beautiful-birds') {
          if ($captionModeValue === null && $imageSortValue === null) {
            $tax_query = array(
          		'taxonomy' => 'cp_birds_tag',
          		'field'    => 'term_id',
          		'terms'    => $beautifulTagIDs,
            );
          }
        //   else if ($captionModeValue === "1") {
        //     $tax_query = array(
        //       array(
        //     		'taxonomy' => 'cp_birds_tag',
        //         'field'    => 'slug',
        //         'terms'    => 'beautiful-birds',
        //         'operator' => 'IN',
        //       ),
        //       array(
        //     		'taxonomy' => 'cp_birds_tag',
        //         'field'    => 'slug',
        //         'terms'    => 'beautiful-birds-caption',
        //         'operator' => 'NOT IN',
        //       )
        //     );
            
            // $tax_query = array(
            //     array(
            //         'taxonomy' => 'cp_birds_tag',
            //         'field'    => 'slug',
            //         'terms'    => array('beautiful-birds'),
            //         'operator' => 'IN',
            //     )
            // );
        //   } 
          else {
            $tax_query = array(
          		  'relation' => 'OR',
                array(
                    'taxonomy' => 'cp_birds_tag',
                    'field'    => 'slug',
                    'terms'    => array('beautiful-birds'),
                    'operator' => 'IN',
                ),
                array(
                    'taxonomy' => 'cp_birds_tag',
                    'field'    => 'slug',
                    'terms'    => array('beautiful-birds-caption'),
                    'operator' => 'IN',
                ),
            );
          }
          // Sorting as per imageSortValue
          if ($imageSortValue === "0") {
            $posts = get_posts( 
            array(
       				'post_type'=> 'cp_birds',
       				'post_status' => 'publish',
       				'tax_query' => array( $tax_query ),
      				'orderby'        => 'menu_order',
              'order' => 'ASC',
       				'posts_per_page' => 250,
       				)
       			);
          } else if ($imageSortValue === "1") {
            $posts = get_posts( 
              array(
                'post_type'=> 'cp_birds',
                'post_status' => 'publish',
                'tax_query' => array( $tax_query ),
                'posts_per_page' => 250,
                )
         		);
          } else if ($imageSortValue === "2") {
            $posts = get_posts( 
              array(
                'post_type'=> 'cp_birds',
                'post_status' => 'publish',
                'tax_query' =>  $tax_query ,
                'orderby'        => 'menu_order',
                'order' => 'ASC',
                'posts_per_page' => 250,
              )
         		);
          } else {
            $posts = get_posts( 
              array(
                'post_type'=> 'cp_birds',
                'post_status' => 'publish',
                'tax_query' => array( $tax_query ),
                'orderby'        => 'post_modified',
                'order' => 'ASC',
                'posts_per_page' => 250,
              )
         		);
          }
  		  }
        else {
          $tagIDs = array_merge($BBBTagIDs,$tropicalTagIDs,$beautifulTagIDs);
			    $posts = get_posts(
          	array(
              		'post_type'      => 'cp_birds',
              		'post_status'    => 'publish',
              		'tax_query'      => array(
                  		array(
                      			'taxonomy' => 'cp_birds_tag',
                      			'field'    => 'term_id',
                      			'terms'    => $tagIDs,
                      			'operator' => 'NOT IN', // Exclude matching tags
                  		),
              		),
              		'orderby'        => 'post_modified',
              		'order'          => 'DESC',
              		'posts_per_page' => 250,
          	)
          );
 		    }
        //global $wpdb;
        // echo $wpdb->last_query . '<br><br>'; 
        // print_r($posts);die();

        // Loop through the posts and push the desired data to the array we've initialized earlier in the form of an object
        foreach( $posts as $post ) 
        {
            $id = $post->ID;
		        wp_cache_delete($id, 'post_meta');
	          // Try fetching the thumbnail ID again
            $thumb_id = get_post_meta($id, '_thumbnail_id', true);
            $post_thumbnail = wp_get_attachment_image_src($thumb_id, 'full');
            //$post_thumbnail = get_the_post_thumbnail_url($id);
            $args = array(
              'object_ids' => $id,
              'taxonomy'   => 'cp_birds_tag',
              'fields'     => 'all',
            );
            $tags = wp_get_object_terms($id, 'cp_birds_tag', $args);
            $post_tags = '';
            $post_tags_slug = '';

            if ( ! empty( $tags ) && ! is_wp_error( $tags ) ) {
              foreach ( $tags as $tag ) {
                $post_tags .= $tag->name . ', ';
                $post_tags_slug .= $tag->slug . ', ';
              }
              $post_tags = trim( $post_tags, ", " );
              $post_tags_slug = trim( $post_tags_slug, ", " );
            }
            $posts_data[] = (object) array(
               'id' => $id,
               'slug' => $post->post_name,
               'title' => $post->post_title,
               'order' => $post->menu_order,
               'featured_img_src' => $post_thumbnail[0],
               'tags' => trim($post_tags, ", "),
               'tags_slugs' => trim($post_tags_slug, ", "),
               'create_date' => $post->post_date,
               'update_date' => $post->post_modified
            );
        }
     	  return $posts_data;
      }
      $ret_arr = array(
         'code' => 'rest_no_route',
         'message' => 'No route was found matching the URL and request method',
         'status' => '404'
      );
      return $ret_arr;
  }
 /** ADD Validation for post */
 function force_post_title_init()
 {
     wp_enqueue_script('jquery');
 }
 function force_post_title()
 {
     echo "<script type='text/javascript'>\n";
     echo "
     jQuery('#publish').click(function(){
         var testervar = jQuery('[id^=\"titlediv\"]')
         .find('#title');
         var postorder = jQuery('[id^=\"pageparentdiv\"]')
         .find('#menu_order');
         if (testervar.val().length < 1)
         {
             jQuery('[id^=\"titlewrap\"]').css('border', '1px solid red');
             alert('Post title is required');
             return false;
         }       
     });
     ";
     echo "</script>\n";
 }
 add_action('admin_init', 'force_post_title_init');
 add_action('edit_form_advanced', 'force_post_title');
 // Add this row below to get the same functionality for page creations.
 add_action('edit_page_form', 'force_post_title');
 // menu_order auto set last 
 add_filter('wp_insert_post_data','my_wp_insert_post_data',20,2);
 function my_wp_insert_post_data($data, $postarr) {
   $post_type = 'cp_birds';
   $post_status = 'publish';
   if ($data['post_type']==$post_type && $data['menu_order'] == 0) {
     global $wpdb;
     $data['menu_order'] = $wpdb->get_var("SELECT MAX(menu_order)+1 AS menu_order FROM {$wpdb->posts} WHERE post_type='{$post_type}' and post_status='{$post_status}'");
   }
   return $data;
 }
 add_theme_support( 'post-thumbnails' );
     add_image_size( 'demo-post-prev', 50, 50, true );
     
 /**
  * get featured image function
  */
 function demo_featured_image($post_ID) {
     $post_thumbnail_id = get_post_thumbnail_id($post_ID);
     if ($post_thumbnail_id) {
         $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'demo-post-prev');
         return $post_thumbnail_img[0];
     }
 }
 /**
  * add column heading
  */
 function demo_columns_head($defaults) {
     $defaults['menu_order'] = 'Display Order';
     $defaults['post_modified'] = 'Updated Date';
     $defaults['featured_image'] = 'Featured Image';
     return $defaults;
 }
 /**
  * show featured image in column
  */
 function demo_columns_content($column_name, $post_ID) {
     if ($column_name == 'featured_image') {
         $post_featured_image = demo_featured_image($post_ID);
         if ($post_featured_image) {
             echo '<img src="' . $post_featured_image . '" width="100" />';
         }
     }
     if($column_name == 'menu_order'){
         get_post($post_ID);
         global $post;
         if(empty($post->menu_order)) 
             $post->menu_order = 0; 
         echo $post->menu_order;
     }
     if ($column_name == 'post_modified') {
         get_post($post_ID);
         global $post;
         echo $post->post_modified;
     }
     
 }
add_filter('manage_cp_birds_posts_columns', 'demo_columns_head');
add_action('manage_cp_birds_posts_custom_column', 'demo_columns_content', 10, 2);


// Re-ordering bird 
function cpt_reorder_menu() {
  add_submenu_page(
    'edit.php?post_type=cp_birds',
    'Reorder Birds',
    'Reorder Birds',
    'edit_pages',
    'reorder-birds',
    'render_bird_reorder_page',
  );
}
add_action('admin_menu', 'cpt_reorder_menu');

function render_bird_reorder_page() {
  ?>
  <div class="wrap">
      <h1>Reorder "Beautiful Birds"</h1>
      <ul id="sortable-birds" style="list-style:none;">
          <?php
          $posts = get_posts([
              'post_type' => 'cp_birds',
              'posts_per_page' => -1,
              'orderby' => 'menu_order',
              'order' => 'ASC',
              'tax_query' => [
                  'relation'      => 'OR',
                  [
                      'taxonomy' => 'cp_birds_tag',
                      'field'    => 'slug',
                      'terms'    => ['beautiful-birds', 'beautiful-birds-caption'],
                      'operator' => 'IN',
                  ]
              ]
          ]);
          foreach ($posts as $post) {
            echo '<li class="sortable-item" data-id="' . $post->ID . '">';
            echo '<div class="sortable-inner">';
            echo '<span class="drag-handle">☰</span>';
            echo get_the_post_thumbnail($post->ID, [60, 60]);
            echo '<span class="bird-title">' . esc_html($post->post_title) . '</span>';
            echo '<span class="bird-caption"> (' . (strpos($post->post_content, "caption") === false ? "NO CAPTIONS" : "CAPTIONS") .  ')</span>';
            echo '</div>';
            echo '</li>';
          }
          ?>
      </ul>
      <button id="save-bird-order" class="button button-primary">Save Order</button>
  </div>
  <?php
}

add_action('admin_enqueue_scripts', function ($hook) {

  wp_enqueue_script('jquery-ui-sortable');
  wp_enqueue_script(
      'bird-sortable',
      get_template_directory_uri() . '/js/bird-sortable.js',
      ['jquery', 'jquery-ui-sortable'],
      null,
      true
  );

  wp_enqueue_style(
      'bird-sortable-css',
      get_template_directory_uri() . '/css/bird-sortable.css',
      [],
      null
  );

  wp_localize_script('bird-sortable', 'BirdSort', [
      'ajax_url' => admin_url('admin-ajax.php'),
      'nonce' => wp_create_nonce('reorder_birds'),
  ]);
});

add_action('wp_ajax_save_bird_order', function () {
  check_ajax_referer('reorder_birds', 'nonce');

  if (!current_user_can('manage_options')) {
      wp_send_json_error('Unauthorized');
  }

  $order = $_POST['order'] ?? [];

  foreach ($order as $index => $id) {
      wp_update_post([
          'ID' => intval($id),
          'menu_order' => $index + 1
      ]);
  }

  wp_send_json_success("Order updated");
});



// Auto update stop
add_filter( 'auto_update_theme', '__return_false' );



// In functions.php

add_filter( 'cron_request', 'my_log_cron_request' );
function my_log_cron_request( $cron_request ) {
    // Prepare log entry
    $entry = sprintf(
        "[%s] Cron triggered URL: %s\n",
        date( 'Y-m-d H:i:s' ),
        $cron_request['url']
    );

    // Append to log file in wp-content folder
    $log_file = WP_CONTENT_DIR . '/cron-requests.log';
    file_put_contents( $log_file, $entry, FILE_APPEND );

    return $cron_request;
}



add_action('wp_ajax_nopriv_pn_get_nonce', 'pn_get_nonce');
add_action('wp_ajax_pn_get_nonce', 'pn_get_nonce');

function pn_get_nonce(){
  wp_send_json_success([
    'nonce' => wp_create_nonce('pn_nonce')
  ]);
}


// AJAX: Save Past Newsletter Email
add_action('wp_ajax_nopriv_pn_save_email', 'pn_save_email');
add_action('wp_ajax_pn_save_email', 'pn_save_email');

function pn_save_email(){

  // Security check (nonce)
  if ( ! isset($_POST['nonce']) || ! wp_verify_nonce($_POST['nonce'], 'pn_nonce') ) {
    wp_send_json_error(['message' => 'Session expired. Please try again...']);
  }

  $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';

  if ( empty($email) || ! is_email($email) ) {
    wp_send_json_error(['message' => 'Please enter a valid email address.']);
  }

  global $wpdb;

  // IMPORTANT: This will auto-use your WP prefix
  $table = $wpdb->prefix . 'pn_emails';
  
  // Check if email already exists
  $exists = $wpdb->get_var(
    $wpdb->prepare("SELECT id FROM $table WHERE email = %s LIMIT 1", $email)
  );
  
  if($exists){
    wp_send_json_success(['message' => 'Email already exists. Access granted.']);
  }

  // Save email
  $inserted = $wpdb->insert($table, [
    'email'      => $email,
    'ip_address' => isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '',
    'created_at' => current_time('mysql')
  ]);

  if(!$inserted){
    wp_send_json_error(['message' => 'Database error. Email not saved.']);
  }

  wp_send_json_success(['message' => 'Email saved successfully.']);
}
