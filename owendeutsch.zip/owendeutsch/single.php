<?php
	get_header();
	if( have_posts() ) : while( have_posts() ) : the_post();
?>
	<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
		<div class="container inner-page-outer single-blog-page">

			<div class="row">
				<div class="col-xs-12 col-sm-12">
					<?php the_title( '<div class="post-title"><h1>', '</h1></div>' ); ?>
				</div>
			</div>
			
			<div class="row">
				<div class="col-xs-12">
					<div class="story">
						<div class="post-info clearfix">
                                                    <span class="post-date"><?php the_time( 'F j, Y' ); ?></span>
                                                    <?php if(is_sticky() ) { ?> <span class="post-sticky">Sticky</span>  <?php } ?>
						</div>
						<?php if(has_post_thumbnail() ) : ?>
                                                    <div class="post-image">
                                                            <?php the_post_thumbnail(); ?>
                                                    </div>
						<?php endif; ?>
						<div class="story-content clearfix">
                                                    <?php the_content(); ?>
						</div>
						<div class="comment-template">
							<?php //comments_template(); ?>
						</div>
					</div>
				</div>
			</div>

		</div>
	</div>
<?php endwhile; else: ?>
	
	<h2 class="error"><?php _e( 'Not Found.','theme' ); ?></h2>
	<p class="error">Sorry, but you are looking for something that isn't here.</p>
	
<?php
	endif; wp_reset_query(); wp_reset_postdata();
	get_footer();
?>