<?php
/**
 * Taxonomy template
 * 
 */
get_header();
?>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/fancybox-common.css">
<?php
  $taxonomy   = get_query_var( 'taxonomy' );
  $term       = get_term_by( 'slug', get_query_var('term'), get_query_var('taxonomy'));
  $term_name  = get_query_var( 'term' );
?>
<div class="inner-page-outer gallery-inner">
  <div class="large-container">
    <div class="location-single">
      <h2 class="large"><span>LOCATION :</span> <?php echo $term->name; ?></h2>
    </div>
    <?php $cur_country_name = strtolower($term->name); $country_url = site_url() . '/?s=&country='.$term->term_id; ?>
    <?php if(!empty(get_field('taxonomy_page_info','option'))) { ?>
            <div class="taxononmy-heading">
                <h3><?php echo get_field('taxonomy_page_info','option'); ?></h3>
            </div>
    <?php } ?>
      	<ul class="massonary">
          <?php 
              $post_repeater 	= get_field('post_schedule', $term);
              if(!empty($post_repeater)){
                  foreach ($post_repeater as $key=>$row) {
                      if(isset($post_repeater[$key]['display_post']) && is_array($post_repeater[$key]['display_post']) ){
                        foreach($post_repeater[$key]['display_post'] as $innerkey => $tpost){ 
                          //pr($tpost);
                          $tpost_terms =  wp_get_post_terms($tpost->ID, 'cp_birds_country', array("fields" => "ids"));
                          if($tpost_terms[0] != $term->term_id){
                            unset($post_repeater[$key]['display_post'][$innerkey]);
                          }
                        }
                      }
                      
                      if(!isset($post_repeater[$key]['display_post'])&& empty($post_repeater[$key]['display_post'])) {
                          unset($post_repeater[$key]);  
                      }else{
                        $post_repeater[$key]['postdate'] = $row['postyear'].'-'.$row['postmonth']; 
                      }
                            
                  }  /*Foreach loop*/

                  //pr($post_repeater);
                  $post_fount = 0;
                  $current_date   = date('Y-m');
                  $current_date   = date('Y-m',strtotime(date('Y-m',strtotime($current_date)).' + 1 month'));
                  
                  while($post_fount == 0) {    
                    
                    $current_date = date('Y-m',strtotime(date('Y-m',strtotime($current_date)).' - 1 month'));
                    
                    for( $i=0;$i<count($post_repeater);$i++){
                      // if(!empty($post_repeater[$i]['display_post'])){
                      //   pr($post_repeater[$i]['display_post']);
                      // }
                      if ( (strtotime($post_repeater[$i]['postdate']) == strtotime($current_date)) && (!empty($post_repeater[$i]['display_post'])) ){

                          //pr("postnotempty");
                          $post_fount =1;
                          foreach ($post_repeater[$i]['display_post'] as $key => $row) { 
                            $taxonomyTerms = wp_get_post_terms($row->ID, $taxonomy, array("fields" => "ids"));
                            //pr($taxonomyTerms);
                            if( $term->term_id != $taxonomyTerms[0]){ 
                              unset($post_repeater[$i]['display_post'][$key]);
                            }
                          }
                          $c = $post_repeater[$i]['display_post'];
                          $count_v = count($c)-1;
                          foreach (array_values($post_repeater[$i]['display_post']) as $key => $row) {
                            $lastclass = '';
                            if($count_v == $key ){ 
                              $lastclass = "last_bird_class"; 
                            }
                            $medium_thumbnail         = wp_get_attachment_image_src( get_post_thumbnail_id( $row->ID ), 'country-large' );
                            $medium_thumbnail_url     = !empty( $medium_thumbnail[0] ) ? $medium_thumbnail[0] : '';
                            $iframedata = get_field('bird_sounds', $row->ID );
                            ?>
                                <li class="country-list-outer" data-post-id="<?php echo $row->ID; ?>">
                                    <div class="grid-item1" href="<?php echo get_the_post_thumbnail_url( $row->ID, 'full' ); ?>" data-fancybox="imagescountry" data-type="image">
                                    <div class="image-title">
                                            <?php echo $row->post_title; ?>
                            </div>  
                            <script>
                              console.log('hello');
                            </script>
                                        <div class="image-outer-table">
                                            <div class="image">
                                              <img class="img-fluid" src="<?php echo $medium_thumbnail_url; ?>" title="<?php echo $row->post_title; ?>">
                                            </div>
                                        </div>
                                        <figcaption>
                                        <div class="countrydetails <?php //echo $lastclass; ?>">
											                     <h4><?php echo $row->post_title; ?></h4>
											                     <?php /*<h3><?php echo "ID : " . $row->ID; ?></h3>*/ ?>
                                           <div class="custom-table">
                                            <div class="row">
                                              <div class="col-md-6">
                                                <?php 
                                                    $get_order = get_field('bird_family',$row->ID);
                                                    if(!empty($get_order)){ 
                                                    $search_order = mb_strtolower($get_order);
                                                    $search_order_url = site_url() . '/?s=&birdfamily='.$search_order;
                                                  ?>
                                                    <h5>Order</h5>
                                                    <a href="<?php echo $search_order_url; ?>" class="whitebtn"><?php echo $search_order; ?></a>
                                                  <?php } ?>
                                              </div>
                                              <div class="col-md-6">
                                                  <?php 
                                                    $get_family = get_field('bfamily',$row->ID);
                                                    if(!empty($get_family)){ 
                                                    $search_get_family = mb_strtolower($get_family);
                                                    $search_family_url = site_url() . '/?s=&family='.$search_get_family;
                                                  ?>
                                                    <h5>Family</h5>
                                                    <a href="<?php echo $search_family_url; ?>" class="whitebtn"><?php echo $search_get_family; ?></a>
                                                  <?php } ?>
                                              </div>
                                            </div>
                                            <div class="row">
                                              <div class="col-md-6">
                                                <h5>Genus <span>(Similar Species)</span>
                                                  <?php
                                                  $gettxgenus = get_field('bird_taxonomic_genus',$row->ID);
                                                    if(!empty($gettxgenus)) { 
                                                    $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.strtolower($gettxgenus);
                                                  ?>
                                                  
                                                    <div class="specbtn">
                                                      <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo $gettxgenus; ?></a>
                                                    </div>
                                                  <?php } ?>
                                              </div>
                                              <?php if(!empty(get_field('bird_scientific_name',$row->ID))) { ?>
                                                <div class="col-md-6">
                                                  <h5>Scientific Name</h5>
                                                  <h6><?php echo get_field('bird_scientific_name',$row->ID); ?></h6>
                                                </div>
                                            <?php } ?>
                                            </div>
                                           </div>
                                            <ul>
                                              <?php
                                                /*
                                              <li>
                                                
                                                 if(!empty(get_field('bird_scientific_name',$row->ID))) { ?>
                                                    <h5>Scientific Name</h5>
                                                    <h6><?php echo get_field('bird_scientific_name',$row->ID); ?></h6>
                                                
                                                  <?php }
                                                    $gettxgenus = get_field('bird_taxonomic_genus',$row->ID);
                                                    if(!empty($gettxgenus)) { 
                                                    $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.strtolower($gettxgenus);
                                                  ?>
                                                  
                                                    <div class="specbtn">
                                                      <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo "Similar Species"; ?></a>
                                                    </div>
                                                  <?php } 
                                                   
                                              </li>
                                               */
                                                  ?>
                                                <?php
                                                    $get_cs = get_field('bird_conservation_status',$row->ID);
                                                    if(!empty($get_cs)) { 
                                                    $search_cs = strtolower($get_cs);
                                                    $search_cs_url = site_url() . '/?s=&conservancy='.$search_cs;
                                                ?>
                                                        <li>
                                                            <h5>Conservation Status</h5>
                                                            <a class="whitebtn" href="<?php echo $search_cs_url; ?>" target="_self"><?php echo $get_cs; ?></a>
                                                        </li>
                                              <?php } ?>
                                            </ul>
                                            <div class="border-bottom-bird">
                                                <div class="row asdcc">
                                            <?php 
                                                $postid = '';
                                                $scurl  = '';
                                                $terms = wp_get_post_terms($row->ID, 'cp_birds_country');
                                                if( !empty( $terms ) && !is_wp_error( $terms ) ) {
                                                    $taxonomy = $terms[0]->name;
                                                    $taxonomyid = $terms[0]->term_id;
                                                    $scurl = site_url() . '/?s=&country='.strtolower($taxonomyid);
                                                    ?>  
                                                    <div class="col-md-6 last-child">
                                                        <h5>Country</h5>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php echo $taxonomy; ?></a>
                                                            <a href="<?php echo site_url().'/countries/'; ?>" class="whitebtn">
                                                            View more Countries
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                }
                                            ?>
                                            <?php if (!empty(get_field('state',$row->ID))){ ?>
                                                    <div class="col-md-6">
                                                        <h5>State</h5>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php the_field('state',$row->ID); ?></a>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                }
                                            ?>
                                            </div>
                                        </div>
                                              <?php if ((!empty(get_field('bird_gender',$row->ID))) || (!empty(get_field('bird_age',$row->ID)))){ ?>
                                            <div class="border-bottom-bird">
                                              <div class="row">
                                                
                                                
                                                  <?php if(!empty(get_field('bird_gender',$row->ID))){ ?>
                                                   <div class="col-md-6 last-child">
                                                        <h5>Gender </h5>
                                                        <h6><?php echo get_field('bird_gender',$row->ID); ?></h6>
                                                    </div>
                                              <?php } ?>
                                                

                                                  <?php if(!empty(get_field('bird_age',$row->ID))) { ?>
                                                  <div class="col-md-6">
                                                    <h5>Age</h5>
                                                    <h6><?php echo get_field('bird_age',$row->ID); ?></h6>
                                                  </div>
                                              <?php } ?>
                                                
                                              </div>
                                            </div>
                                            <?php } ?>
                                              <ul>
                                              <?php
                                                  $get_vc = get_field('bird_visual_country',$row->ID);
                                                  if(!empty($get_vc)){ 
                                                  $search_vc = strtolower($get_vc);
                                                  $search_vc_url = site_url() . '/?s=&visualcategory='.$search_vc;
                                              ?>
                      											    <li>
                      											        <h5>Visual Category</h5>
                      											        <a class="whitebtn" href="<?php echo $search_vc_url; ?>" target="_self"><?php echo $get_vc; ?></a>
                      											    </li>
                                              <?php } 
                                                $getloc = get_field('bird_locations_multi',$row->ID);
                                                if(!empty($getloc) && isset($getloc)) { ?>
                                                <li>
                                                  <h5>Birding Sites and Lodges</h5>
                                                  <?php 
                                                    if($getloc != ''){
                                                      foreach ($getloc as $post) {
                                                        // Check if POST_TITLE is set before echoing
                                                        if (isset($post->post_title)) {
                                                          $getlocurlMulti = od_location_search_url( $post->post_title );
                                                          ?>
                                                          <a class="whitebtn" href="<?php echo $getlocurlMulti ?>" target="_self">
                                                              <?php echo $post->post_title; ?>
                                                          </a>
                                                          <?php
                                                        }
                                                        if(!empty($post) && !isset($post->post_title)) {
                                                          $get_title_lodges = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($post) AND post_status = 'publish'", ARRAY_N);
                                                          $lodges_postidtit = array_column($get_title_lodges, 0);
                                                          $getlocurlMulti = od_location_search_url( $lodges_postidtit[0] );
                                                          ?>
                                                          <a class="whitebtn" href="<?php echo $getlocurlMulti; ?>" target="_self">
                                                              <?php echo $lodges_postidtit[0]; ?>
                                                          </a>
                                                          <?php
                                                        }
                                                      }
                                                    }
                                                  ?>
                                                </li>
                                              <?php } ?>
                                              <?php 
                                                /*  $get_order = get_field('bird_family',$row->ID);
                                                  if(!empty($get_order)){ 
                                                  $search_order = strtolower($get_order);
                                                  $search_order_url = site_url() . '/?s=&birdfamily='.$search_order;
                                                  ?>
                                                <li>
                      											        <h5>Order</h5>
                      											        <a class="whitebtn" href="<?php echo $search_order_url; ?>" ><?php echo $get_order; ?></a>
                                                </li>
                                              <?php } */
                                                $get_activity = get_field('bird_activity',$row->ID);
                                                if(!empty($get_activity) && isset($get_activity)) { ?>
                                                      <li>
                                                          <h5>Activity</h5>
                                                          <?php
                                                              if($get_activity != ''){
                                                                $explodeactivity = explode(",",$get_activity);
                                                                foreach ($explodeactivity as  $activityrow) {
                                                                    $search_activityurl = site_url() . '/?s=&activity='.$activityrow;
                                                          ?>
                                                                  <a class="whitebtn" href="<?php echo $search_activityurl; ?>" >
                                                                    <?php echo $activityrow; ?>
                                                                </a>
                                                          <?php } } ?>
                                                      </li>
                                              <?php } ?>
                      											</ul>
                                            <?php 
                                                //if(!empty($get_activity) && isset($get_activity)) { ?>
                                                    <div class="custom-table new-cat">
                                                       <div class="row">
                                                            <?php
                                                              if( have_rows('categories', $row->ID) ):
                                                                  while ( have_rows('categories', $row->ID) ) : the_row();
                                                                      if( get_row_layout() == 'category' ): 
                                                                          $name = get_sub_field('name');
                                                                          $value = get_sub_field('value'); ?>
                                                                          <div class="col-md-6">
                                                                              <h5><?php echo $name; ?></h5>
                                                                              <a class="whitebtn" href="<?php echo $search_activityurl; ?>" ><?php echo $value; ?></a>
                                                                          </div>
                                                                     <?php
                                                                      endif;                                      
                                                                  endwhile;
                                                              else :                                      
                                                              endif;
                                                            ?>
                                                        </div>
                                                    </div>
                                              <?php //} ?>
                                            <?php if(!empty($iframedata)){?>
                                              <h5>BIRD CALLS</h5>
                                              <div class="iframeappend">
                                                  <?php $removelastcomma = rtrim($iframedata, ','); ?>
                                                  <input type="hidden" id="custId" name="custId" value="<?php echo $removelastcomma; ?>">
                                                  <img class="iframeloader" src="<?php echo get_template_directory_uri(). '/images/loader.svg'; ?>" alt="Page Loader">
                                              </div>
                                            <?php } ?>
										                    </div>
                                        </figcaption>
                                        
                                        
                                    </div>
                                
                                </li>
                            <?php
                          }
                          break; 
                      }
                    }
                    //break; /*Foreach loop*/
        	      }/*While loop*/ 
              } /*Main If statement*/
        ?>
      </ul>
    <div class="view-another">
        <div class="pull-left">
          <a href="<?php echo home_url(); ?>/countries/#grid-view">
            <?php echo get_field('taxonomy_page_link_title','option'); ?>
          </a>
        </div>
        <div class="pull-right">
          <a href="<?php echo $country_url; ?>" target="_self" title="<?php echo $term->name; ?>">
            <?php echo "see all my birds from ". $term->name; ?>
          </a>
        </div>
        <input type="hidden" id="taxonomy_url" name="taxonomy_url" value="<?php echo $cur_country_name; ?>">
        <!-- <input type="hidden" id="taxonomy_url" name="taxonomy_url" value="<?php //echo $term_name; ?>"> -->
      </div>
    </div>
  </div>
  <?php $url = get_site_url();?>
  <script>
    var $ = jQuery;
    var siteUrl = '<?php echo $url; ?>';
    var curcname = '<?php echo strtolower($term->name); ?>';
    function functionname(){
      window.location.href = siteUrl+'/countries';
    }
    //$( document ).ready( function() {
      //$('.last_bird_class').append("<a href='"+siteUrl+"/countries/' class='country_btn'>View more Countries</a><a href='"+siteUrl+"/?s=&country="+curcname+"' class='country_btn'>See all birds from "+curcname+"</a>");
      // $('.last_bird_class').append("<a href='"+siteUrl+"/?s=&country="+curcname+"' class='country_btn'>See all birds from "+curcname+"</a>");
    //});
  </script>
  <style>
    .country-list-outer{
        min-height: 250px;
        max-height: 250px;
    }
    .country-list-outer .image-title{
        text-align: left !important;
        padding-right: 0px !important
    }
    .country-list-outer .image-title{
        position:absolute !important;
        display: none;
    }
    .country-list-outer:hover .image-title{
        display: block;
    }
</style>
  <?php get_footer(); ?>