<?php

global $wpdb;
get_header();
?>
<link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/fancybox-common.css">
<?php

get_header();




$search         = stripcslashes(isset($_GET['s'])) ? $_GET['s'] : '';
$str = $search;
$array = explode('.', $str);
$las_char = end($array);
if(is_numeric($las_char)){
    array_pop($array);
}
$search_new = implode(".",$array);
$searches = $search_new;
$country        = stripcslashes(isset($_GET['country'])) ? $_GET['country'] : '';
$gender         = isset($_GET['gender']) ? $_GET['gender'] : '';
$minage         = isset($_GET['minage']) ? $_GET['minage'] : '';
$age            = isset($_GET['age']) ? $_GET['age'] : '';
$maxage         = isset($_GET['maxage']) ? $_GET['maxage'] : '';
$conservancy    = stripcslashes(isset($_GET['conservancy'])) ? $_GET['conservancy'] : '';
$activity_value = stripcslashes(isset($_GET['activity'])) ? $_GET['activity'] : '';
$birdfamily     = stripcslashes(isset($_GET['birdfamily'])) ? $_GET['birdfamily'] : '';
$taxonomicgenus = stripcslashes(isset($_GET['taxonomicgenus'])) ? $_GET['taxonomicgenus'] : '';
$locations      = stripcslashes(isset($_GET['locations'])) ? $_GET['locations'] : '';
$visualcategory = stripcslashes(isset($_GET['visualcategory'])) ? $_GET['visualcategory'] : '';
$familycategory = stripcslashes(isset($_GET['family'])) ? $_GET['family'] : '';
$sorting_option = stripcslashes(isset($_GET['sorting_option'])) ? $_GET['sorting_option'] : '';
$exit = 0;
if(!empty($searches) || !empty($country) || !empty($gender) || !empty($age) || !empty($minage) || !empty($maxage) || !empty($conservancy) || !empty($activity_value) || !empty($birdfamily) || !empty($taxonomicgenus) || !empty($locations) || !empty($visualcategory) || !empty($familycategory))  {
    $exit = 1;
}
?>

<style>
    select#sorting_option {
        position: relative;
        left: unset;
        top: 10px;
        padding: 15px 10px 15px 10px;
        border-radius: 50px;
        border: 0;
        font-weight: 500;
        margin: 0;
        width: 100%;
    }
    div#radio_buttons {
        display: flex;
        align-items: center;
        justify-content: space-evenly;
        margin: 10px 0 0 0;
    }
    input[name='sorting_option']:before {
        content: '';
        display:block;
        width:60%;
        height:60%;
        margin: 20% auto;
        border-radius:50%;
        /* background: white; */
    }

    input[name='sorting_option']:checked:before {
        background: #fff600;
    }

    input[name='sorting_option'] {
        -webkit-appearance: none;
        width: 15px;
        height: 15px;
        border: 1px solid #fff600;
        border-radius: 50%;
        outline: none;
        box-shadow: 0 0 5px 0px grey inset;
        margin-right: 4px;
    }
    div#radio_buttons label {
        font-size: 14px;
        font-weight: 500;
        color: white;
    }

    div#radio_buttons .form-check {
        display: flex;
        align-items: flex-start;
    }
</style>
<div class="inner-page-outer search">
    <div class="container-search text-center">
        <div class="row">
            <div class="col-md-12">
                <h1 class="large search-title">Search</h1>
            </div>
        </div>
        <?php 
            $search_subline = get_field('search_subline','option'); 
            $filter_heading = get_field('search_filter_heading','option'); 
            $filter_subtitles = get_field('search_filter_subtitles','option'); 
            if(!empty($search_subline)){ ?>
                <div class="needhelp"><a href="/faq/#collapse1"><?php echo $search_subline; ?></a></div>
        <?php } 
            $search_short_content = get_field('search_short_content','option');
            if(!empty($search_short_content)){ 
            ?>
                <p><?php echo $search_short_content; ?></p>
            <?php } 
                
        ?>
        <div class="search-group">
            <div class="search-input">
                <form action="javascript:;" method="get" id="my-ajax-filter-search">
                        <input id="searchfocus" class="search-text" type="text" name="s" placeholder="Enter bird species name or keywords" value="<?php echo $searches; ?>" autofocus>
                        <div id="radio_buttons">
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="sorting_option" id="sorting_option3" value="by_tags" <?php echo ( !empty($sorting_option) && $sorting_option=='by_tags' ) ? 'checked' : '';  ?>>
                                <label class="form-check-label" for="sorting_option3">
                                    Location
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="sorting_option" id="sorting_option2" value="exact_match" <?php echo ( !empty($sorting_option) && $sorting_option=='exact_match' || (!isset($_GET['sorting_option'])) || ( empty($sorting_option )) ) ? 'checked' : '';  ?>>
                                <label class="form-check-label" for="sorting_option2">
                                    Bird Name
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="sorting_option" id="sorting_option1" value="contain" <?php echo ( (!empty($sorting_option) && $sorting_option=='contain')) ? 'checked' : '';  ?>>
                                <label class="form-check-label" for="sorting_option1">
                                    Species
                                </label>
                            </div>
                        </div>

                        <input type="submit" id="search_birds" />
                    </form>
                <span><img src="<?php echo site_url(); ?>/wp-content/uploads/2019/04/search-icon.png" alt="search"></span>
            </div>
            
        </div>
        <div class="filterblock">
            <?php if(!empty($filter_heading)) {  ?>
                <h3><?php echo $filter_heading; ?></h3>
            <?php } if(!empty($filter_subtitles)) { ?>
                <h6><?php echo $filter_subtitles; ?></h6>
            <?php } ?>
        </div>
        <div class="search-filter-outer" >
            <!-- Country column  -->
            <div class="search-filter-col">
                <div class="country-filter dropdown">
                    <div class="custom-dropdown <?php if($country) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="selected" class="active">Country</span>
                    </div>
                    <ul class="dropdown-menu">
                        <?php //$terms = get_terms( 'cp_birds_country', array( 'hide_empty' => true) ); ?>
                        <?php $terms = get_terms( array(
                                                        'order'      => 'ASC',
                                                        'hide_empty' => true,
                                                        'exclude'    => array( 994 ),
                                                        'taxonomy'   => 'cp_birds_country',
                                                    )); ?>
                            <?php 
                            
                                foreach ($terms as $term) {
                                    ?>

                                        <li <?php if($country == strtolower($term->term_id)) { echo 'class=active'; } ?>>
                                            <a href="javascript:void(0);" data-countryfilter="<?php echo strtolower($term->term_id); ?>"><?php echo strtolower($term->name); ?></a>
                                        </li>
                                    <?php
                                    
                                }
                               
                            ?>
                    </ul>
                </div>
            </div>

            <!--Order Column-->
            <div class="search-filter-col">
                <div class="bird-family-filter dropdown">
                    <div class="custom-dropdown <?php if($birdfamily) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="birdfamilyselected">Order</span>
                    </div>
                    <?php
                        $bird_family_arr = [];
                        $bird_family = get_meta_values( 'bird_family', 'cp_birds' );
                        asort($bird_family);
                        if( !empty( $bird_family ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Order</a></li>-->
                                    <?php
                                        foreach( $bird_family as $key => $bird_family_value ){
                                            if( !empty($bird_family_value) && !in_array(trim($bird_family_value), $bird_family_arr)){
                                                ?>
                                                <li <?php if($birdfamily == strtolower($bird_family_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-bird-family="<?php echo strtolower($bird_family_value); ?>">
                                                        <?php echo strtolower($bird_family_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                                $bird_family_arr[] =  trim($bird_family_value);
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>

            <!-- Visual Category Column  -->
            <div class="search-filter-col">
                    <div class="visualcategory-filter dropdown">
                        <div class="custom-dropdown <?php if($visualcategory) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                            <span id="visualcategoryselected">Visual Category</span>
                        </div>
                        <?php
                            $bird_visualcategory = get_meta_values( 'bird_visual_country', 'cp_birds' );
                            asort($bird_visualcategory);
                            if( !empty( $bird_visualcategory ) ) {
                                ?>
                                    <ul class="dropdown-menu">
                                        <!--<li><a href="javascript:void(0);">Visual Category</a></li>-->
                                        <?php
                                            foreach( $bird_visualcategory as $key => $bird_visualcategory_value ){
                                                if( !empty($bird_visualcategory_value) ){
                                                    ?>
                                                    <li <?php if($visualcategory == strtolower($bird_visualcategory_value)) { echo 'class=active'; } ?>>
                                                        <a href="javascript:void(0);" data-bird-visualcategory="<?php echo strtolower($bird_visualcategory_value); ?>">
                                                            <?php echo strtolower($bird_visualcategory_value); ?>
                                                        </a>
                                                    </li>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </ul>
                                <?php
                            }
                        ?>
                    </div>
            </div>

           <!-- Locations Multi column  -->
           <div class="search-filter-col">
                    <div class="locations-filter dropdown">
                        <div class="custom-dropdown <?php if($locations) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                            <span id="locationselected">Birding Sites and Lodges</span>
                        </div>
                        <?php 
                            $bird_locations_multi = get_meta_values( 'bird_locations_multi', 'cp_birds');
                    
                            $postidofmulti = array();
                            foreach ($bird_locations_multi as $key => $data) {
                                $test = unserialize($data);
                                if($test){
                                    $postidofmulti = array_merge($postidofmulti, $test);
                                }   
                            }
                             
                            $value_id = implode(",", $postidofmulti);
                            global $wpdb;
                            $get_title = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($value_id) AND post_status = 'publish'", ARRAY_N);
                            $postidtit = array_column($get_title, 0);

                            asort($postidtit);
                                if(!empty($postidtit)){
                                    ?>
                                    <ul class="dropdown-menu">
                                        <?php
                                            foreach (array_unique($postidtit) as $key => $value) {
                                                if (!empty($value)) {
                                                    ?>
                                                        <li <?php if(isset($locations)){  if($locations == strtolower($value)) { echo 'class=active'; } } ?>> 
                                                            <a href="javascript:void(0);" data-bird-locations="<?php  echo strtolower($value); ?>">
                                                            <?php echo $value; ?>
                                                            </a>
                                                        </li>
                                                    <?php
                                                }
                                            }
                                        ?>
                                    </ul>
                                    <?php
                                }
                            
                        ?>
                    </div>
            </div>           

            <!-- Family Column  -->
            <div class="search-filter-col">
                <div class="family-filter dropdown">
                    <div class="custom-dropdown <?php if($familycategory) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="familycategoryselected">Family</span>
                    </div>
                    <?php
                        $bird_familycategory = get_meta_values( 'bfamily', 'cp_birds' );
                        asort($bird_familycategory);
                        if( !empty( $bird_familycategory ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Visual Category</a></li>-->
                                    <?php
                                        foreach( $bird_familycategory as $key => $bird_familycategory_value ){
                                            // pr($bird_familycategory_value);
                                            if( !empty($bird_familycategory_value) ){
                                                ?>
                                                <li <?php if($familycategory == mb_strtolower($bird_familycategory_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-bird-familycategory="<?php echo mb_strtolower($bird_familycategory_value); ?>">
                                                        <?php echo mb_strtolower($bird_familycategory_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>

            <!-- Activity column  -->
            <div class="search-filter-col">
                <div class="activity-filter dropdown">
                    <div class="custom-dropdown <?php if($activity_value) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="activityselected" class="activityselectedseachphp33">Activity</span>
                    </div>
                    <?php 
                        $allBirdactivity = array();
                        
                        $bird_activity = get_meta_values( 'bird_activity', 'cp_birds' );
                        foreach($bird_activity as $activity){ 
                            $new =array();
                                $new =explode(",",$activity);
                                foreach($new as $new_item){
                                    //$allBirdactivity[] = $new_item;
                                    $allBirdactivity[] = strtolower(trim($new_item));
                                }
                              
                            }
                        if( !empty( $allBirdactivity ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Activity</a></li>-->
                                    <?php
                                        foreach( array_unique($allBirdactivity) as $key => $bird_activity_value ){
                                            if( !empty($bird_activity_value) ){

                                                ?>
                                                <li <?php if($activity_value == strtolower($bird_activity_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-bird-activity="<?php echo strtolower($bird_activity_value); ?>">
                                                        <?php echo strtolower($bird_activity_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>

            <!-- Conservancy column  -->
            <div class="search-filter-col">
                <div class="conservancy-filter dropdown">
                    <div class="custom-dropdown <?php if($conservancy) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="conservancyselected">Conservation Status</span>
                    </div>
                    <?php  $getseqs = get_field('field_5d5a95442afc6','option');
                        $seqs = explode('<br />',$getseqs);
                        
                        foreach($seqs as $s){ 
                            $temp =  trim($s);
                            $seq[] = strtolower($temp);
                            } 
                        //$seq  = array('leastconcern','nearthreatened','vulnerable','endangered','criticallyendangered');  // small later and without space
                        $bird_conservancy = get_meta_values( 'bird_conservation_status', 'cp_birds' );
                        foreach ($seq as $row) {
                           foreach($bird_conservancy as $k => $cons)
                           {   // echo $row  .'=='. str_replace(' ','',strtolower($cons)).'<br>';
                                if($row  == str_replace(' ','',strtolower($cons))){
                                     $result[] = $cons;  break;
                                }
                               
                           }
                        }
                      
                        asort($bird_conservancy);
                        if( !empty( $result ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Conservation Status</a></li>-->
                                    <?php
                                        foreach( $result as $key => $bird_conservancy_value ){
                                            if( !empty($bird_conservancy_value) ){
                                                ?>
                                                <li <?php if($conservancy == strtolower($bird_conservancy_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-bird-conservancy="<?php echo strtolower($bird_conservancy_value); ?>">
                                                        <?php echo strtolower($bird_conservancy_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>

            <!--Genus Column-->
            <div class="search-filter-col">
                <div class="taxonomic-genus-filter dropdown">
                    <div class="custom-dropdown <?php if($taxonomicgenus) { echo 'filterselected'; } ?>" data-toggle="dropdown">
                        <span id="taxonomicselected">Genus</span>
                    </div>
                    <?php
                        $taxonomy_genus = get_meta_values( 'bird_taxonomic_genus', 'cp_birds' );
                        // asort($taxonomy_genus, SORT_NATURAL | SORT_FLAG_CASE);
                        asort($taxonomy_genus, SORT_NATURAL | SORT_FLAG_CASE);
                        if( !empty( $taxonomy_genus ) ) {
                            ?>
                                <ul class="dropdown-menu">
                                    <!--<li><a href="javascript:void(0);">Genus</a></li>-->
                                    <?php
                                        foreach( $taxonomy_genus as $key => $taxonomy_genus_value ){
                                            /*$num_of_ratings[] = $taxonomy_genus_value;*/
                                            if( !empty($taxonomy_genus_value) ){
                                                ?>
                                                <li <?php if($taxonomicgenus == strtolower($taxonomy_genus_value)) { echo 'class=active'; } ?>>
                                                    <a href="javascript:void(0);" data-taxonomic-genus="<?php echo strtolower($taxonomy_genus_value); ?>">
                                                        <?php echo strtolower($taxonomy_genus_value); ?>
                                                    </a>
                                                </li>
                                                <?php
                                                
                                            }
                                        }
                                    ?>
                                </ul>
                            <?php
                        }
                    ?>
                </div>
            </div>
            
            <div class="search-filter-col">
                <div class="buttonarea">
                    <div class="submitsearch"><a class="submitsearchbtn">Search</a></div>
                    <div class="filter-clear"><a href="javascript:void(0);" class="custom-clear-btn clear-search">Clear</a></div>
                </div>
            </div>
        </div>
        
        <?php if( is_search() ) { ?>
            <?php if( $exit == 1 ) { ?>
            <div class="search-results-container" id="search-results-container">         
                <?php  
                    global $wp_query,$post;
                    // print_r($post);
                    if( $wp_query->found_posts != 0 ){
                    ?>
                        <h2 class="large">
                            <?php _e('Search Results','owen'); ?>
                            <p class="resultcount"><?php echo 'Found ' . $wp_query->found_posts; ?></p>
                            <?php if(!empty(get_field('taxonomy_page_info','option'))) { ?>
                                    <div class="search-moreinfo">
                                        <p class="resultcount"><?php echo get_field('taxonomy_page_info','option'); ?></p>
                                    </div>
                                    <div class="sortby-filter-col">
                    <div class="sortby-filter dropdown">
                        <div class="custom-dropdown" data-toggle="dropdown">
                            <div>
                            <span id="sortbySelected">Sort By</span>

                            </div>
                        </div>
                        <ul class="dropdown-menu basic-filter">
                            <li><a href="javascript:void(0);" data-sort="name-asc">Bird Name A-Z</a></li>
                            <li><a href="javascript:void(0);" data-sort="name-desc">Bird Name Z-A</a></li>
                            <li><a href="javascript:void(0);" data-sort="oldest">Oldest to Newest</a></li>
                            <li><a href="javascript:void(0);" data-sort="newest">Newest to Oldest</a></li>
                        </ul>
                    </div>
                </div>
                            <?php } ?>
                        </h2>
                <?php } ?>

                <ul class="search-results" id="playground">
                    <?php
                        if( have_posts() ) : 
                            while( have_posts() ) : the_post();
                                $postid = $post->ID;
                                $guid =$post->guid; 
                                $od_post_url = get_permalink($postid);                                
                                $default_placeholder_image = get_template_directory_uri()."/images/placeholder-bird.png";
                                $feat_image_full = wp_get_attachment_image_src( get_post_thumbnail_id( $postid ), 'full', false );
                                $feat_image_full_src = !empty( $feat_image_full[0] ) ? $feat_image_full[0] : $default_placeholder_image;
                                $feat_image_medium = wp_get_attachment_image_src( get_post_thumbnail_id( $postid ), 'square-medium', false );
                                $feat_image_medium_src = !empty( $feat_image_medium[0] ) ? $feat_image_medium[0] : $default_placeholder_image;
                                $iframedata = get_field('bird_sounds', $postid );
                                
                            ?>
                                <li data-post_id = "<?php echo $postid; ?>" >
                                    <div class="searchgallery" data-fancybox="search-gallery" href="<?php echo $feat_image_full_src; ?>">
                                        <div class="image-outer-table">
                                            <div class="image">
                                                <img src="<?php echo $feat_image_medium_src; ?>" alt="<?php echo $post->post_title; ?>" />
                                            </div>
                                        </div>
                                        <div class="image-title">
                                        <?php /*<h3><?php echo $postid; ?></h3>*/ ?>
                                        <?php if( !empty($iframedata) ) { ?>
                                                <div class="music-symbol">
                                                <img src="<?php echo $HOME_URL; ?>/wp-content/uploads/2019/08/musical-notes-symbols-2.png" alt="music">
                                            </div>
                                            <?php } ?>
                                            <?php $trimtitle = $post->post_title; 
                                                    //pr(trim($trimtitle,'-'));
                                                    $title = trim($trimtitle);
                                            _e($title,'owen'); ?>
                                            <?php if( !empty($iframedata) ) { ?>
                                                <!-- <span class="birdplaysound"> -->
                                                    <!--<i class="fa fa-music fa-lg"></i>-->
                                                <!-- </span> -->
                                            <?php } ?>
                                        </div>
                                        <!--Bird Detail Layout Start-->
                                        <figcaption>
                                            <div class="countrydetails">
                                            <h4 data-postid="<?php echo $postid; ?>" data-value="<?php echo $od_post_url; ?>">
                                            <?php echo get_the_title($postid); ?>
                                            </h4>
                                            <?php /*<h3><?php echo 'ID : ' . $postid; ?></h3>*/ ?>
                                            <div class="custom-table">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <?php 
                                                            $get_order = get_field('bird_family',$postid);
                                                            if(!empty($get_order)){ 
                                                            $search_order = mb_strtolower($get_order);
                                                            $search_order_url = site_url() . '/?s=&birdfamily='.$search_order;
                                                        ?>
                                                            <h5>Order</h5>
                                                            <a href="<?php echo $search_order_url; ?>" class="whitebtn"><?php echo $search_order; ?></a>
                                                        <?php } ?>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <?php 
                                                            $get_family = get_field('bfamily',$postid);
                                                            if(!empty($get_family)){ 
                                                            $search_get_family = mb_strtolower($get_family);
                                                            $search_family_url = site_url() . '/?s=&family='.$search_get_family;
                                                        ?>
                                                            <h5>Family</h5>
                                                            <a href="<?php echo $search_family_url; ?>" class="whitebtn"><?php echo $search_get_family; ?></a>
                                                        <?php } ?>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <h5>Genus <span>(Similar Species)</span></h5>
                                                        <?php
                                                        $gettxgenus = get_field('bird_taxonomic_genus',$postid);
                                                            if(!empty($gettxgenus)) { 
                                                            $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.strtolower($gettxgenus);
                                                        ?>
                                                        
                                                            <div class="specbtn">
                                                            <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo $gettxgenus; ?></a>
                                                            </div>
                                                        <?php } ?>
                                                    </div>
                                                    <?php if(!empty(get_field('bird_scientific_name',$postid))) { ?>
                                                        <div class="col-md-6">
                                                        <h5>Scientific Name</h5>
                                                        <h6><?php echo get_field('bird_scientific_name',$postid); ?></h6>
                                                        </div>
                                                    <?php } ?>
                                                </div>
                                            </div>
                                            <ul>
                                                    <!-- <li> -->
                                                        <?php /*if(!empty(get_field('bird_scientific_name',$postid))) { ?>
                                                                <h5>Scientific Name</h5>
                                                                <h6><?php echo get_field('bird_scientific_name',$postid); ?></h6>
                                                        
                                                        <?php } 
                                                            $gettxgenus = get_field('bird_taxonomic_genus',$postid);
                                                            if(!empty($gettxgenus)) { 
                                                            $gettxgenusurl = site_url() . '/?s=&taxonomicgenus='.strtolower($gettxgenus);
                                                        ?>
                                                            <div class="specbtn">
                                                                <a class="whitebtn" href="<?php echo $gettxgenusurl; ?>" target="_self"><?php echo "Similar Species"; ?></a>
                                                            </div>
                                                        <?php   }*/ ?>
                                                       
                                                    <!-- </li>  -->
                                                    <?php
                                                        $getcs = get_field('bird_conservation_status',$postid);
                                                        if(!empty($getcs)) { 
                                                        $csurl = site_url() . '/?s=&conservancy='.strtolower($getcs);
                                                    ?>
                                                        <li>
                                                            <h5>Conservation Status</h5>
                                                            <a class="whitebtn" href="<?php echo $csurl; ?>" target="_self"><?php echo $getcs; ?></a>
                                                        </li>
                                            <?php   }   ?>
                                            </ul>
                                            <div class="border-bottom-bird">
                                                <div class="row">
                                            <?php 
                                                $terms = wp_get_post_terms($postid, 'cp_birds_country');
                                                if( !empty( $terms ) && !is_wp_error( $terms ) ) {
                                                    $taxonomy = $terms[0]->name;
                                                    $taxonomyid = $terms[0]->term_id;
                                                    $scurl = site_url() . '/?s=&country='.strtolower($taxonomyid);
                                                    ?>  
                                                    <div class="col-md-6 last-child">
                                                        <h5>Country</h5>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php echo $taxonomy; ?></a>
                                                            <a href="<?php echo site_url().'/countries/'; ?>" class="whitebtn">
                                                            View more Countries
                                                            </a>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                }
                                            ?>
                                            <?php if (!empty(get_field('state',$postid))){ ?>
                                                    <div class="col-md-6">
                                                        <h5>State</h5>
                                                        <div class="newcountrybtns">
                                                            <a class="whitebtn" href="<?php echo $scurl; ?>" target="_self"><?php the_field('state',$postid); ?></a>
                                                        </div>
                                                    </div>
                                                    <?php 
                                                }
                                            ?>
                                            </div>
                                        </div>
                                        <?php if ((!empty(get_field('bird_gender',$postid))) || (!empty(get_field('bird_age',$postid)))){ ?>
                                                   <div class="border-bottom-bird">
                                                    <div class="row">
                                                <?php if(!empty(get_field('bird_gender',$postid))){ ?>
                                                    <div class="col-md-6 last-child">
                                                        <h5>Gender </h5>
                                                        <h6><?php echo get_field('bird_gender',$postid); ?></h6>
                                                    </div>
                                            <?php } if(!empty(get_field('bird_age',$postid))) { ?>
                                                    <div class="col-md-6">
                                                        <h5>Age</h5>
                                                        <h6><?php echo get_field('bird_age',$postid); ?></h6>
                                                    </div>
                                                    
                                            <?php } ?>
                                                </div>
                                                </div>
                                            <?php }  ?>
                                            <ul>

                                            <?php $getvc = get_field('bird_visual_country',$postid);
                                                    if(!empty($getvc)) { 
                                                    $getvcurl = site_url() . '/?s=&visualcategory='.strtolower($getvc);
                                                ?>
                                                    <li>
                                                        <h5>Visual Category</h5>
                                                        <a class="whitebtn" href="<?php echo $getvcurl; ?>" target="_self"><?php echo $getvc; ?></a>
                                                    </li>
                                            <?php } 
                                                    $getlocMulti = get_field('bird_locations_multi',$postid);
                                                    if(!empty($getlocMulti) && isset($getlocMulti)) {
                                                        ?>
                                                   <li>
                                                        <h5>Birding Sites and Lodges</h5>
                                                        <?php
                                                            foreach ($getlocMulti as $post) {
                                                                // Check if POST_TITLE is set before echoing
                                                                if (isset($post->post_title)) {
                                                                    $getlocurlMulti = site_url() . '/?s=&locations='.strtolower($post->post_title);
                                                                    ?>
                                                                    <a class="whitebtn" href="<?php echo $getlocurlMulti ?>" target="_self">
                                                                        <?php echo $post->post_title; ?>
                                                                    </a>
                                                                    <?php
                                                                }
                                                                if(!empty($post) && !isset($post->post_title)) {
                                                                    $get_title_lodges = $wpdb->get_results( "SELECT post_title FROM wp_posts WHERE ID IN ($post) AND post_status = 'publish'", ARRAY_N);
                                                                    $lodges_postidtit = array_column($get_title_lodges, 0);
                                                                    $getlocurlMulti = site_url() . '/?s=&locations='.strtolower($lodges_postidtit[0]);
                                                                    ?>
                                                                    <a class="whitebtn" href="<?php echo $getlocurlMulti; ?>" target="_self">
                                                                        <?php echo $lodges_postidtit[0]; ?>
                                                                    </a>
                                                                    <?php
                                                                }
                                                            }
                                                        ?>
                                                    </li>
                                            <?php }  ?>
                                            
                                            <?php
                                                /*$get_order = get_field('bird_family',$postid);
                                                if(!empty($get_order)){ 
                                                $search_order = strtolower($get_order);
                                                $search_order_url = site_url() . '/?s=&birdfamily='.$search_order;
                                                ?>
                                                    <li>
                                                        <h5>Order</h5>
                                                        <a class="whitebtn" href="<?php echo $search_order_url; ?>" >
                                                            <?php echo $get_order; ?>
                                                        </a>
                                                    </li>
                                            <?php } */
                                            $search_activityurl = '';
                                                $get_activity = get_field('bird_activity',$postid);
                                                if(!empty($get_activity) && isset($get_activity)) { ?>
                                                    <li>
                                                        <h5>Activity</h5>
                                                        <?php
                                                            if($get_activity != ''){
                                                                $explodeactivity = explode(",",$get_activity);
                                                                foreach ($explodeactivity as  $activityrow) {
                                                                    $search_activityurl = site_url() . '/?s=&activity='.$activityrow;
                                                        ?>
                                                                <a class="whitebtn" href="<?php echo $search_activityurl; ?>" >
                                                                    <?php echo $activityrow; ?>
                                                                </a>
                                                        <?php } } ?>
                                                    </li>
                                            <?php } ?>
                                            </ul>
                                            <?php 
                                                //if(!empty($get_activity) && isset($get_activity)) { ?>
                                                    <div class="custom-table new-cat">
                                                       <div class="row">
                                                            <?php
                                                              if( have_rows('categories', $postid) ):
                                                                  while ( have_rows('categories', $postid) ) : the_row();
                                                                      if( get_row_layout() == 'category' ): 
                                                                          $name = get_sub_field('name');
                                                                          $value = get_sub_field('value'); ?>
                                                                          <div class="col-md-6">
                                                                              <h5><?php echo $name; ?></h5>
                                                                              <a class="whitebtn" href="<?php echo $search_activityurl; ?>" ><?php echo $value; ?></a>
                                                                          </div>
                                                                     <?php
                                                                      endif;                                      
                                                                  endwhile;
                                                              else :                                      
                                                              endif;
                                                            ?>
                                                        </div>
                                                    </div>
                                              <?php //} ?>
                                            <?php if(!empty($iframedata)){
                                                ?>
                                                
                                            <h5>BIRD CALLS</h5>
                                                <div class="iframeappend">
                                                    <?php $removelastcomma = rtrim($iframedata, ',');
                                                    ?>
                                                    <input type="hidden" id="custId" name="custId" value="<?php echo $removelastcomma; ?>">
                                                    <img class="iframeloader" src="<?php echo get_template_directory_uri(). '/images/loader.svg'; ?>" alt="Page Loader">
                                                </div>
                                            <?php } ?>
                                            </div>
                                        </figcaption>
                                        
                                        <!--Bird Detail Layout End-->

                                    </div>
                                </li>
                            <?php
                            endwhile;
                            wp_reset_query(); wp_reset_postdata(); 
                        else :
                            if($exit == 1) {
                                echo '<h2 class="large">Search Results</h2>';
                                if ( function_exists( 'relevanssi_didyoumean' ) ) {
                                    relevanssi_didyoumean( get_search_query(), '<p class="suggestioncls">Did you mean: ', '</p>', 3 );
                                }
                                echo '<h2>No birds found - try clearing filters and/or broadening your search</h2>';
                            }
                            
                        endif;
                        wp_reset_query(); wp_reset_postdata(); 
                    
                    ?>

                </ul>
                
                <?php 
                    the_posts_pagination( array(
                        'prev_text' => __( 'Previous', 'theme' ),
                        'next_text' => __( 'Next', 'theme' ),
                        'screen_reader_text' => __( ' ' )

                    ) );
                    
                ?>

            </div>
            <?php } ?>
        <?php }?>
    </div> 
</div>
<?php get_footer(); 
?>
<script type='text/javascript' src="<?php echo get_template_directory_uri(); ?>/js/hilitor.js"></script>
<script>
window.addEventListener("DOMContentLoaded", function(e) {
    var myHilitor2 = new Hilitor("playground");
    //myHilitor2.setEndRegExp('^[^\\w-]+|[^\\w]+$');
    //myHilitor2.setBreakRegExp(new RegExp('[^\\w\' - ]+', "g"));
    myHilitor2.setMatchType("left");
    var searchterm = jQuery("#searchfocus").val();
    myHilitor2.apply(searchterm);
}, false);
</script>
<script type="text/javascript">
    var urlsite = "<?php echo site_url(); ?>";
    jQuery(document).ready(function ($) {
        jQuery.noConflict();
        var search_inputFocus = $("#searchfocus");
        if( search_inputFocus.val().length > 0 ){
            var len = search_inputFocus.val().length;
            search_inputFocus[0].focus();
            search_inputFocus[0].setSelectionRange(len, len);
        }
        jQuery(".loader-icon").hide();
        jQuery('.lazy').lazy({
           
            // called before an elements gets handled
                beforeLoad: function(element) {
                    var imageSrc = element.data('src');
                    jQuery("#fancybox-wrap #fancybox-content #fancybox-img").attr('alt', alt);
                },
                // called after an element was successfully handled
                afterLoad: function(element) {
                    var imageSrc = element.data('src');
                    jQuery("#fancybox-wrap #fancybox-content #fancybox-img").attr('alt', alt);
                    
                },
                // called whenever an element could not be handled
                onError: function(element) {
                    var imageSrc = element.data('src');
                    jQuery("#fancybox-wrap #fancybox-content #fancybox-img").attr('alt', alt);
                    
                },
                // called once all elements was handled
                onFinishedAll: function() {
                    console.log('finished loading all images');

                }
        });

        var maximumpages    = "<?php echo $wp_query->max_num_pages; ?>";
        var getcurrentpage  = "<?php echo get_query_var('paged'); ?>";
        var perpagepost    = "<?php echo $wp_query->post_count; ?>";
        var cpagelink       = "<?php echo get_pagenum_link(strip_tags((get_query_var('paged'))+1),false); ?>";
        var firstpagelink   = "<?php echo get_pagenum_link(strip_tags((get_query_var('paged'))),false); ?>";
        var searchparameters  = window.location.search;
        var str         = window.location.hash;
        var lastSlash   = str.lastIndexOf("-");
        console.log(str.substring(lastSlash+1));
        jQuery('[data-fancybox="search-gallery"]').fancybox({
            loop: false,
            baseClass: "fancybox-search-layout",
            infobar: false,
            touch : true,
            wheel:false,
            clickSlide:false,
            clickOutside:false,
            //hash : false,
            buttons: ["close", "slideShow","fullScreen"],
            animationEffect: "fade",
            transitionEffect: "fade",
            preventCaptionOverlap: false,
            idleTime: false,
            gutter: 0,
            iframe : {
                preload: false
            },
            // Customize caption area
            caption : function( instance, item ) {
               return $(this).find('figcaption').html();
            },
            beforeLoad: function(instance, current) {
                var canonical_link = $(".fancybox-container").contents().find( ".fancybox-caption").find('.countrydetails').find("h4").attr("data-value");
                jQuery("#cono_link").remove();
                jQuery("head").append('<link rel="canonical" id="cono_link" href="'+canonical_link+'" >');
                
            },
            afterLoad: function(instance, current) {
            	
            },
            beforeShow: function( instance, current ) {
            },
            afterShow: function( instance, current ) {
                
                var currentDivNo = instance.currIndex;
                /*Next logic*/
                var gallerySize = instance.group.length;
                
                if(parseInt(getcurrentpage) == 0  && parseInt(maximumpages) == 1 && (instance.currIndex == parseInt(gallerySize) - 1)){
                    jQuery('.fancybox-navigation').find(".fancybox-button--arrow_right").attr( "disabled",true);
                }else{
                    if((parseInt(getcurrentpage) == parseInt(maximumpages) && (instance.currIndex == parseInt(perpagepost) - 1))){
                        // $(".customnextbtn").remove();
                        jQuery('.fancybox-navigation').find(".fancybox-button--arrow_right").attr( "disabled",true );
                    }else
                    {
                        jQuery('.fancybox-navigation').find(".fancybox-button--arrow_right").attr( "disabled",false );
                    }
                    if ((instance.currIndex == parseInt(gallerySize) - 1)) {
                        $("button.fancybox-button.fancybox-button--arrow_right>div").addClass('FancyLastImage');
                        $("button.fancybox-button.fancybox-button--arrow_right").attr("disabled", true);
                        jQuery(".FancyLastImage").parents(".fancybox-navigation").append("<button class='customnextbtn'>NEXT Button</button>");
                        jQuery(".customnextbtn").on('click', function(){
                            if((parseInt(getcurrentpage)==0)&&(parseInt(instance.currIndex) == 99)&&((parseInt(instance.currIndex))==parseInt(gallerySize)-1)) {
                                jQuery(".loader-icon").show();
                                window.location.href = urlsite+'/page/2/'+searchparameters+"#search-gallery-1";
                            } else if ((parseInt(getcurrentpage)>=2)&&(parseInt(instance.currIndex)==99) &&((parseInt(instance.currIndex)==(parseInt(gallerySize)-1)))) {
                                jQuery(".loader-icon").show();
                                window.location.href = cpagelink+"#search-gallery-1";
                            }else{
                                if(parseInt(getcurrentpage) < parseInt(maximumpages)){
                                    // window.location.href = cpagelink+"#search-gallery-1";
                                }else{
                                    $(".customnextbtn").remove();
                                }
                            }

                        });
                    }else{
                        $(".customnextbtn").remove();
                        $("button.fancybox-button.fancybox-button--arrow_right>div").removeClass('FancyLastImage');
                    }
                }
                /*Prev Logic*/
                if ((parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0)){
                    $("button.fancybox-button.fancybox-button--arrow_left>div").addClass('FancyFirstImage');
                    $("button.fancybox-button.fancybox-button--arrow_left").removeAttr("disabled");
                    var prevpagelink = "<?php echo get_pagenum_link(strip_tags((get_query_var('paged'))-1),false); ?>";
                    jQuery(".FancyFirstImage").parents(".fancybox-navigation").append("<button class='customprevbtn'>Prev Button</button>");
                    jQuery(".customprevbtn").on('click', function(){
                        if((parseInt(getcurrentpage)!=0)&&(parseInt(getcurrentpage)<=2)&&(parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0)){
                            jQuery(".loader-icon").show();
                            window.location.href = urlsite+searchparameters+"#search-gallery-100"
                        }else if((parseInt(getcurrentpage)>2)&&((parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0))){
                            jQuery(".loader-icon").show();
                            window.location.href = prevpagelink+"#search-gallery-100";
                        }else{
                            $(".customnextbtn").remove();
                        }
                    });

                } else {
                    $(".customprevbtn").remove();
                    $("button.fancybox-button.fancybox-button--arrow_left>div").removeClass('FancyFirstImage');
                }
                
                /*Iframe Logic Load After Fancybox Load */
                var iframestr   =  $(".searchgallery:eq("+currentDivNo+")").find('#custId').val();
                console.log(iframestr);
                if((typeof(iframestr) != 'undefined') &&(iframestr) && (iframestr !== null) && (iframestr !== '')){
                    var ifrmaesplit = iframestr.split(',');
                    var ihtml = '';
                    for(var i = 0; i < ifrmaesplit.length; i++) {
                       // Trim the excess whitespace.
                        ifrmaesplit[i] = ifrmaesplit[i].replace(/^\s*/, "").replace(/\s*$/, "");
                        // Add additional code here, such as:
                        ihtml +="<iframe src='https://www.xeno-canto.org/"+ifrmaesplit[i]+"/embed?simple=1&darkbg=1' height='110' width='100%' frameborder='0' scrolling='no'></iframe>";
                    }
                    $(".fancybox-container").contents().find( ".fancybox-caption").find('.countrydetails').find(".iframeappend" ).append(ihtml);
                    $(".fancybox-caption .iframeappend iframe").on('load', function(){
                        $(".iframeloader").hide();
                    });
                }

                /*Key Press Events*/
                    jQuery(document).on("keydown", function (e) {
                        console.log('inin');
                        var code = e.which || e.keyCode;
                        if (code >= 37 && code <= 40) {
                            console.log("press"+code);

                            if (e.keyCode == '37') {
                            /* left arrow */ //alert('left arrow');
                                if (parseInt(getcurrentpage)>0){
                                    jQuery('.fancybox-navigation').find(".customprevbtn").trigger( "click" );
                                }
                            }
                            if (e.keyCode == '39') {
                            /*right  arrow*/
                                if ((instance.currIndex == parseInt(gallerySize) - 1)) { 
                                    jQuery('.fancybox-navigation').find(".customnextbtn").trigger( "click" );
                                }
                            
                            }
                            if (e.keyCode == '38') {
                            /* up arrow */
                                if ((parseInt(instance.currIndex)==0)&&(parseInt(getcurrentpage)>0)){
                                    jQuery('.fancybox-navigation').find(".customprevbtn").trigger( "click" );
                                }
                            }
                            if (e.keyCode == '40') {
                            /*down arrow*/
                            if ((instance.currIndex == parseInt(gallerySize) - 1)) {
                                jQuery('.fancybox-navigation').find(".customnextbtn").trigger( "click" );
                            }
                        }
                        }
                    
                    });
                // } //main else close
            },
        });
    });
</script>
<script>
jQuery(document).ready(function($) {
    // Check if a sort filter is already applied in the URL
    var currentUrl = new URL(window.location.href);
    var sortBy = currentUrl.searchParams.get('sortby');

    if (sortBy) {
        // Find the matching dropdown item and update the displayed text
        var selectedItem = $('.dropdown-menu a[data-sort="' + sortBy + '"]');
        if (selectedItem.length) {
            $('#sortbySelected').text(selectedItem.text());
        }
    }

    // Handle dropdown item clicks
    $('.dropdown-menu.basic-filter a').on('click', function(e) {
        e.preventDefault();

        var sortType = $(this).data('sort');
        $('#sortbySelected').text($(this).text());

        // Update the URL with the new sort parameter
        currentUrl.searchParams.set('sortby', sortType);
        console.log("hello");
        // Reload the page with the new sorting parameter
        window.location.href = currentUrl.toString();
    });
});

</script>